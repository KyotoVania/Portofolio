/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** TrueComponent.hpp
*/
#ifndef TRUECOMPONENT_HPP_
	#define TRUECOMPONENT_HPP_

#include "AComponent.hpp"

namespace nts {
class TrueComponent : public nts::AComponent {
    public:
        TrueComponent();
        ~TrueComponent();
        nts::Tristate compute(std::size_t pin);
        std::vector<Pin> * getLinks();
        const std::vector<Pin> * getLinks() const;
        void display(std::ostream &os);
    void setStates(nts::Tristate state) {};
    private:
        std::vector<Pin> links = std::vector<Pin> (1);


};
}
#endif /*TRUECOMPONENT_HPP_*/