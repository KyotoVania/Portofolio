/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** PinComponent.hpp
*/
#ifndef PINCOMPONENT_HPP_
	#define PINCOMPONENT_HPP_
#include "IComponent.hpp"
#include <cstddef>


class Pin {
    public:
    Pin();
    ~Pin();
    nts::IComponent *other;
    std::size_t otherPin;
    void setLink(nts::IComponent &other, std::size_t otherPin);
    nts::Tristate compute();
};

#endif /*PINCOMPONENT_HPP_*/