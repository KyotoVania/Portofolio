/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** control_socket_operation.c
*/

#include "myftp.h"

int bind_socket(server_t *server)
{
    if (bind(server->fd, (const struct sockaddr *)&server->s_in,
        sizeof(server->s_in)) == -1)
        return (84);
    if (listen(server->fd, SOMAXCONN) == -1)
        return (84);
    return (0);
}

int set_value_for_client_accept(fd_node_t *node, server_t *server)
{
    node->buffer = malloc(sizeof(char) * 1024);
    node->buffer_size = 1024;
    node->buffer_pos = 0;
    node->status = is_connected;
    node->working_dir = strdup(server->home_dir);
    node->client_addr_len = sizeof(node->client_addr);
    node->data_fd = 0;
    node->data_port = -1;
    node->states = undefined;
    node->fd = accept(server->fd,
    (struct sockaddr *)&node->client_addr, &node->client_addr_len);
    if (node->fd == -1)
        return (84);
    return (0);
}

int set_value_for_client_connect(fd_node_t *node, server_t *server)
{
    node->ip = inet_ntoa(node->client_addr.sin_addr);
    node->port = ntohs(node->client_addr.sin_port);
    node->next = server->client_fds;
    server->client_fds = node;
    server->client_count++;
    return (0);
}

int accept_client(server_t *server)
{
    fd_node_t *node = malloc(sizeof(fd_node_t));
    if (node == NULL)
        return (84);
    if (set_value_for_client_accept(node, server) == 84)
        return (84);
    if (set_value_for_client_connect(node, server) == 84)
        return (84);
    if (server->client_fds == NULL) {
        printf("Error: realloc failed\n");
        return (84);
    }
    if (send_client_line(node->fd,
        "220 Service ready for new user.\n") == 84)
        return (84);
    return (node->fd);
}
