/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** factory.hpp
*/
#ifndef FACTORY_HPP_
	#define FACTORY_HPP_
#include "utils/shared.hpp"
#include <iostream>
#include <vector>
#include "scene/camera.hpp"
#include "primitives/sphere.hpp"
#include "primitives/plane.hpp"
#include "lights/ambient_light.hpp"
#include "lights/directional_light.hpp"
#include "lights/pointLight.hpp"
#include <libconfig.h++>

class CameraFactory {
public:
	Camera create(const libconfig::Setting& cameraConfig) {
		int width = cameraConfig["resolution"]["width"];
		int height = cameraConfig["resolution"]["height"];
		float fieldOfView = cameraConfig["fieldOfView"];
		std::cout << "width: " << width << std::endl;
		std::cout << "height: " << height << std::endl;
		return Camera(fieldOfView, float(width) / float(height));
	}
};

class ResolutionFactory {
	public:
	std::pair<int, int> create(const libconfig::Setting& cameraConfig) {
		int width = cameraConfig["resolution"]["width"];
		int height = cameraConfig["resolution"]["height"];
		return std::make_pair(width, height);
	}
};


class SphereFactory
{
public:
	Sphere create(const libconfig::Setting& sphereConfig) {
		Vec3 sphereCenter;
		Vec3 sphereColor;
		Vec3 sphereTranslation;
		float sphereRadius;
		float spheretransparency;
		bool sphereCastShadow;
		bool sphereEnableReflection;
		float sphereRefractiveIndex;
		sphereCenter = Vec3(sphereConfig["center"]["x"], sphereConfig["center"]["y"], sphereConfig["center"]["z"]);	
		sphereColor = Vec3(sphereConfig["color"]["r"], sphereConfig["color"]["g"], sphereConfig["color"]["b"]);
		if (sphereConfig.exists("translation"))
			sphereTranslation = Vec3(sphereConfig["translation"]["x"], sphereConfig["translation"]["y"], sphereConfig["translation"]["z"]);
		else
			sphereTranslation = Vec3(0, 0, 0);
		sphereRadius = sphereConfig["radius"];	
		spheretransparency = sphereConfig["transparency"];
		sphereCastShadow = sphereConfig["castsShadow"];
		sphereEnableReflection = sphereConfig["enableReflection"];
		sphereRefractiveIndex = sphereConfig["refractiveIndex"];
		return Sphere(sphereCenter, sphereRadius, sphereColor, sphereTranslation,sphereEnableReflection, sphereRefractiveIndex, spheretransparency);
	}
};

class PlaneFactory
{
	
public:
	Plane create(const libconfig::Setting& planeConfig) {
		Vec3 planePoint;
		Vec3 planeNormal;
		Vec3 planeColor;
		Vec3 planeTranslation;
		bool planeEnableReflection;
		planePoint = Vec3(planeConfig["point"]["x"], planeConfig["point"]["y"], planeConfig["point"]["z"]);
		planeNormal = Vec3(planeConfig["normal"]["x"], planeConfig["normal"]["y"], planeConfig["normal"]["z"]);
		planeColor = Vec3(planeConfig["color"]["r"], planeConfig["color"]["g"], planeConfig["color"]["b"]);
		if (planeConfig.exists("translation"))
			planeTranslation = Vec3(planeConfig["translation"]["x"], planeConfig["translation"]["y"], planeConfig["translation"]["z"]);
		else
			planeTranslation = Vec3(0, 0, 0);
		planeEnableReflection = planeConfig["enableReflection"];

		return Plane(planePoint, planeNormal, planeColor, planeTranslation, planeEnableReflection);
	}
};

class AmbientLightFactory
{
	public:
		AmbientLight create(const libconfig::Setting& ambientLightConfig) {
			Vec3 ambientLightColor;
			float ambientLightIntensity;
			ambientLightColor = Vec3(ambientLightConfig["color"]["r"], ambientLightConfig["color"]["g"], ambientLightConfig["color"]["b"]);
			ambientLightIntensity = ambientLightConfig["intensity"];
			return AmbientLight(ambientLightColor, ambientLightIntensity);
		}
};

class pointLightFactory
{
	public:
		pointLight create(const libconfig::Setting& pointLightConfig) {
			Vec3 pointLightColor;
			Vec3 pointLightPosition;
			float pointLightIntensity;
			float pointLightConstantAttenuation;
			float pointLightLinearAttenuation;
			float pointLightQuadraticAttenuation;
			pointLightColor = Vec3(pointLightConfig["color"]["r"], pointLightConfig["color"]["g"], pointLightConfig["color"]["b"]);
			pointLightPosition = Vec3(pointLightConfig["position"]["x"], pointLightConfig["position"]["y"], pointLightConfig["position"]["z"]);
			pointLightIntensity = pointLightConfig["intensity"];
			pointLightConstantAttenuation = pointLightConfig["constantAttenuation"];
			pointLightLinearAttenuation = pointLightConfig["linearAttenuation"];
			pointLightQuadraticAttenuation = pointLightConfig["quadraticAttenuation"];
			return pointLight(pointLightPosition, pointLightColor, pointLightIntensity, pointLightConstantAttenuation, pointLightLinearAttenuation, pointLightQuadraticAttenuation);
		}
};

class directionalLightFactory
{
	public:
		DirectionalLight create(const libconfig::Setting& directionalLightConfig) {
			Vec3 directionalLightColor;
			Vec3 directionalLightDirection;
			float directionalLightIntensity;
			directionalLightColor = Vec3(directionalLightConfig["color"]["r"], directionalLightConfig["color"]["g"], directionalLightConfig["color"]["b"]);
			directionalLightDirection = Vec3(directionalLightConfig["direction"]["x"], directionalLightConfig["direction"]["y"], directionalLightConfig["direction"]["z"]);
			directionalLightIntensity = directionalLightConfig["intensity"];
			return DirectionalLight(directionalLightColor, directionalLightDirection, directionalLightIntensity);
		}
};

#endif /*FACTORY_HPP_*/