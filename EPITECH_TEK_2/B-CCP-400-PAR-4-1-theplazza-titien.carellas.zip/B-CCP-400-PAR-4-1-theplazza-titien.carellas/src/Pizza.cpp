/*
** EPITECH PROJECT, 2023
** B-CCP-400-PAR-4-1-theplazza-titien.carellas
** File description:
** Pizza.cpp
*/
#include "Pizza.hpp"
//Regina XXL x2;Margarita XXL x1;Americana XXL x2
//Regina XXL x5;Margarita XXL x5;Americana XXL x5
//Regina XXL x1
std::map<PizzaType, std::string> pizzaTypeMap = {
    {PizzaType::Margarita, "Margarita"},
    {PizzaType::Regina, "Regina"},
    {PizzaType::Americana, "Americana"},
    {PizzaType::Fantasia, "Fantasia"},
    {PizzaType::None, "None"}
};

std::map<PizzaSize, std::string> pizzaSizeMap = {
    {PizzaSize::S, "S"},
    {PizzaSize::M, "M"},
    {PizzaSize::L, "L"},
    {PizzaSize::XL, "XL"},
    {PizzaSize::XXL, "XXL"},
    {PizzaSize::Null, "Null"}
};

std::map<Ingredient, std::string> ingredientMap = {
    {Ingredient::Dough, "Dough"},
    {Ingredient::Tomato, "Tomato"},
    {Ingredient::Gruyere, "Gruyere"},
    {Ingredient::Steak, "Steak"},
    {Ingredient::Ham, "Ham"},
    {Ingredient::Mushrooms, "Mushrooms"},
    {Ingredient::Eggplant, "Eggplant"},
    {Ingredient::GoatCheese, "GoatCheese"},
    {Ingredient::ChiefLove, "ChiefLove"}
};

PizzaType getPizzaTypeFromString(const std::string& pizzaTypeString) {
    for (const auto& pair : pizzaTypeMap) {
        if (pair.second == pizzaTypeString) {
            return pair.first;  // Return the enum value
        }
    }
    return PizzaType::None;  // Return a default value if no match is found
}

PizzaSize getPizzaSizeFromString(const std::string& pizzaSizeString) {
    for (const auto& pair : pizzaSizeMap) {
        if (pair.second == pizzaSizeString) {
            return pair.first;  // Return the enum value
        }
    }
    return PizzaSize::Null;  // Return a default value if no match is found
}
Pizza::Pizza(PizzaType type, PizzaSize size)
{
    this->type = type;
    this->size = size;
}

Pizza::~Pizza()
{
}

void Pizza::removeIngredient(Ingredient ingredient)
{
    for (auto it = ingredients.begin(); it != ingredients.end(); it++) {
        if (*it == ingredient) {
            ingredients.erase(it);
            return;
        }
    }
}

std::ostream &operator<<(std::ostream &os, const Pizza &pizza)
{
    os << pizzaTypeMap[pizza.getType()] << " " << pizzaSizeMap[pizza.getSize()] << " ";
    for (auto it = pizza.getIngredients().begin(); it != pizza.getIngredients().end(); it++) {
        os << ingredientMap[*it];
        if (it + 1 != pizza.getIngredients().end())
            os << ", ";
    }
    return os;
}

std::ostream &operator<<(std::ostream &os, const PizzaType &pizzaType)
{
    os << pizzaTypeMap[pizzaType];
    return os;
}