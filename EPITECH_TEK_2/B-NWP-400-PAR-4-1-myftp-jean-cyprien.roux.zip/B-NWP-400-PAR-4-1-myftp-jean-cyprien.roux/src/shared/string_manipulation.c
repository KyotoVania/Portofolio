/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** string_manipulation.cpp
*/

#include <string.h>
#include "myftp.h"

void get_last_path_sub(char **tmp, char **last_path)
{
    if ((*tmp[0]) == '.' && (*tmp[1]) == '.'){
        (*tmp) = strdup((*tmp) + 3);
    }
    if ((*tmp[0]) == '/')
        (*tmp) = strdup((*tmp) + 1 );
    if ((*tmp)[strlen(*tmp) - 1] == '/')
        (*tmp)[strlen(*tmp) - 1] = '\0';
    (*last_path) = strtok((*tmp), "/");
}

char *get_last_path(char *path)
{
    char *last_path = NULL;
    char *tmp = NULL;

    if (path == NULL)
        return (NULL);
    tmp = strdup(path);
    if (tmp == NULL)
        return (NULL);
    get_last_path_sub(&tmp, &last_path);
    while (last_path != NULL) {
        tmp = last_path;
        last_path = strtok(NULL, "/");
    }
    return (tmp);
}

int read_and_write(int read_fd, int write_fd)
{
    char buffer[1024];
    int size = 0;

    while ((size = read(read_fd, buffer, 1023)) > 0) {
        buffer[size] = '\0';
        if (write(write_fd, buffer, size) == -1) {
            printf("Error: cannot write to server \n");
            return 84;
        }
        if (size < 1023)
            break;
    }
    return 0;
}
