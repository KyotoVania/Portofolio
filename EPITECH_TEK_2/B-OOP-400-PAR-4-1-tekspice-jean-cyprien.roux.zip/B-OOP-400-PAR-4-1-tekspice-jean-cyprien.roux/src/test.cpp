/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** test.cpp
*/

#include <iostream>
#include <memory>
#include "AndComponent.hpp"
#include "FalseComponent.hpp"
#include "TrueComponent.hpp"
#include "NotComponent.hpp"
#include "OrComponent.hpp"
#include "XorComponent.hpp"
#include "ClockComponent.hpp"
#include "InputComponent.hpp"
#include "OutputComponent.hpp"
#include "test.hpp"


my_Test::my_Test()
{
}

my_Test::~my_Test()
{
}

void my_Test::bigTest()
{
    this->testAnd();
    this->testOr();
    this->testXor();
    this->testNot();
    this->testInput();
    this->testFalse();
    this->testTrue();
    this->testBootsrap();
}

void my_Test::testAnd()
{
    std::unique_ptr<nts::IComponent> gate = std::make_unique<nts::AndComponent>();
    std::unique_ptr<nts::IComponent> input1 = std::make_unique<nts::FalseComponent>();
    std::unique_ptr<nts::IComponent> input2 = std::make_unique<nts::TrueComponent>();

    gate->setLink(1, *input1, 1);
    gate->setLink(2, *input2, 1);
    std::cout << "test gate AND : " << std::endl;
    std::cout << input1->compute(1) << " && " << input2->compute(1) << " ->"<< gate->compute(3) << std::endl;
    
}

void my_Test::testNot()
{
    std::unique_ptr<nts::IComponent> input1 = std::make_unique<nts::FalseComponent>();
    std::unique_ptr<nts::IComponent> inverter = std::make_unique<nts::NotComponent>();

    inverter->setLink(1, *input1, 1);
    std::cout << "test gate NOT : " << std::endl;
    std::cout << input1->compute(1) << " -> "<< inverter->compute(2) << std::endl;
    
}

void my_Test::testTrue ()
{
    std::unique_ptr<nts::IComponent> input1 = std::make_unique<nts::TrueComponent>();
    std::cout << "test gate TRUE : " << std::endl;
    std::cout << input1->compute(1) << std::endl;
    
}

void my_Test::testFalse ()
{
    std::unique_ptr<nts::IComponent> input1 = std::make_unique<nts::FalseComponent>();
    std::cout << "test gate FALSE : " << std::endl;
    std::cout << input1->compute(1) << std::endl;
}

void my_Test::testXor ()
{
    std::unique_ptr<nts::IComponent> gate = std::make_unique<nts::XorComponent>();
    std::unique_ptr<nts::IComponent> input1 = std::make_unique<nts::FalseComponent>();
    std::unique_ptr<nts::IComponent> input2 = std::make_unique<nts::TrueComponent>();

    gate->setLink(1, *input1, 1);
    gate->setLink(2, *input2, 1);
    std::cout << "test gate XOR : " << std::endl;
    std::cout << input1->compute(1) << " ^ " << input2->compute(1) << " ->"<< gate->compute(3) << std::endl;
    
}

void my_Test::testOr()
{
    std::unique_ptr<nts::IComponent> gate = std::make_unique<nts::OrComponent>();
    std::unique_ptr<nts::IComponent> input1 = std::make_unique<nts::FalseComponent>();
    std::unique_ptr<nts::IComponent> input2 = std::make_unique<nts::TrueComponent>();

    gate->setLink(1, *input1, 1);
    gate->setLink(2, *input2, 1);
    std::cout << "test gate OR : " << std::endl;
    std::cout << input1->compute(1) << " || " << input2->compute(1) << " ->"<< gate->compute(3) << std::endl;
    
}

void my_Test::testInput()
{
    std::unique_ptr<nts::IComponent> input1 = std::make_unique<nts::InputComponent>();
    std::unique_ptr<nts::IComponent> trucompo = std::make_unique<nts::TrueComponent>();
    input1->setLink(1, *trucompo, 1);
    std::cout << "test gate INPUT : " << std::endl;
    std::cout << input1->compute(2) << std::endl;
    
}



void my_Test::testBootsrap()
{
    std::unique_ptr<nts::IComponent> gate = std::make_unique<nts::AndComponent>();
    std::unique_ptr<nts::IComponent> input1 = std::make_unique<nts::FalseComponent>();
    std::unique_ptr<nts::IComponent> input2 = std::make_unique<nts::TrueComponent>();
    std::unique_ptr<nts::IComponent> inverter = std::make_unique<nts::NotComponent>();

    gate->setLink(1, *input1, 1);
    gate->setLink(2, *input2, 1);
    inverter->setLink(1, *gate, 3);
    std::cout << "test Bootsrap false / true / not / and : " << std::endl;
    std::cout << "!(" << input1->compute(1) << " && " << input2->compute(1) << ") ->"<< inverter->compute(2) << std::endl;
}
