/*
** EPITECH PROJECT, 2023
** B-CCP-400-PAR-4-1-panoramix-jean-cyprien.roux
** File description:
** main.c
*/



#include "panoramix.h"

int print_usage(int argc, char **argv)
{
    if (argc != 5) {
        printf("USAGE:\n");
        printf("\t./panoramix <nb_villagers> <pot_size> "
        "<nb_fights> <nb_refills>\n");
        return 1;
    }

    int nb_villagers = atoi(argv[1]);
    int pot_size = atoi(argv[2]);
    int nb_fights = atoi(argv[3]);
    int nb_refills = atoi(argv[4]);

    if (nb_villagers <= 0 || pot_size <= 0 || nb_fights <= 0 ||
    nb_refills <= 0) {
        printf("ERROR: All parameters should be positive integers.\n");
        return 1;
    }

    return 0;
}

int main(int argc, char **argv)
{
    if (print_usage(argc, argv) == 1)
        return (84);

    program_t program = {
            .parameters = {0, 0, 0, 0},
            .druid = {0, 0},
            .villagers = NULL,
            .semaphorex = {
                    .pot_mutex = PTHREAD_MUTEX_INITIALIZER,
                    .wake_mutex = PTHREAD_MUTEX_INITIALIZER,
                    .refill_sem = { .__align = 0 },
            }
    };
    init_program(argv, &program);
    return (0);
}
