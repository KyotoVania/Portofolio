/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** mathHelper.hpp
*/
#ifndef MATHHELPER_HPP_
	#define MATHHELPER_HPP_
	#include "utils/shared.hpp"
	#include "scene/scene_config.hpp"
	#include <thread>
class MathHelper {
	public:
	float clamped(float x, float min, float max) {
		if (x < min) return min;
		if (x > max) return max;
		return x;
	}
	float random_float() {
		static thread_local std::mt19937 generator(std::hash<std::thread::id>{}(std::this_thread::get_id()));
		static thread_local std::uniform_real_distribution<float> distribution(0.0, 1.0);
		return distribution(generator);
	}
	float phongSpecular(const Vec3& lightDirection, const Vec3& surfaceNormal, const Vec3& viewDirection, float shininess) {
		Vec3 reflectionDirection = (surfaceNormal * 2 * surfaceNormal.dot(lightDirection)) - lightDirection;
		float spec = std::max(0.0f, reflectionDirection.dot(viewDirection));
		return std::pow(spec, shininess);
	}


	float fresnelSchlick(const Vec3& incident, const Vec3& normal, float indexOfRefraction) {
		float cosTheta = std::abs(normal.dot(incident));
		float r0 = (1 - indexOfRefraction) / (1 + indexOfRefraction); 
		r0 = r0 * r0;
		return r0 + (1 - r0) * std::pow((1 - cosTheta), 5);
	}

	Vec3 refract(const Vec3& incident, const Vec3& normal, float n1, float n2) {
		float n = n1 / n2;
		float cosI = -normal.dot(incident);
		float sinT2 = n * n * (1.0f - cosI * cosI);

		if (sinT2 > 1.0f) {
			return incident - 2 * normal.dot(incident) * normal;
		}
    
		float cosT = std::sqrt(1.0f - sinT2);
		return incident * n + normal * (n * cosI - cosT);
	}


};

#endif /*MATHHELPER_HPP_*/