/*
** EPITECH PROJECT, 2023
** Strace
** File description:
** low_func.h
*/

#ifndef LOW_FUNC_H_
    #define LOW_FUNC_H_
    #include "trace.h"
    #include <ctype.h>

char * tolower_st(char *str);
void detach_and_exit(pid_t pid);
int get_arg_type(syscall_t syscall, int i);

#endif /*LOW_FUNC_H_*/
