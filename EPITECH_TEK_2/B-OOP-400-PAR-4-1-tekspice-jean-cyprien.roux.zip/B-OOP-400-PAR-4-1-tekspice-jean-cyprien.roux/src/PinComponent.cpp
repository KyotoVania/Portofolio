/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** PinComponent.cpp
*/


#include "PinComponent.hpp"

Pin::Pin()
{
    other = nullptr;
    otherPin = 0;
}

Pin::~Pin()
{
}

void Pin::setLink(nts::IComponent &other, std::size_t otherPin)
{
    this->other = &other;
    this->otherPin = otherPin;
}

nts::Tristate Pin::compute()
{
    if (other != nullptr)
        return other->compute(otherPin);
    return nts::UNDEFINED;
}

