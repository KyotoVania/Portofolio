/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** AndComponent.hpp
*/
#ifndef ANDCOMPONENT_HPP_
	#define ANDCOMPONENT_HPP_

#include "AComponent.hpp"
#include "PinComponent.hpp"

namespace nts {

class AndComponent : public nts::AComponent {
    public:
        AndComponent();
        ~AndComponent();
        nts::Tristate compute(std::size_t pin);
        const std::vector<Pin> * getLinks() const;
        std::vector<Pin> * getLinks();
        void display(std::ostream &os);
        void setStates(nts::Tristate state) {};

private:
        std::vector<Pin> links = std::vector<Pin> (3);
    };
};

#endif /*ANDCOMPONENT_HPP_*/