/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** ClockComponent.hpp
*/
#ifndef CLOCKCOMPONENT_HPP_
	#define CLOCKCOMPONENT_HPP_

#include "AComponent.hpp"


namespace nts {
    class ClockComponent : public nts::AComponent {
        public:
            ClockComponent();
            ~ClockComponent();
        protected:
            nts::Tristate compute(std::size_t pin);
            void simulate(std::size_t tick);
            std::vector<Pin> * getLinks();
            const std::vector<Pin> * getLinks() const;
            void display(std::ostream &os);
            void setStates(nts::Tristate state);
        private:
            std::vector<Pin> links = std::vector<Pin> (1);
            nts::Tristate state = nts::UNDEFINED;
            nts::Tristate newstate = nts::UNDEFINED;
    };
};

#endif /*CLOCKCOMPONENT_HPP_*/