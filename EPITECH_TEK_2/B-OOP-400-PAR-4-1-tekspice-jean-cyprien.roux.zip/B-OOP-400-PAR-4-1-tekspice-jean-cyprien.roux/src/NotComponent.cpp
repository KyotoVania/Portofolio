/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** NotComponent.cpp
*/

#include "NotComponent.hpp"
#include "IComponent.hpp"

nts::NotComponent::NotComponent()
{

}

nts::NotComponent::~NotComponent()
{
}

nts::Tristate nts::NotComponent::compute(std::size_t pin)
{
    if (pin == 2) {
        //check the adress of the link
        if (getLink(1) == nts::TRUE)
            return nts::FALSE;
        else if (getLink(1) == nts::FALSE)
            return nts::TRUE;
        else
            return nts::UNDEFINED;
    }
    if (pin == 1) {
        return getLink(1);
    }
    return nts::UNDEFINED;
}

const std::vector<Pin> * nts::NotComponent::getLinks() const
{
    return &links;
}

std::vector<Pin> * nts::NotComponent::getLinks()
{
    return &links;
}

void nts::NotComponent::display(std::ostream &os)
{
    os << "NotComponent" << std::endl;
}