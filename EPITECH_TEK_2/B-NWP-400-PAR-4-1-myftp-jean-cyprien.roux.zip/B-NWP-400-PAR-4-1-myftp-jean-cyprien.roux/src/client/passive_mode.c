/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** passive_mode.c
*/

#include "client.h"

int parse_ip_port_from_pasv_response(char *msg, char **ip_out,
int *port_out)
{
    char *end = NULL;
    char *tok = NULL;
    char *ip = NULL;
    int port = 0;

    if (parse_ip_port_from_pasv_response_sub(
            &end, &tok, &ip, msg) != 0)
        return -1;
    port = parse_ip_port_from_pasv_response_port(tok, port);
    if (port == -1) {
        free(ip);
        return -1;
    }
    *ip_out = ip;
    *port_out = port;
    return 0;
}

int activate_passive_mode(char *msg, client_t *client)
{
    char *ip = NULL;
    int port = 0;

    if (parse_ip_port_from_pasv_response(msg, &ip, &port) != 0) {
        return -1;
    }
    int res = connect_toserver_passive(ip, port, client);
    free(ip);
    return res;
}

int retrieve_passive_mode(client_t *client, char *pathname)
{
    int fd_file = (open(pathname, O_CREAT | O_WRONLY, 0644));

    if (fd_file == -1) {
        perror("open");
        return (84);
    }
    if (read_and_write_client(client->data_fd, fd_file) != 0)
        return (84);
    close(client->data_fd);
    close(fd_file);
    client->data_fd = 0;
    client->states = undefined;
    read_server(client->fd);
    return (0);
}
