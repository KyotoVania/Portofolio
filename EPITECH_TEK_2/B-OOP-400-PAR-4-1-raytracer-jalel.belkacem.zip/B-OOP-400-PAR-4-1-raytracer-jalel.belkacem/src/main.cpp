/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** main.cpp
*/

#include <iostream>
#include "scene/scene_config.hpp"
#include "scene/render.hpp"
#include <iostream>
#include <fstream>
#include <vector>
#include <random>
#include <cmath>
#include <omp.h> // Add this include at the beginning of your file


int main(int argc, char *argv[]) {
    if (argc != 2) {
        std::cerr << "USAGE: ./raytracer <SCENE_FILE>" << std::endl;
        return 84;
    }

    const std::string scene_file = argv[1];
    SceneConfig scene_config;
    scene_config = scene_config.set_up_scene(scene_file);
    
    std::string outputFile = "output.ppm";
    int maxDepth = 5; // Adjustable recursion depth
    Render render;
    ProgressBar progressBar;
    render.addObserver(&progressBar);
    render.render_scene(scene_config, outputFile, maxDepth, 10);
    std::cout << "Image exported to " << outputFile << std::endl;

    return 0;
}
