/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** server.c
*/

#include "myftp.h"
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int server_functionhandler_filetransfer_split(
command_map_filetransfer commands, fd_node_t *tmp_node,
char *line, char *path)
{
    if (strncmp(line, commands.code,
        strlen(commands.code)) == 0) {
        if (commands.handler(tmp_node,
            line + strlen(commands.code) + 1, path) == 84)
            return (84);
        return 1;
    }
    return 0;
}

int server_functionhandler_filetransfer(fd_node_t *tmp_node,
char *line, char *path)
{
    int res = 0;
    command_map_filetransfer commands[] = {
            {"RETR", retrieve_file},
            {"STOR", store_file}
    };
    for (long unsigned int i = 0;
        i < sizeof(commands) / sizeof(command_map_filetransfer); i++) {
        res = server_functionhandler_filetransfer_split(commands[i],
        tmp_node, line, path);
        if (res == 84 || res == 1)
            return (res);
    }
    return 0;
}

int server_functionhandler_second(fd_node_t *tmp_node,
char *line, server_t *server)
{
    if (strncmp(line, "PORT", 4) == 0) {
        if (set_actv(tmp_node, server->ip, line + 5) == 84)
            return (84);
        return 1;
    }
    return 0;
}
