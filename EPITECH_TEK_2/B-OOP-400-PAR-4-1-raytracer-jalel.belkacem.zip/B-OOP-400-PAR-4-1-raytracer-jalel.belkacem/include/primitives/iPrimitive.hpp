/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** iPrimitive.hpp
*/
#ifndef iPrimitive_HPP_
	#define iPrimitive_HPP_
	#include "utils/shared.hpp"

class iPrimitive {
public:
	Vec3 color;
	Vec3 translation; // added translation vector
	float transparency;
	float refractiveIndex;
	bool castsShadow;
	bool enableReflection;
	bool enableTranslation;

	iPrimitive(const Vec3& color = Vec3(), const Vec3& translation = Vec3(), float transparency = 1.0f, bool castsShadow = true, bool enableReflection = false, float refractiveIndex = 1.0f)
		: color(color), translation(translation), transparency(transparency), castsShadow(castsShadow), enableReflection(enableReflection), refractiveIndex(refractiveIndex) {}

	virtual bool intersect(const Vec3& rayOrigin, const Vec3& rayDirection, float& t0, float& t1) const = 0;
	virtual const Vec3& getColor() const {
		return color;
	}
	virtual const Vec3& getTranslation() const { // added getTranslation method
		return translation;
	}
	virtual float gettransparency() const {
		return transparency;
	}
	virtual float getRefractiveIndex() const {
		return refractiveIndex;
	}
	virtual bool getEnableReflection() const {
		return enableReflection;
	}
};

#endif /*iPrimitive_HPP_*/
