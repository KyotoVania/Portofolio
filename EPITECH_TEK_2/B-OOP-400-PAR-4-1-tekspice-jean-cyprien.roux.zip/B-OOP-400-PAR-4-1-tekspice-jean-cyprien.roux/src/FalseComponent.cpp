/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** FalseComponent.cpp
*/
#include <exception>
#include "FalseComponent.hpp"
#include "IComponent.hpp"

nts::FalseComponent::FalseComponent()
{
    //we need to init it with a false value
}

nts::FalseComponent::~FalseComponent()
{
}

nts::Tristate nts::FalseComponent::compute(std::size_t pin)
{
    return nts::FALSE;
}

const std::vector<Pin> * nts::FalseComponent::getLinks () const
{
    return &links;
}

std::vector<Pin> * nts::FalseComponent::getLinks()
{
   return &links;
}

void nts::FalseComponent::display(std::ostream &os)
{
    os << "FalseComponent" << std::endl;
}