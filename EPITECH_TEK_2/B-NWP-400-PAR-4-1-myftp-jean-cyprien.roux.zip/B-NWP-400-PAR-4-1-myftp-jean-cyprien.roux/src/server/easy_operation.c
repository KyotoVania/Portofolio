/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** server.c
*/

#include "myftp.h"
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int noop_function(fd_node_t *tmp_node)
{
    if (send_client_line(tmp_node->fd,
    "200 NOOP command successful.\n") == 84)
        return (84);
    return 0;
}

int help_function(fd_node_t *tmp_node)
{
    char *message = NULL;
    asprintf(&message, "214-The following commands are recognized.\n "
    "cdup\n  pwd\n  user\n  smnt\n  noop \n  help\n  quit\n  "
    "rein\n  port\n  pasv\n  retr\n  stor\n");
    if (send_client_line(tmp_node->fd, message) == 84)
        return (84);
    return 0;
}
