/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** plane.hpp
*/
#ifndef PLANE_HPP_
	#define PLANE_HPP_
	#include "utils/shared.hpp"
	#include "primitives/iPrimitive.hpp"


class Plane : public iPrimitive {
public:
	Vec3 point;
	Vec3 normal;

	Plane() : iPrimitive(), point(Vec3()), normal(Vec3()) {}
	Plane(const Vec3& point, const Vec3& normal, const Vec3& color, const Vec3& translation = Vec3(), bool enableReflection = false) 
		: iPrimitive(color, translation, 1.0f, true, enableReflection), point(point), normal(normal) {}

	bool intersect(const Vec3& rayOrigin, const Vec3& rayDirection, float& t0, float& t1) const override {
		Vec3 translatedRayOrigin = rayOrigin - translation; // Apply translation
		float denom = normal.dot(rayDirection);
		if (std::abs(denom) > 1e-6) {
			Vec3 p0l0 = point - translatedRayOrigin;
			t0 = p0l0.dot(normal) / denom;
			t1 = t0;  // For a plane, the two intersection points are the same.
			if (t0 >= 0) {
				return true;
			}
		}
		return false;
	}
};

#endif /*PLANE_HPP_*/