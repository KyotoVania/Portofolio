/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** SubCircuit.hpp
*/
#ifndef SUBCIRCUIT_HPP_
	#define SUBCIRCUIT_HPP_

#include "InputComponent.hpp"
#include "OutputComponent.hpp"
#include "AndComponent.hpp"
#include "OrComponent.hpp"
#include "XorComponent.hpp"
#include "NotComponent.hpp"
#include "TrueComponent.hpp"
#include "FalseComponent.hpp"
#include "ClockComponent.hpp"
#include "Parsing.hpp"
#include "ProtectedComponent.hpp"
#include <iostream>


namespace nts {
    class SubCircuit : public nts::AComponent {
    public:
        SubCircuit(const std::string &file);
        ~SubCircuit();
        nts::Tristate compute(std::size_t pin);
        std::vector<Pin> * getLinks();
        const std::vector<Pin> * getLinks() const;
        void setStates(nts::Tristate state) {};
        void display(std::ostream &os);
        void parsing(std::string filename);
    protected:
    std::map<std::string, nts::AComponent *> _componentsMap;
    std::vector<Pin> links;
};
};

#endif /*SUBCIRCUIT_HPP_*/