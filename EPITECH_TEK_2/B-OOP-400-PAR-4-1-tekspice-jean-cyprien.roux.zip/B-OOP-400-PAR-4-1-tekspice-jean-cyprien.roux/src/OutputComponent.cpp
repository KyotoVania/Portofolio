/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** OutputComponent.cpp
*/

#include "OutputComponent.hpp"

nts::OutputComponent::OutputComponent()
{
    state = nts::UNDEFINED;
}

nts::OutputComponent::~OutputComponent()
{
}

nts::Tristate nts::OutputComponent::compute(std::size_t pin)
{
    if (pin == 1) {
        return getLink(1);
    }
    return nts::UNDEFINED;
}

void nts::OutputComponent::simulate(std::size_t tick)
{
    setStates(getLink(1));
}


const std::vector<Pin> * nts::OutputComponent::getLinks () const
{
    return &links;
}

std::vector<Pin> * nts::OutputComponent::getLinks()
{
    return &links;
}

void nts::OutputComponent::display(std::ostream &os)
{
    os << "OutputComponent" << std::endl;
}

void nts::OutputComponent::setStates(nts::Tristate state)
{
    this->state = state;
}