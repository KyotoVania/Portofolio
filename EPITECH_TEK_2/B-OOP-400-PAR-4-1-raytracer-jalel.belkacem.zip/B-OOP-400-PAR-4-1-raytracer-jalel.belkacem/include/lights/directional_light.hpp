/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** directional_light.hpp
*/
#ifndef DIRECTIONAL_LIGHT_HPP_
	#define DIRECTIONAL_LIGHT_HPP_
	#include "utils/shared.hpp"


class DirectionalLight {
public:
	Vec3 color;
	Vec3 direction;
	float intensity;

	DirectionalLight(const Vec3& color = Vec3(1, 1, 1), const Vec3& direction = Vec3(0, 0, -1), float intensity = 1.0f)
		: color(color), direction(direction.normalized()), intensity(intensity) {}
};


#endif /*DIRECTIONAL_LIGHT_HPP_*/