/*
** EPITECH PROJECT, 2023
** B-CCP-400-PAR-4-1-theplazza-titien.carellas
** File description:
** Cook.cpp
*/

#include "Chef.hpp"


Chef::Chef() : _mutex(std::make_shared<std::mutex>()), _id(0), _timeMultiplier(1),  _cv(std::make_shared<std::condition_variable>()) {}

Chef::Chef(int id, int timeMultiplier)
    : _id(id), _timeMultiplier(timeMultiplier), _pizza(nullptr), _isReady(false), _isBusy(false), _mutex(std::make_shared<std::mutex>()), _cv(std::make_shared<std::condition_variable>())
{
    std::cout << "Chef " << _id << " created" << std::endl;
}

Chef::~Chef() {}

void Chef::cookPizza(Pizza * pizza)
{
    int randval = rand() % 50 + 50;
    std::this_thread::sleep_for(std::chrono::milliseconds(randval * _timeMultiplier));
    std::cout << "Pizza " << pizza->getNameString() << " size " << pizza->getSizeString() << " cooked by chef " << _id << std::endl;
    _isBusy = false;
}

void Chef::run()
{
    try {
        std::cout << " Chef " << _id << " is ready" << std::endl;
        std::cout << " Chef " << _id << " is waiting for a command" << std::endl;
        _isReady = false;
        
        while (true)
        {
            if (_isBusy) {
                std::cout << "Chef " << _id << " is cooking a " << _pizza->getNameString() << " size " << _pizza->getSizeString() << std::endl;
                cookPizza(_pizza);
                _pizza = nullptr;
                _isBusy = false;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
    }
    catch (const std::exception &e) {
        std::cerr << "Exception in Chef::run(): " << e.what() << std::endl;
    }
    catch (...) {
        std::cerr << "Unknown exception in Chef::run()" << std::endl;
    }
}


bool Chef::isReady() {
    //std::lock_guard<std::mutex> lock(_myMutex);  // use the chef's mutex
    return _isReady;
}
bool Chef::isBusy() {
    return _isBusy;
}
void Chef::setPizza(Pizza* pizza) {
        if (_isBusy) {
            std::cout << "Chef " << _id << " is busy" << std::endl;
            return;
        }
        std::cout << "Chef " << _id << " is taking a " << pizza->getNameString() << " size " << pizza->getSizeString() << std::endl;
        _pizza = pizza;
        _isBusy = true;
    }