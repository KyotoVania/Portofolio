/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** Parsing.cpp
*/

#include "Parsing.hpp"

#include <iostream>

template<typename Base, typename T>
inline bool instanceof(const T *ptr) {
    return dynamic_cast<const Base*>(ptr) != nullptr;
}


Parsing::Parsing()
{
}

Parsing::Parsing(const std::string file_name, std::map<std::string, nts::AComponent *> &componentsMap)
{
    this->file_name = file_name;

    parseFile(componentsMap);
}

bool Parsing::isComponentValid(const std::string &component, std::map<std::string, nts::AComponent *> &componentsMap)
{
    for (auto &valid_component : componentsMap) {
        if (valid_component.first == component)
            return true;
    }
    std::cout << "Unknow component name '" << component << "'" << std::endl;
    return false;
}

bool Parsing::isArealComponent(const std::string &component)
{
    for (auto &valid_component : valid_components) {
        if (valid_component == component)
            return true;
    }
    printf("Unknow component name '%s' ", component.c_str());
    return false;
}

bool Parsing::checkLink(const std::string &link, std::map<std::string, nts::AComponent *> &componentsMap)
{

    std::string component1;
    std::string component2;
    std::string pin1;
    std::string pin2;
    std::size_t pos = 0;
    std::size_t pos2 = 0;
    

    if (componentsMap.size() == 0)
        exit(84);
    pin1 = link.substr(link.find(":") + 1, link.find(" ") - link.find(":") - 1);
    component1 = link.substr(0, link.find(":"));
    if (component1 == "") {
        std::cout << "Missing component name in link '" << link << "'" << std::endl;
        return false;
    }
    if (pin1 == "") {
        std::cout << "Missing pin number in link '" << link << "'" << std::endl;
        return false;
    }
    pin2 = link.substr(link.find(":", link.find(":") + 1) + 1, link.size());
    if (pin2 == "") {
        std::cout << "Missing pin number in link '" << link << "'" << std::endl;
        return false;
    }
    component2 = link.substr(link.find(" ") + 1, link.find(":", link.find(":") + 1) - link.find(" ") - 1);
    if (component2 == "") {
        std::cout << "Missing component name in link '" << link << "'" << std::endl;
        return false;
    }
    if (isComponentValid(component1, componentsMap) && isComponentValid(component2, componentsMap)) {
        return true;
    }
    //check if the pin number is valid and not out of range
    return false;
}


Parsing::~Parsing()
{
}

void Parsing::parseFile(std::map<std::string, nts::AComponent *> &_componentsMap)
{
    std::ifstream file(file_name);
    std::string line;
    std::string chipsets;
    std::string links;
    std::pair<std::string, std::size_t> tmp;
    std::pair<std::string, std::size_t> tmp2;
    //Check if file is empty
    if (file.peek() == std::ifstream::traits_type::eof()) {
        std::cout << "File is empty" << std::endl;
        exit(84);
    }

    if (file.is_open()) {
        while (getline(file, line)) {
            if (line == ".chipsets:") {
                while (getline(file, line)) {
                    if (line == ".links:")
                        break;
                    //check if the line start with input
                    if (line.find("input") != std::string::npos) {
                        _componentsMap[line.substr(6, line.size())] =  new nts::InputComponent();
                    }
                    //check if the line start with output
                    if (line.find("output") != std::string::npos) {
                        _componentsMap[line.substr(7, line.size())] =  new nts::OutputComponent();
                    }
                    //check if the line start with or
                    if (line.find("or") != std::string::npos) {
                        _componentsMap[line.substr(3, line.size())] = new nts::OrComponent();
                    }
                    //check if the line start with and
                    if (line.find("and") != std::string::npos) {
                        _componentsMap[line.substr(4, line.size())] = new nts::AndComponent();
                    }
                    if (line.find("nand") != std::string::npos) {
                        _componentsMap[line.substr(5, line.size())] = new nts::NandComponent();
                    }
                    //check if the line start with nor
                    if (line.find("nor") != std::string::npos) {
                        _componentsMap[line.substr(4, line.size())] = new nts::NorComponent();
                    }
                    //check if the line start with not
                    if (line.find("not") != std::string::npos) {
                        _componentsMap[line.substr(4, line.size())] = new nts::NotComponent();
                    }
                    //check if the line start with xor
                    if (line.find("xor") != std::string::npos) {
                        _componentsMap[line.substr(4, line.size())] = new nts::XorComponent();
                    }
                    //check if the line start with clock
                    if (line.find("clock") != std::string::npos) {
                        _componentsMap[line.substr(6, line.size())] = new nts::ClockComponent();
                    }
                    if (line.find("4001") != std::string::npos) {
                        _componentsMap[line.substr(5, line.size())] = new nts::SubCircuit("4001");
                    }
                    if (line.find("4011") != std::string::npos) {
                        _componentsMap[line.substr(5, line.size())] = new nts::SubCircuit("4011");
                    }
                    if (line.find("4030") != std::string::npos) {
                        _componentsMap[line.substr(5, line.size())] = new nts::SubCircuit("4030");
                    }
                    if (line.find("4069") != std::string::npos) {
                        _componentsMap[line.substr(5, line.size())] = new nts::SubCircuit("4069");
                    }
                    if (line.find("4071") != std::string::npos) {
                        _componentsMap[line.substr(5, line.size())] = new nts::SubCircuit("4071");
                    }
                    if (line.find("4081") != std::string::npos) {
                        _componentsMap[line.substr(5, line.size())] = new nts::SubCircuit("4081");
                    }
                    //check if the line start with true
                    if (line.find("true") != std::string::npos) {
                        _componentsMap[line.substr(5, line.size())] = new nts::TrueComponent();
                    }
                    //check if the line start with false
                    if (line.find("false") != std::string::npos) {
                        _componentsMap[line.substr(6, line.size())] = new nts::FalseComponent();
                    }
                    if (line.size() != 0 )
                    {
                        tmp.first = line.substr(0, line.find(" "));
                        if (isArealComponent(tmp.first) == false)
                        {
                            std::cout << "Invalid component name '" << tmp.first << "'" << std::endl;
                            exit(84);
                        }
                    }
                }
            }
            if (line == ".links:") {
                while (getline(file, line)) {
                    if (checkLink(line, _componentsMap) == false)
                        exit(84);
                    tmp.first = line.substr(0, line.find(":"));
                    tmp.second = std::stoi(line.substr(line.find(":") + 1, line.find(" ")));
                    tmp2.first = line.substr(line.find(" ") + 1, line.find(":", line.find(":") + 1) - line.find(" ") - 1);
                    tmp2.second = std::stoi(line.substr(line.find(":", line.find(":") + 1) + 1, line.size()));

                    if (isComponentValid(tmp.first, _componentsMap) == false || isComponentValid(tmp2.first, _componentsMap) == false)
                        exit(84);
                    //check if in the link there is an output or an input and set the link
                    if (instanceof<nts::OutputComponent>(_componentsMap[tmp.first]) == true) {
                        _componentsMap[tmp.first]->setLink(tmp.second, *_componentsMap[tmp2.first], tmp2.second);
                    } else if (instanceof<nts::InputComponent>(_componentsMap[tmp.first]) == true) {                      
                        _componentsMap[tmp2.first]->setLink(tmp2.second, *_componentsMap[tmp.first], tmp.second);
                    } else if (instanceof<nts::OutputComponent>(_componentsMap[tmp2.first]) == true) {
                        _componentsMap[tmp2.first]->setLink(tmp2.second, *_componentsMap[tmp.first], tmp.second);
                    } else if (instanceof<nts::InputComponent>(_componentsMap[tmp2.first]) == true) {
                        _componentsMap[tmp.first]->setLink(tmp.second, *_componentsMap[tmp2.first], tmp2.second);
                    } else {
                        _componentsMap[tmp.first]->setLink(tmp.second, *_componentsMap[tmp2.first], tmp2.second);
                        _componentsMap[tmp2.first]->setLink(tmp2.second, *_componentsMap[tmp.first], tmp.second);
                    }
                }
            }
        }
    }
    file.close();

}


