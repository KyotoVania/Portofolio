/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-tekspice-jean-cyprien.roux
** File description:
** Class
*/
#ifndef CIRCUIT_HPP_
	#define CIRCUIT_HPP_

#include "InputComponent.hpp"
#include "OutputComponent.hpp"
#include "AndComponent.hpp"
#include "NandComponent.hpp"
#include "OrComponent.hpp"
#include "XorComponent.hpp"
#include "NotComponent.hpp"
#include "TrueComponent.hpp"
#include "FalseComponent.hpp"
#include "ClockComponent.hpp"

#include "Parsing.hpp"

#include "SubCircuit.hpp"
#include <iostream>


// this is the class that will contain all the components
class Circuit {
    public:
        Circuit(const std::string &file);
        ~Circuit();
        void simulate();
        void display();
        void loop();
        void setValue(const std::string name, const std::string value);
        std::size_t getTick() const;
    protected:
    std::map<std::string, nts::AComponent *> _componentsMap;
    std::size_t _tick = 0;
    private:
};

#endif /*CIRCUIT_HPP_*/


