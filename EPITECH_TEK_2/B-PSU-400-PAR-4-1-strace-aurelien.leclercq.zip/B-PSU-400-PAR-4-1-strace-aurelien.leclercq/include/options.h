/*
** EPITECH PROJECT, 2023
** Strace
** File description:
** option.h
*/

#ifndef OPTION_H_
    #define OPTION_H_
    #include <sys/types.h>

    typedef struct {
        int s_option;
        int p_option;
        pid_t pid;
    } options_t;

options_t parse_options(int argc, char **argv);

#endif /*OPTION_H_*/
