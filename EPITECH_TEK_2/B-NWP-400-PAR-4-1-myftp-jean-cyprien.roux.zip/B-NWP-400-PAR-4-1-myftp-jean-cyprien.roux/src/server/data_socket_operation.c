/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** data_socket_operation.c
*/

#include "myftp.h"

int check_if_option_set(fd_node_t *node)
{
    int optval;
    socklen_t optlen = sizeof(optval);

    if (getsockopt(node->data_fd, SOL_SOCKET, SO_REUSEADDR,
    &optval, &optlen) < 0) {
        perror("getsockopt(SO_REUSEADDR) failed");
        return (84);
    }
    return (0);
}
