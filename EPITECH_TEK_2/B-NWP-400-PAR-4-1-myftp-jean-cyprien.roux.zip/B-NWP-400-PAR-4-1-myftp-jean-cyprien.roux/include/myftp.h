/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** myftp.h
*/
#ifndef MYFTP_H_
    #define MYFTP_H_
    #define _GNU_SOURCE
    #include "server.h"
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <unistd.h>
    #include <sys/types.h>
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <arpa/inet.h>
    #include <stdbool.h>
    #include <dirent.h>
    #include <sys/stat.h>
    #include <fcntl.h>
    #include <time.h>

typedef int (*command_handler)(fd_node_t *tmp_node, char *line);
typedef int (*command_handler_easy)(fd_node_t *tmp_node);
typedef int (*command_handler_servers_args)(fd_node_t *tmp_node,
        server_t *server);
typedef int (*command_handler_filetransfer)
(fd_node_t *tmp_node, char *line, char *path);

typedef struct {
    char* code;
    command_handler handler;
} command_map;

typedef struct {
    char* code;
    command_handler_easy handler;
} command_map_easy;

typedef struct {
    char* code;
    command_handler_servers_args handler;
} command_map_server_args;

typedef struct {
    char* code;
    command_handler_filetransfer handler;
} command_map_filetransfer;

int read_and_write(int read_fd, int write_fd);
char *get_last_path(char *path);
int server_functionhandler_easy(fd_node_t *tmp_node, char *line);
int server_functionhandler_first(fd_node_t *tmp_node, char *line);
int server_functionhandler_second(fd_node_t *tmp_node, char *line,
    server_t *server);
int server_functionhandler_filetransfer(fd_node_t *tmp_node,
    char *line, char *path);
int server_functionhandler_server_args(fd_node_t *tmp_node,
    char *line, server_t *server);
int server_functionhandler(fd_node_t *tmp_node,
    fd_set readfds, server_t *server);
#endif /*MYFTP_H_*/
