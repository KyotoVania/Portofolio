#include "Kitchen.hpp"

Kitchen::Kitchen(int id, int nbChef, int timeMultiplier, commu_t* sharedMemory)
    : _id(id),
      _nbChef(nbChef),
      _timeMultiplier(timeMultiplier),
      _isFull(false),
      _isClosed(false),
      _isBusy(false),
      _pizzas(),
      _maxPizza(nbChef),
      _mutex(std::make_shared<std::mutex>()),
      _cv(std::make_shared<std::condition_variable>()),
      _cvAddCommand(std::make_shared<std::condition_variable>()),
      _sharedMemory(sharedMemory),
        _numReadyChefs(0)
{
    std::cout << "Kitchen " << _id << " created with " << _nbChef << " chefs. The available space is " << this->getAvailableSpace() << std::endl;
    
    for (int i = 0; i < nbChef; i++) {
        auto chef = std::make_shared<Chef>(i + 1, _timeMultiplier);
        _chefs.push_back(chef);
        //detach the thread
        _chefThreads.push_back(std::thread([this, chef](){
            {
                std::unique_lock<std::mutex> lock(this->_readyMutex);
                this->_numReadyChefs++;
                std::cout << "Kitchen " << _id << " chef " << chef->getId() << " is ready. nbReadyChefs = " << this->_numReadyChefs << std::endl;
                if (this->_numReadyChefs == this->_nbChef) {
                    this->_allChefsReady.notify_all();  // Notify the main thread
                }
            }
            chef->run();
        }));
    }

    // Wait for all chefs to be ready
    std::unique_lock<std::mutex> lock(this->_readyMutex);
    this->_allChefsReady.wait(lock, [this, nbChef] { return this->_numReadyChefs == nbChef; });
    std::cout << "Kitchen " << _id << " is now ready" << std::endl;
    //detach the thread
}

Kitchen::~Kitchen() {
    for (auto& thread : _chefThreads) {
        if (thread.joinable()) {
            thread.join();
        }
    }
    shmdt(_sharedMemory);
}

    void Kitchen::run()
    {
        while (true) {
            std::cout << "Kitchen " << _id << " is waiting for a command" << std::endl;
		    sem_wait(&_sharedMemory->sem);
            //sleep 
            //std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            if (_sharedMemory->_commandAdded) { // Check if a command was added
                _sharedMemory->_commandAdded = false; // Reset the flag after handling the command
			    handleDetectedCommand();
                std::cout << "Kitchen " << _id << " has received a command size : " << _pizzas.size() << std::endl;
                if (_isClosed) break;
                while (!_pizzas.empty()) {
				    std::cout << "Kitchen " << _id << "is starting to cook a : " << pizzaTypeMap[_pizzas.front()->getType()] << std::endl;
                    // find a free chef
                    for (auto& chef : _chefs) {
                        if (!chef->isBusy()) {
                            std::cout << "Kitchen " << _id << " is giving a pizza to chef " << chef->getId() << std::endl;
                            auto pizza = _pizzas.front(); // Get the pizza from the front of the queue
                            _pizzas.pop(); // Remove the pizza from the queue
                            chef->setPizza(pizza); // Assign the pizza to the chef
                            break;
                        }
                    }
                }
                _sharedMemory->_commandProcessed = true;
            }
            else {
                std::cout << "Kitchen " << _id << "No command available, will go to sleep for 100 msec" << std::endl;
            }
        }
    }

    void Kitchen::receiveOrder(Command order){
        if (isFull()) {
            throw std::runtime_error("Kitchen is at full capacity.");
        } else {
		    //we need to modifie the shared space to make sure that we modify the child process and not the parent process when
            addCommand(order);
        }
    }

    void Kitchen::addCommand(Command command) {

	    //debug part
	    //std::queue<std::shared_ptr<Pizza>> commandPizzas = _sharedMemory->_order->getPizzas();
        std::cout << "Kitchen when addCommand " << _id << " is starting to detect command" << std::endl;
	    std::cout << "addCommand from split command conntaing " << _sharedMemory->number << std::endl;
        _cvAddCommand->notify_all();
        std::cout << "Kitchen " << _id << " addCommand notified" << std::endl;

    }

    void Kitchen::handleDetectedCommand()
    {
        std::unique_lock<std::mutex> lock(*_mutex);
        std::cout << "handleDetectedCommand from split command containing " << _sharedMemory->number << std::endl;

        PizzaType pizzaType = _sharedMemory->type;
        PizzaSize pizzaSize = _sharedMemory->size;
        int pizzaNumber = _sharedMemory->number;

        std::cout << "Kitchen " << _id << " is starting to detect command" << std::endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(1000)); // 1 second delay
        // Create a pizza and add it to the _pizzas queue based on the information from _sharedMemory
        for (int i = 0; i < pizzaNumber; ++i) {
            Pizza* pizza = new Pizza(pizzaType, pizzaSize);
            _pizzas.push(pizza);
        }
    }
