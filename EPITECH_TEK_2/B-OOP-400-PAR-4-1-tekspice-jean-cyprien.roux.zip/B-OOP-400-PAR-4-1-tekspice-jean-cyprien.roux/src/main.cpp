/*
** EPITECH PROJECT, 2023
** B_OOP_400_PAR_4_1_tekspice_jean_cyprien_roux
** File description:
** main.cpp
*/

#include "IComponent.hpp"
#include "AndComponent.hpp"
#include "FalseComponent.hpp"
#include "TrueComponent.hpp"
#include "NotComponent.hpp"
#include "XorComponent.hpp"
#include "OrComponent.hpp"
#include "InputComponent.hpp"
#include "OutputComponent.hpp"
#include "Circuit.hpp"
#include "test.hpp"
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <csignal>
#include <unistd.h>


int main_project (int argc, char* argv[])
{
    if (argc != 2)
        return 84;
    //check if argv[1] is a file and if it's a valid file
    if (access(argv[1], F_OK) == -1)
        return 84;
    std::string file = argv[1];
    Circuit circuit(file);
    circuit.loop();
    return 0;
}


int main(int ac, char **av)
{

    if (ac == 1) {
        return 84;
    }
    else
        main_project(ac, av);
    // start of the project
     return 0;
}