/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** basic_operation.cpp
*/

#include "myftp.h"

server_t *init_server(int port, char *home_dir)
{
    server_t *server = malloc(sizeof(server_t));
    time_t t;
    srand((unsigned) time(&t));

    if (server == NULL)
        return (NULL);
    server->port = port;
    server->fd = 0;
    server->home_dir = home_dir;
    server->client_count = 0;
    server->client_fds = NULL;
    server->s_in.sin_family = AF_INET;
    server->s_in.sin_port = htons(port);
    server->s_in.sin_addr.s_addr = INADDR_ANY;
    server->ip = inet_ntoa(server->s_in.sin_addr);
    return (server);
}

char * read_client_line_loop(fd_node_t *node, int size)
{
    char *newline = NULL;

    while (node->buffer_pos < node->buffer_size) {
        if ((size = read(node->fd, node->buffer + size,
        node->buffer_size)) == -1)
            return (NULL);
        newline = strchr(node->buffer, '\n');
        if (newline != NULL)
            break;
        node->buffer_pos += size;
        node->buffer[node->buffer_pos] = '\0';
    }
    *newline = '\0';
    return (newline);
}

char *read_client_line(fd_node_t *node)
{
    int size = 0;
    char *line = NULL;
    char *newline = NULL;

    newline = read_client_line_loop(node, size);
    if (newline == NULL)
        return (NULL);
    line = strdup(node->buffer);
    size_t length = newline - node->buffer;
    line[length] = '\0';
    memmove(node->buffer, node->buffer
    + node->buffer_pos, newline - node->buffer + 1);
    printf("%s \n", node->buffer);
    return (line);
}

int send_client_line(int client_fd, char *msg)
{
    printf("send to client: %d %s \n", client_fd, msg);
    if (write(client_fd, msg, strlen(msg)) == -1){
        perror("write failed");
        return (84);
    }
    return (0);
}
