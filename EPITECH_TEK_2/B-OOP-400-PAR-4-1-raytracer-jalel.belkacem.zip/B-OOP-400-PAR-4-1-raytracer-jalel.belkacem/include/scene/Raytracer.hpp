/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** Raytracer.hpp
*/
#ifndef RAYTRACER_HPP_
	#define RAYTRACER_HPP_
	#include "utils/shared.hpp"
	#include "scene/Scene.hpp"

class Raytracer {
public:
	Raytracer(const SceneConfig& sceneConfig);
	~Raytracer();

	void render();

private:
	SceneConfig _sceneConfig;
};


#endif /*RAYTRACER_HPP_*/