/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** main.c
*/

#include "client.h"

int main(int ac, char **av)
{
    (void)ac;
    client_t client;
    if (create_client(&client, av[1], atoi(av[2])) == 84)
        return (84);
    if (connect_to_server(&client) == 84)
        return (84);
    printf("starting client loop fd %d \n", client.fd);
    client_loop(&client);
    close(client.fd);
    return (0);
}
