/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** cylinder.hpp
*/
#ifndef CYLINDER_HPP_
	#define CYLINDER_HPP_
	#include "utils/shared.hpp"
//handle later
class Cylinder
{
	public:
	Cylinder();
	~Cylinder();
	//	void setPos(Position pos);
	//	void setRadius(float radius);
	//	void setColor(Color color);
	private:
	Position _pos;
	float _radius;
	FlatColor _color;
};

#endif /*CYLINDER_HPP_*/