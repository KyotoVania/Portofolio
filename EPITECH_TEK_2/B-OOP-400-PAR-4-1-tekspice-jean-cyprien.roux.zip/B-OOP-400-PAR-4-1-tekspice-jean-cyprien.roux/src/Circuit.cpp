/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** Circuit.cpp
*/

#include "Circuit.hpp"
#include <regex>
#include <iostream>
#include <csignal>
#include <unistd.h>

template<typename Base, typename T>
inline bool instanceof(const T *ptr) {
    return dynamic_cast<const Base*>(ptr) != nullptr;
}

sig_atomic_t sigintReceived = 0;
int mainLoop = 0;
//signal handler
void signal_handler(int signum)
{
    sigintReceived = 1;
    if (mainLoop == 0)
        exit(0);
}

std::ostream &operator<<(std::ostream &os, nts::Tristate state)
{
    switch (state) {
        case nts::Tristate::UNDEFINED:
            os << "U";
            break;
        case nts::Tristate::TRUE:
            os << "1";
            break;
        case nts::Tristate::FALSE:
            os << "0";
            break;
    }
    return os;
}

Circuit::Circuit(const std::string &file)
{
    Parsing p(file, this->_componentsMap);
    //_components = p.getComponents();
}


Circuit::~Circuit()
{
}

std::size_t Circuit::getTick() const
{
    return _tick;
}

void Circuit::simulate()
{
    _tick++;
    for (auto &it : _componentsMap) {
		it.second->simulate(_tick);
    }
}

void Circuit::display()
{
    std::cout << "tick: " << _tick << std::endl;
    std::cout << "input(s):" << std::endl;
    for (auto &it : _componentsMap) {
        if (instanceof<nts::ClockComponent>(it.second)) {
            std::cout << "  " << it.first << ": " << it.second->compute(1) << std::endl;
        }
        if (instanceof<nts::InputComponent>(it.second)) {
            std::cout << "  " << it.first << ": " << it.second->compute(1) << std::endl;
        }
    }
    //or 4071 debug
    /*
    std::cout << "debug : " << std::endl;
    for (auto &it : _componentsMap) {
        if (instanceof<nts::SubCircuit>(it.second)) {
            //4071 style
            std::cout << "\t" << it.first << ": \n" << it.second->getLink(3) <<"\t" << it.second->getLink(2) << "\t" << it.second->getLink(1) << std::endl;
            std::cout << "\t" << it.first << ": \n" << it.second->getLink(6) <<"\t" << it.second->getLink(5) << "\t" << it.second->getLink(4) << std::endl;
            std::cout << "\t" << it.first << ": \n" << it.second->getLink(10) <<"\t" << it.second->getLink(9) << "\t" << it.second->getLink(8) << std::endl;
            std::cout << "\t" << it.first << ": \n" << it.second->getLink(13) <<"\t" << it.second->getLink(12) << "\t" << it.second->getLink(11) << std::endl;
            //4069 style
            std::cout << "\t" << it.first << ": \n" << it.second->getLink(1) <<"\t" << it.second->compute(2) << std::endl;
            std::cout << "\t" << it.first << ": \n" << it.second->getLink(3) <<"\t" <<  it.second->compute(4) << std::endl;
            std::cout << "\t" << it.first << ": \n" << it.second->getLink(5) <<"\t" <<  it.second->compute(6) << std::endl;
            std::cout << "\t" << it.first << ": \n" << it.second->getLink(9) <<"\t" ;
            std::cout << it.second->compute(8) << std::endl;
            std::cout << "\t" << it.first << ": \n" << it.second->getLink(11) <<"\t" << it.second->compute(10) << std::endl;
            std::cout << "\t" << it.first << ": \n" << it.second->getLink(13) <<"\t" <<  it.second->compute(12) << std::endl;
        }
    }
    */
    std::cout << "output(s):" << std::endl;
    for (auto &it : _componentsMap) {
        if (instanceof<nts::OutputComponent>(it.second)) {
            std::cout << "  " << it.first << ": "
                      << it.second->compute(1) << std::endl;
        }
    }
}

void Circuit::loop()
{
    
    signal(SIGINT, signal_handler);
    
    std::string input;
    std::cout << "> ";
    while (getline(std::cin, input))
    {
        if (input == "exit")
            break;
        if (input.find("=") != std::string::npos){
            std::string const name = input.substr(0, input.find("="));
            std::string const value = input.substr(input.find("=") + 1, input.size());
            this->setValue(name, value);
        }
        if (input == "simulate")
        {
            this->simulate();
            //circuit.display();
        }
        if (input == "display")
        {
            this->display();
        }
        if (input == "loop")
        {
            this->simulate();
            this->display();
            mainLoop = 1;
            while (1)
            {
                //check if ctrl+c is pressed
                if (sigintReceived == 1)
                {
                    sigintReceived = 0;
                    mainLoop = 0;
                    break;
                }
                this->simulate();
                this->display();
                sleep(1);
            }
        }
        if (input == "loopQuiet")
        {
            this->simulate();
            mainLoop = 1;
            while (1)
            {
                //check if ctrl+c is pressed
                if (sigintReceived == 1)
                {
                    sigintReceived = 0;
                    mainLoop = 0;
                    break;
                }
                //sleep(1);
                this->simulate();
            }
        }
        if (input == "help")
        {
            std::cout << "exit" << std::endl;
            std::cout << "simulate" << std::endl;
            std::cout << "display" << std::endl;
            std::cout << "loop" << std::endl;
            std::cout << "loopQuiet" << std::endl;
            std::cout << "input" << std::endl;
            std::cout << "help" << std::endl;
        }
        std::cout << "> ";
    }
}

void Circuit::setValue(const std::string name, const std::string value)
{
    //check if there is a component with this name
    std::string name_clean = name;
    std::string value_clean = value;
    name_clean.erase(std::remove_if(name_clean.begin(), name_clean.end(), ::isspace), name_clean.end());
    value_clean.erase(std::remove_if(value_clean.begin(), value_clean.end(), ::isspace), value_clean.end());
    for (const auto& pair : _componentsMap) {
        if (pair.first == name_clean)
            goto next;
    }
    throw std::invalid_argument("No component with this name");
next:
    for (const auto& pair : _componentsMap) {
        if (instanceof<nts::ClockComponent>(pair.second)) {
            if (pair.first == name_clean)
                goto next2;
        }
        if (instanceof<nts::InputComponent>(pair.second)) {
            if (pair.first == name_clean)
                goto next2;
        }
    }
    throw std::invalid_argument("This component is not an input or a clock");
next2:
    if (value_clean == "1")
        _componentsMap[name_clean]->setStates(nts::TRUE);
    else if (value_clean == "0")
        _componentsMap[name_clean]->setStates(nts::FALSE);
    else if (value_clean == "U")
        _componentsMap[name_clean]->setStates(nts::UNDEFINED);
    else
        throw std::invalid_argument("Invalid value");
}
