/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** passive_mode.c
*/

#include "client.h"

int connect_toserver_passive(char *ip, int port, client_t *client)
{
    if (client->data_fd != 0)
        close(client->data_fd);
    client->data_fd = socket(AF_INET, SOCK_STREAM, 0);
    client->data_addr.sin_family = AF_INET;
    client->data_addr.sin_port = htons(port);
    client->data_addr.sin_addr.s_addr = inet_addr(ip);
    client->ip = strdup(ip);
    client->data_port = port;
    client->data_addr_len = sizeof(client->data_addr);
    client->states = is_passive;
    if (connect(client->data_fd,
        (const struct sockaddr *)&client->data_addr,
        client->data_addr_len) == -1){
        perror("connect");
        return (84);
    }
    printf("Connected to server %s:%d in passive mode !\n", ip, port);
    return ( 0);
}

int parse_ip_port_from_pasv_response_sub_sub(char **ip, char **tok)
{
    *ip = strdup(*tok);
    for (int i = 0; i < 3; i++) {
        *tok = strtok(NULL, ",");
        if (*tok == NULL) {
            free(*ip);
            return -1;
        }
        *ip = strcat(*ip, ".");
        *ip = strcat(*ip, *tok);
    }
    *tok = strtok(NULL, ",");
    if (*tok == NULL) {
        free(*ip);
        return -1;
    }
    return 0;
}

int parse_ip_port_from_pasv_response_sub(char **end,
char **tok, char **ip, char *msg)
{
    char *start = strchr(msg, '(');
    if (start == NULL)
        return -1;
    start++;
    (*end) = strchr(start, ')');
    if ((*end) == NULL) {
        return -1;
    }
    (**end) = '\0';
    *tok = strtok(start, ",");
    if (*tok == NULL)
        return -1;
    if (parse_ip_port_from_pasv_response_sub_sub(ip, tok) != 0)
        return -1;
    return 0;
}

int parse_ip_port_from_pasv_response_port(char *tok, int port)
{
    int port1 = 0;
    int port2 = 0;
    port1 = atoi(tok);
    tok = strtok(NULL, ",");
    if (tok == NULL) {
        return -1;
    }
    port2 = atoi(tok);
    port = port1 * 256 + port2;
    return port;
}
