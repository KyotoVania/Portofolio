/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-tekspice-jean-cyprien.roux
** File description:
** AComponent
*/
#ifndef ACOMPONENT_HPP_
#define ACOMPONENT_HPP_

#include "IComponent.hpp"
#include "PinComponent.hpp"


namespace nts {
    class AComponent : public nts::IComponent {
    public:
        AComponent();
        ~AComponent();
        virtual nts::Tristate compute(std::size_t pin ) = 0;
        void simulate(std::size_t tick) ;
        nts::Tristate getLink(std::size_t pin) const;
        void setLink(std::size_t pin, IComponent &other,
                     std::size_t otherPin);
        virtual const std::vector<Pin> * getLinks() const = 0;
        virtual std::vector<Pin> * getLinks() = 0;
        virtual void display(std::ostream &os) = 0;
        virtual void setStates(nts::Tristate state) = 0;
        friend std::ostream& operator<<(std::ostream& os, AComponent& component) {
            component.display(os);
            return os;
        }
        //compute method pure virtual
    };
};

#endif /*ACOMPONENT_HPP_*/