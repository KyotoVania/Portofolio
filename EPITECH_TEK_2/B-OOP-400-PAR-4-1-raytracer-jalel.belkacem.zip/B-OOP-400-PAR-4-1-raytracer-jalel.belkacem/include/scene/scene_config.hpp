/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** scene_config.hpp
*/
#ifndef SCENE_CONFIG_HPP_
	#define SCENE_CONFIG_HPP_
#include "utils/shared.hpp"
#include <iostream>
#include <vector>
#include "camera.hpp"
#include "primitives/sphere.hpp"
#include "primitives/plane.hpp"
#include "lights/ambient_light.hpp"
#include "lights/directional_light.hpp"
#include "lights/pointLight.hpp"


class SceneConfig {
public:
	SceneConfig() : _camera(90.0f, 1.0f) {}
	SceneConfig set_up_scene(const std::string& scene_file);
    SceneConfig(int width, int height) : _camera(90.0f, float(width) / float(height)) {_width = width, _height = height;}
	~SceneConfig();
	
	// Getter methods for camera, primitives, and lights
	Camera getCamera() const;
	std::vector<Sphere> getSpheres() const;
	std::vector<Plane> getPlanes() const;
	AmbientLight getAmbientLight() const;
	std::vector<DirectionalLight> getDirectionalLights() const;
	void parseCamera(const libconfig::Setting &cameraConfig);
	void parsePrimitives(const libconfig::Setting &primitivesConfig);
	void parseLights(const libconfig::Setting &lightsConfig);
	bool parseSceneConfig(const std::string &filename);
	void adjustRgbValues(Vec3& color);
	int _width;
	int _height;
	std::vector<Sphere> _spheres;
	std::vector<Plane> _planes;
	AmbientLight _ambientLight;
	std::vector<DirectionalLight> _directionalLights;
	Camera _camera;
	std::vector<pointLight> _pointLights;
	private:
};
#endif /*SCENE_CONFIG_HPP_*/