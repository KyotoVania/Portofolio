/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** server.c
*/

#include "myftp.h"
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int server_functionhandler_split_split(fd_node_t *tmp_node,
char *line, server_t *server)
{
    int res = 0;

    res = server_functionhandler_easy(tmp_node, line);
    if (res == 84 || res == 1)
        return (res);
    res = server_functionhandler_filetransfer(tmp_node,
    line, server->home_dir);
    if (res == 84 || res == 1)
        return (res);
    return (0);
}

int server_functionhandler_split(fd_node_t *tmp_node,
char *line, server_t *server)
{
    int res = 0;

    res = server_functionhandler_first(tmp_node, line);
    if (res == 84 || res == 1)
        return (res);
    res = server_functionhandler_second(tmp_node, line, server);
    if (res == 84 || res == 1)
        return (res);
    res = server_functionhandler_split_split(tmp_node, line, server);
    if (res == 84 || res == 1)
        return (res);
    res = server_functionhandler_server_args(tmp_node, line, server);
    if (res == 84 || res == 1)
        return (res);
    return (0);
}

int server_functionhandler(fd_node_t *tmp_node,
fd_set readfds, server_t *server)
{
    int res = 0;

    if (FD_ISSET(tmp_node->fd, &readfds)) {
        char *line = read_client_line(tmp_node);
        if (strncmp(line, "QUIT", 4) == 0)
            close_client(tmp_node->fd, server);
        res = server_functionhandler_split(tmp_node, line, server);
        if (res == 1 || res == 84)
            return (res);
        if (send_client_line(tmp_node->fd,
            "500 Unknown command.\n") == 84)
                return (84);
        }
    return (0);
}
