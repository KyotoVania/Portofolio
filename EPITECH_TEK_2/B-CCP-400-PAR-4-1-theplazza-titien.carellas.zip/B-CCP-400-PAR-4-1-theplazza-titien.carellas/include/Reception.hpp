#ifndef RECEPTION_HPP
#define RECEPTION_HPP

#include "Command.hpp"
#include "ArgumentParser.hpp"
#include "Kitchen.hpp"
#include "shared.hpp"
#include <thread>
#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include<unistd.h>


class Reception {
public:
    Reception(int argc, char* argv[]);
    ~Reception();
    void receiveOrder(Command * order);
    void display(void);
    void run(void);
    
    void sendOrderToKitchen();
    void createKitchen();
    bool isFull();
    private:
    std::vector<std::shared_ptr<Kitchen>> _kitchens;
    std::vector<std::shared_ptr<Command>> _orders;
    ArgumentParser _options;
    pthread_t thread;
	commu_t* _shared_mem;
    int _memid;

};

#endif // RECEPTION_HPP
