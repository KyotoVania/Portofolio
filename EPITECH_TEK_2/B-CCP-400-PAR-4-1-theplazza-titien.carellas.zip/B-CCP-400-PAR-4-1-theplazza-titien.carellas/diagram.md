```mermaid
classDiagram
    class Pizza {
        -PizzaType type
        -PizzaSize size
        -vector<Ingredient> ingredients
    }
    class Cook {
        -thread thread
    }
    class Kitchen {
        -int maxPizzas
        -vector<Cook> cooks
        -vector<Pizza> pizzas
        -map<Ingredient, int> ingredients
    }
    class Reception {
        -vector<Kitchen> kitchens
    }
    class Ingredient {
        -int enum name
    }
    Reception -- Kitchen : managed the
    Kitchen -- Cook : have working
    Cook -- Pizza : cook this
    Kitchen -- Pizza: prepared this 
    Pizza -- Ingredient : contains

```
