/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** ppm_export.hpp
*/
#ifndef PPM_EXPORT_HPP_
	#define PPM_EXPORT_HPP_
	#include "utils/shared.hpp"
	#include "materials/flat_color.hpp"


#endif /*PPM_EXPORT_HPP_*/