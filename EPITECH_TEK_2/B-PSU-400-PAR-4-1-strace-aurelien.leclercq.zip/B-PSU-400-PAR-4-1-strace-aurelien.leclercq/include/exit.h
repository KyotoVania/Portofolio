/*
** EPITECH PROJECT, 2023
** Strace
** File description:
** exit.h
*/

#ifndef EXIT_H_
    #define EXIT_H_
typedef bool (*condition_func)(int);

struct condition_message_pair {
    condition_func condition;
    const char* message;
};

#endif /*EXIT_H_*/
