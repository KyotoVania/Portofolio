/*
** EPITECH PROJECT, 2023
** Strace
** File description:
** syscall_helpers.h
*/
#ifndef SYSCALL_HELPERS_H_
    #define SYSCALL_HELPERS_H_
    #include <sys/types.h>
    #include "syscall.h"
    #include "options.h"
    #include "trace.h"

char *read_string(pid_t child, size_t address);
int get_syscall_index(long long syscall,
    syscall_t *syscalls);
long long get_register(pid_t child, int reg);
int print_name(long long syscall, syscall_t *syscalls);
void print_params(pid_t child, syscall_t *syscalls, long long index);
void print_retval(long long retval, options_t *opts,
    long ret_type, pid_t child);
void print_detailed_params(pid_t child, syscall_t *syscalls,
    long long index, options_t *opts);
int check_status(int status);

#endif /*SYSCALL_HELPERS_H_*/
