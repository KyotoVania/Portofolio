/*
** EPITECH PROJECT, 2023
** Strace
** File description:
** syscall_helpers.c
*/

#include "syscall_helpers.h"

void print_retval_helper(long long retval, long ret_type, pid_t child)
{
    switch (ret_type) {
        case STRING:{
            char *str = retval ? read_string(child, retval) : "";
            fprintf(stderr, ") = \"%s\"\n", str);
        }
            break;
        case VOID:
            fprintf(stderr, ") = ?\n");
            break;
        case NUM:
        case PVOID:
            fprintf(stderr, ") = %lld\n", retval);
            break;
        default:
            fprintf(stderr, ") = 0x%llx\n", retval);
            break;
    }
}

void print_retval(long long retval,
    options_t *opts, long ret_type, pid_t child)
{
    if (retval) {
        if (opts->s_option) {
            print_retval_helper(retval, ret_type, child);
        } else {
            fprintf(stderr, ") = 0x%llx\n", retval);
        }
    } else {
        if (opts->s_option) {
            print_retval_helper(retval, ret_type, child);
        } else {
            fprintf(stderr, ") = 0x0\n");
        }
    }
}

void print_arg(pid_t child, int arg_type,
    unsigned long long arg_long, options_t *opts)
{
    switch (arg_type) {
        case NUM:
        case VOID_P:
        case PVOID:
            fprintf(stderr, opts->s_option ? "%lld" : "0x%llx", arg_long);
            break;
        case STRING: {
            char *str = read_string(child, arg_long);
            fprintf(stderr, opts->s_option ? "\"%s\"" : "0x%llx", str);
        }
            break;
        default:
            fprintf(stderr, "%lld", arg_long);
    }
}

void print_detailed_params(pid_t child, syscall_t *syscalls,
long long index, options_t *opts)
{
    int nargs = syscalls[index].nargs;
    int args[6] = {RDI, RSI, RDX, R10, R8, R9};
    unsigned long long arg_long;

    if (index == -1) {
        return;
    }

    for (int i = 0; i < nargs; i++) {
        arg_long = get_register(child, args[i]);
        int arg_type = get_arg_type(syscalls[index], i);
        print_arg(child, arg_type, arg_long, opts);

        if (i < nargs - 1) {
            fprintf(stderr, ", ");
        }
    }
}

int check_status(int status)
{
    return ((WIFSTOPPED(status) && (WSTOPSIG(status) == SIGTRAP))
    || WSTOPSIG(status) == SIGSTOP);
}
