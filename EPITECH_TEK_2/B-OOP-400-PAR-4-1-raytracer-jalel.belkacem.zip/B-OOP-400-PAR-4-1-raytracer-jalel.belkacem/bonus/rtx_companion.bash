#!/bin/bash

PPM_FILE="output.ppm"
DIRECTORY="configuration/"

# Function to display PPM file
display_ppm() {
    while true; do
        inotifywait -e modify "$PPM_FILE" >/dev/null 2>&1
        feh --borderless --title "PPM Viewer" --geometry 800x600 "$PPM_FILE"
    done
}

# Function to launch raytracer
launch_raytracer() {
    while true; do
        file=$(inotifywait -r -e modify "$DIRECTORY" | awk '{print $3}')
        if [[ -n "$file" ]]; then
            echo "File $file modified. Launching program..."
            ./raytracer "$DIRECTORY/$file"
        fi
    done
}

# Run functions in parallel
display_ppm &
display_ppm_pid=$!

launch_raytracer &
launch_raytracer_pid=$!

# Wait for spacebar to be pressed to quit
while true; do
    read -rsn1 input
    if [[ $input == ' ' ]]; then
        echo "Quitting..."
        break
    fi
done

# Terminate the background processes
kill $display_ppm_pid
kill $launch_raytracer_pid

