/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** ClockComponent.cpp
*/

#include "ClockComponent.hpp"

nts::ClockComponent::ClockComponent()
{
    state = nts::UNDEFINED;
    newstate = nts::UNDEFINED;
}

nts::ClockComponent::~ClockComponent()
{
}

nts::Tristate nts::ClockComponent::compute(std::size_t pin)
{
    if (pin == 1) {
        return state;
    }
    return nts::UNDEFINED;
}

void nts::ClockComponent::simulate(std::size_t tick) // check if its coherent with the  subject
{
    if (newstate == nts::NOT_SET && state != nts::UNDEFINED) {
        if (state == nts::TRUE)
            state = nts::FALSE;
        else if (state == nts::FALSE)
            state = nts::TRUE;
    } else if (newstate != nts::NOT_SET) {
        state = newstate;
        newstate = nts::NOT_SET;
    }
}


const std::vector<Pin> * nts::ClockComponent::getLinks () const
{
    return &links;
}

std::vector<Pin> * nts::ClockComponent::getLinks()
{
    return &links;
}

void nts::ClockComponent::display(std::ostream &os)
{
    os << "ClockComponent" << std::endl;
}

void nts::ClockComponent::setStates(nts::Tristate state)
{
    this->newstate = state;
}

