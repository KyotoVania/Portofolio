/*
** EPITECH PROJECT, 2023
** B-CCP-400-PAR-4-1-theplazza-titien.carellas
** File description:
** shared.hpp
*/
#ifndef SHARED_HPP_
	#define SHARED_HPP_
#include <memory>
#include <mutex>
#include <thread>
#include <queue>
#include <condition_variable>
#include <iostream>
#include "Pizza.hpp"
#include "Command.hpp"
#include <atomic>
#include <semaphore.h>
typedef struct commu_s
{
	//need to hold a command
	std::atomic<bool> _commandAdded;  // Signal when a command is added
	std::atomic<bool> _commandProcessed;  // Signal when a command is processed
	PizzaType type; //
	PizzaSize size; // 
	int number; 
    sem_t sem;
} commu_t;




#endif /*SHARED_HPP_*/