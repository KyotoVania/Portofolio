/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** shared.hpp
*/
#ifndef SHARED_HPP_
	#define SHARED_HPP_
	#include <libconfig.h++>
	#include <iostream>
	#include <tuple>
    #include <vector>
	#include <cmath>
	#include <sstream>
    #include <random>
	#include <omp.h>


class Vec3 {
public:
    float x, y, z;
    static std::mt19937 generator;
    Vec3(float x = 0, float y = 0, float z = 0) : x(x), y(y), z(z) {}

    Vec3 operator+(const Vec3& other) const {
        return Vec3(x + other.x, y + other.y, z + other.z);
    }

    Vec3 operator-(const Vec3& other) const {
        return Vec3(x - other.x, y - other.y, z - other.z);
    }
    Vec3& operator+=(const Vec3& other) {
        x += other.x;
        y += other.y;
        z += other.z;
        return *this;
    }
    Vec3& operator-=(const Vec3& other) {
        x -= other.x;
        y -= other.y;
        z -= other.z;
        return *this;
    }
    Vec3 operator*(const Vec3& other) const {
        return Vec3(x * other.x, y * other.y, z * other.z);
    }
    Vec3& operator*=(float scalar) {
        x *= scalar;
        y *= scalar;
        z *= scalar;
        return *this;
    }
    
    Vec3 operator*(float scalar) const {
        return Vec3(x * scalar, y * scalar, z * scalar);
    }
    friend Vec3 operator*(float scalar, const Vec3& vec) {
        return Vec3(vec.x * scalar, vec.y * scalar, vec.z * scalar);
    }
    friend Vec3 operator/(const Vec3& vec, int scalar) {
        return Vec3(vec.x / scalar, vec.y / scalar, vec.z / scalar);
    }
	friend std::ostream& operator<<(std::ostream& os, const Vec3& vec) {
        os << "(" << vec.x << ", " << vec.y << ", " << vec.z << ")";
        return os;
    }

    float dot(const Vec3& other) const {
        return x * other.x + y * other.y + z * other.z;
    }
    
    static float random_double() {
        
        static std::uniform_real_distribution<float> distribution(0.0, 1.0);
        return distribution(generator);
    }
    
    static float random_double_limited(float min, float max) {
        return min + (max-min)*random_double();
    }
    
    Vec3 normalized() const {
        float len = length();
        return Vec3(x / len, y / len, z / len);
    }
    double length() const {
        return std::sqrt(x * x + y * y + z * z);
    }
    static Vec3 random() {
        return Vec3(random_double(), random_double(), random_double());
    }
    static Vec3 random(float min, float max) {
        return Vec3(random_double_limited(min, max), random_double_limited(min, max), random_double_limited(min, max));
    }
    Vec3 random_in_unit_sphere() {
        while (true) {
            auto p = Vec3::random(-1,1);
            if (p.length() >= 1) continue;
            return p;
        }
    }
};


#endif /*SHARED_HPP_*/