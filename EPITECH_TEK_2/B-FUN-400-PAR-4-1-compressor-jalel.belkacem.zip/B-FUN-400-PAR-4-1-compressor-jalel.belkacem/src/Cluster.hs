{- 
-- EPITECH PROJECT, 2023
-- norme_moi_ca
-- File description:
-- Cluster
-}

module Cluster (
    Cluster(..), printCluster, generateInitialClusters, refineClusters,
    groupPixelsByCluster, allocatePixelsToClusters
  ) where

import Point (Point(..), pointPosition, pointValue, randomlySelect)
import Pixel (Pixel, squaredDistance)
import Data.List (sortBy)
import Data.Maybe (fromJust)
import System.Random (randomRIO)
import Control.Parallel.Strategies (parMap, rdeepseq)
import Data.List (minimumBy, groupBy, sortBy, find)
import Data.Ord (comparing)

data Cluster = Cluster {
    clusterId :: !Int, clusterValue :: !Pixel, points :: ![Point]
  } deriving (Show, Eq)

printCluster :: Cluster -> IO ()
printCluster (Cluster n (r, g, b) _) =
  putStrLn $
    "(" ++ show n ++ ",(" ++ show r ++ "," ++ show g ++ "," ++ show b ++ "))"

generateInitialClusters :: Int -> [Pixel] -> IO [Cluster]
generateInitialClusters nClusters pixels = do
  initialCentroid <- randomlySelect pixels
  otherCentroids <- selectCentroids (nClusters - 1) [initialCentroid] pixels
  return $ zipWith (\idx pixel -> Cluster idx pixel []) [0..]
    (initialCentroid : otherCentroids)

selectCentroids :: Int -> [Pixel] -> [Pixel] -> IO [Pixel]
selectCentroids 0 _ _ = return []
selectCentroids n centroids pixels = do
  newCentroid <- nextCentroid centroids pixels
  rest <- selectCentroids (n - 1) (newCentroid : centroids) pixels
  return (newCentroid : rest)

nextCentroid :: [Pixel] -> [Pixel] -> IO Pixel
nextCentroid centroids pixels = do
  let probabilities = calculateProbabilities centroids pixels
  threshold <- randomRIO (0.0, 1.0)
  return $ sampleWithThreshold (zip probabilities pixels) threshold

calculateProbabilities :: [Pixel] -> [Pixel] -> [Float]
calculateProbabilities centroids pixels
  | null pixels || null centroids = []
  | otherwise =
    let squaredDistances =
          parMap rdeepseq
            (\pixel -> minimum [squaredDistance pixel centroid
                               | centroid <- centroids]) pixels
        totalSquaredDistances = sum squaredDistances
    in map (/ totalSquaredDistances) squaredDistances

sampleWithThreshold :: [(Float, Pixel)] -> Float -> Pixel
sampleWithThreshold [] _ = error "sampleWithThreshold: empty list"
sampleWithThreshold ((p, x) : xs) t
  | t <= p = x
  | otherwise = sampleWithThreshold xs (t - p)

clusterDistance :: Cluster -> Cluster -> Float
clusterDistance c1 c2 = squaredDistance (clusterValue c1) (clusterValue c2)

newCentroid :: Cluster -> [Point] -> Cluster
newCentroid (Cluster clusterId value _) allocatedPoints =
  let points = if null allocatedPoints
               then []
               else map pointValue allocatedPoints
      newCentroid = if null points
                    then value
                    else getAverage points
  in Cluster clusterId newCentroid allocatedPoints
  where
    getAverage pixels = divColor (getSum pixels) (length pixels)
    getSum = foldr addColor (0, 0, 0)
    addColor (r, g, b) (r2, g2, b2) = (r + r2, g + g2, b + b2)
    divColor (r, g, b) n = (r `div` n, g `div` n, b `div` n)

refineClusters :: (Int, Int) -> Float -> [Cluster] -> [Pixel] -> IO ([Cluster], Int)
refineClusters imageSize convergenceThreshold initialClusters pixels =
  go initialClusters 0
  where
    go clusters iteration = do
        let newClusters = recalculateCentroids imageSize clusters pixels
        let differences = zipWith clusterDistance clusters newClusters
        let maxDifference = maximum differences
        if realToFrac maxDifference <= convergenceThreshold
            then return (newClusters, iteration)
            else go newClusters (iteration + 1)

identifyNearestCluster :: [Cluster] -> Pixel -> Cluster
identifyNearestCluster clusters pixel =
  minimumBy (comparing (squaredDistance pixel . clusterValue)) clusters

recalculateCentroids ::
  (Int, Int) -> [Cluster] -> [Pixel] -> [Cluster]
recalculateCentroids imageSize clusters pixels = newClusters
  where
    allocatedPixels = allocatePixelsToClusters imageSize clusters pixels
    groupedPixels = groupPixelsByCluster clusters allocatedPixels
    newClusters = zipWith (\c gp -> newCentroid c (points gp))
                          clusters groupedPixels

allocatePixelsToClusters ::
  (Int, Int) -> [Cluster] -> [Pixel] -> [Cluster]
allocatePixelsToClusters (width, height) clusters pixels =
  map createCluster clusters
  where
    createCluster cluster =
      let points = findPointsForCluster cluster
                     (zip (concatMap (\y -> map (\x -> (x, y)) [0..(width - 1)]) [0..(height - 1)]) pixels)
      in Cluster (clusterId cluster) (clusterValue cluster) points
    findPointsForCluster clusterId pixels =
      [Point (i, j) pixel | ((i, j), pixel) <- pixels, identifyNearestCluster clusters pixel == clusterId]

groupPixelsByCluster :: [Cluster] -> [Cluster] -> [Cluster]
groupPixelsByCluster clusters clustersWithPoints =
  map updateCluster clusters
  where
    updateCluster cluster =
      let matchingCluster = findClusterById (clusterId cluster) clustersWithPoints
      in Cluster (clusterId cluster) (clusterValue cluster)
            (maybe [] points matchingCluster)
    findClusterById targetId = find (\cluster -> clusterId cluster == targetId)
