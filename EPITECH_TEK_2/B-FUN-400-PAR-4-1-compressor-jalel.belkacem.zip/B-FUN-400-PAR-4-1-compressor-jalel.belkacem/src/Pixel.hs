{-
-- EPITECH PROJECT, 2023
-- B-FUN-400-PAR-4-1-compressor-jalel.belkacem
-- File description:
-- Pixel
-}

module Pixel (Pixel, pixelFromList, processPixelLine, pixelParser, readInt,
              formatPixel, parseRgbValues, squaredDistance) where
import Data.List (groupBy)
import Text.ParserCombinators.ReadP
import Data.Char (isDigit)
import Data.List (sortBy)
import Data.Ord (comparing)
import Position (Position, processPosition, readInt, positionParser)

type Pixel = (Int, Int, Int)

pixelParser :: ReadP Pixel
pixelParser = do
    _ <- char '('
    r <- readInt
    _ <- char ','
    g <- readInt
    _ <- char ','
    b <- readInt
    _ <- char ')'
    return (r, g, b)

pixelFromList :: [Int] -> Pixel
pixelFromList [r, g, b] = (r, g, b)
pixelFromList xs = error $ "Invalid pixel data: " ++ show xs

processPixelLine :: String -> Pixel
processPixelLine line = case parseRgbValues line of
    Just pixel -> pixel
    Nothing -> error $ "Invalid pixel data: " ++ line ++
               " / " ++ show (parseRgbValues line)

parseRgbValues :: String -> Maybe Pixel
parseRgbValues line = case readP_to_S pixelParser line of
    [(pixel, "")] -> Just pixel
    _ -> Nothing

formatPixel :: Pixel -> String
formatPixel (r, g, b) = "(" ++ show r ++ "," ++ show g ++ "," ++ show b ++ ")"

squaredDistance :: Pixel -> Pixel -> Float
squaredDistance (r1, g1, b1) (r2, g2, b2) =
  fromIntegral ((r1 - r2) ^ 2 + (g1 - g2) ^ 2 + (b1 - b2) ^ 2)
