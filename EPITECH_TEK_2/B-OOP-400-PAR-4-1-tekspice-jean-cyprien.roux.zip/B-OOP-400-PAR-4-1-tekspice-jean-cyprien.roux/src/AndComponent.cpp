/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** AndComponent.cpp
*/

#include "AndComponent.hpp"

#include "AndComponent.hpp"

nts::AndComponent::AndComponent()
{

}

nts::AndComponent::~AndComponent()
{
}

nts::Tristate nts::AndComponent::compute(std::size_t pin)
{
    nts::Tristate state = getLink(1);
    nts::Tristate state2 = getLink(2);
    if (pin == 3) {
        if (state == nts::FALSE || state2 == nts::FALSE) {
            return nts::FALSE;
        } else if (state == nts::UNDEFINED || state2 == nts::UNDEFINED) {
            return nts::UNDEFINED;
        } else {
            return nts::TRUE;
        }
    }


    if (pin == 1) {
        return getLink(1);
    }
    if (pin == 2) {
        return getLink(2);
    }
    return nts::UNDEFINED;
}

const std::vector<Pin> * nts::AndComponent::getLinks() const
{
    return &links;
}

std::vector<Pin> * nts::AndComponent::getLinks()
{
    return &links;
}

void nts::AndComponent::display(std::ostream &os)
{
    os << "AndComponent" << std::endl;
}