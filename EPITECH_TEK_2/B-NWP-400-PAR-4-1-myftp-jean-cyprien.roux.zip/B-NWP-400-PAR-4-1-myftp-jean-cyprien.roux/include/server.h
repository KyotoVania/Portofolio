/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** server.h
*/
#ifndef SERVER_H_
    #define SERVER_H_
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <unistd.h>
    #include <sys/types.h>
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <arpa/inet.h>
    #include <stdbool.h>

enum {
    is_connected,
    is_disconnected,
    is_anonymous,
    is_logged_in,
};

enum {
    is_passive,
    is_active,
    undefined
};

typedef struct fd_node_s {
    int fd;
    int data_fd;
    char *ip;
    int port;
    int data_port;
    char *buffer;
    int buffer_pos;
    int buffer_size;
    int status;
    char *working_dir;
    int states;
    struct sockaddr_in client_addr;
    struct sockaddr_in data_addr;
    socklen_t client_addr_len;
    socklen_t data_addr_len;
    struct fd_node_s *next;
} fd_node_t;

typedef struct server_s {
    int fd;
    int port;
    char *ip;
    int client_count;
    struct sockaddr_in s_in;
    char *home_dir;
    fd_node_t *client_fds;
} server_t;

int start_server(int port, char *home_dir);
int stop_server(int fd);
server_t *init_server(int port, char *home_dir);
int set_user(fd_node_t *node, char *username);
int set_pass(fd_node_t *node, char *password);
int set_account(fd_node_t *node, char *account);
int set_cwd(fd_node_t *node, char *path);
int set_cdup(fd_node_t *node);
int reinit_client(fd_node_t *node, server_t *server);
int set_pasv(fd_node_t *node, server_t *server);
int set_actv(fd_node_t *node, char *ip, char *port);
int set_port(char *msg, fd_node_t *node);
int retrieve_file(fd_node_t *node, char *pathname, char *server_dir);
int store_file(fd_node_t *node, char *pathname, char *server_dir);
int set_smnt(fd_node_t *node, char *structure);
char *read_client_line(fd_node_t *node);
int send_client_line(int client_fd, char *msg);
int close_client(int client_fd, server_t *server);
int accept_client(server_t *server);
int check_iflogged(fd_node_t *node);
int create_socket(void);
int bind_socket(server_t *server);
int reconnect_client_data_socket(fd_node_t *node);
int bind_socket_data(fd_node_t *node);
int check_if_option_set(fd_node_t *node);
int help_function(fd_node_t *tmp_node);
int noop_function(fd_node_t *tmp_node);
int accept_and_select(fd_set readfds, server_t *server, int biggest_fd);
int stop_server(int fd);
#endif /*SERVER_H_*/
