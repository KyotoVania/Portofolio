/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** sphere.hpp
*/
#ifndef SPHERE_HPP_
	#define SPHERE_HPP_
	#include "utils/shared.hpp"
	#include "primitives/iPrimitive.hpp"



class Sphere : public iPrimitive {
public:
	
	Vec3 center;
	float radius;

	Sphere() : iPrimitive(), center(Vec3()), radius(0) {} // Add default constructor

	Sphere(const Vec3& center, float radius, const Vec3& color, const Vec3& translation = Vec3(), bool enableReflection = false, float refractiveIndex = 1.0f, float transparency = 1.0f) // Add enableReflection parameter to constructor
		: iPrimitive(color, translation, transparency, true, enableReflection, refractiveIndex), center(center), radius(radius) {} // Add enableReflection parameter to constructor
    
	bool intersect(const Vec3& rayOrigin, const Vec3& rayDirection, float& t0, float& t1) const override {
		Vec3 translatedRayOrigin = rayOrigin - translation; // Apply translation
		Vec3 oc = translatedRayOrigin - center;
		float a = rayDirection.dot(rayDirection);
		float b = 2.0f * oc.dot(rayDirection);
		float c = oc.dot(oc) - radius * radius;
		float discriminant = b * b - 4.0f * a * c;

		if (discriminant < 0) {
			return false;
		} else {
			float sqrtDiscriminant = std::sqrt(discriminant);
			t0 = (-b - sqrtDiscriminant) / (2.0f * a);
			t1 = (-b + sqrtDiscriminant) / (2.0f * a);
			return true;
		}
	}
};



#endif /*SPHERE_HPP_*/