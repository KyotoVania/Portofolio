/*
** EPITECH PROJECT, 2023
** Strace
** File description:
** trace.c
*/

#include "trace.h"

void handle_syscall(pid_t child, struct user_regs_struct regs,
    syscall_t *tabled, options_t *opts)
{
    long long syscall = regs.orig_rax;
    int syscall_index = get_syscall_index(syscall, tabled);
    if (syscall >= 0) {
        print_name(syscall, tabled);
        if (opts->s_option) {
            print_detailed_params(child, tabled, syscall_index, opts);
        } else {
            print_params(child, tabled, syscall_index);
        }
        print_retval(regs.rax, opts,
            tabled[syscall_index].ret_type, child);
    }
}

int do_trace(pid_t child, options_t *opts, syscall_t *tabled)
{
    struct user_regs_struct regs;
    int status;
    while (waitpid(child, &status, 0) && !WIFEXITED(status)) {
        ptrace(PTRACE_GETREGS, child, NULL, &regs);
        handle_syscall(child, regs, tabled, opts);
        ptrace(PTRACE_SINGLESTEP, child, NULL, NULL);
    }
    return status;
}

int do_child(int argc, char **argv)
{
    char *args [argc + 1];
    memcpy(args, argv, argc * sizeof(char*));
    args[argc] = NULL;
    ptrace(PTRACE_TRACEME, 0, 0, 0);
    if (execvp(args[0], args) == -1) {
        perror("execvp");
        return 1;
    }
    return 0;
}

int trace_process(char **av, options_t opts, syscall_t *tabled)
{
    int ret;
    int status = -1;
    pid_t pid = atoi(av[2]);
    struct user_regs_struct regs;

    signal(SIGINT, detach_and_exit);
    ret = ptrace(PTRACE_ATTACH, pid, 0, 0);
    if (ret == -1){
        perror("strace: attach");
        return 84;
    }
    trace_context_t context = {
            .pid = pid,
            .status = status,
            .regs = regs,
            .opts = opts,
            .tabled = tabled
    };
    perform_trace_p(&context);
    return 0;
}
