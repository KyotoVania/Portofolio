/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** main.c
*/

#include "myftp.h"

int main(int ac, char **av)
{
    (void)ac;
    if (ac != 3)
        return (84);
    start_server(atoi(av[1]), av[2]);

    return (0);
}
