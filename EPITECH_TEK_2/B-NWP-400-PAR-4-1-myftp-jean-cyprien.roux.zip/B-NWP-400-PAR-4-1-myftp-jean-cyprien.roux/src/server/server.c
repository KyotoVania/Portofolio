/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** server.c
*/

#include "myftp.h"
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int loop_server_sub(server_t *server, fd_set readfds, fd_node_t *tmp_node)
{
    while (tmp_node) {
        if (server_functionhandler(tmp_node, readfds, server) == 84)
            return (84);
        tmp_node = tmp_node->next;
    }
    return (0);
}

int set_fd_sets(server_t *server, fd_set *readfds, int *biggest_fd)
{
    FD_ZERO(readfds);
    fd_node_t *tmp_node = server->client_fds;
    *biggest_fd = server->fd;
    while (tmp_node) {
        FD_SET(tmp_node->fd, readfds);
        if (tmp_node->fd > *biggest_fd)
            *biggest_fd = tmp_node->fd;
        tmp_node = tmp_node->next;
    }
    FD_SET(server->fd, readfds);
    return (0);
}

int loop_server_active_part(server_t *server, int biggest_fd,
    fd_set readfds)
{
    if (set_fd_sets(server, &readfds, &biggest_fd) == 84)
        return (84);
    if (select(biggest_fd + 1, &readfds, NULL, NULL, NULL) == -1) {
        perror("select");
        return (84);
    }
    if (FD_ISSET(server->fd, &readfds)) {
        if (accept_client(server) == 84)
            return (84);
        printf("Client connected\n");
    }
    fd_node_t *tmp_node = server->client_fds;
    if (loop_server_sub(server, readfds, tmp_node) == 84)
        return (84);
    return (0);
}

int loop_server(server_t *server, int biggest_fd, fd_set readfds)
{
    while (1) {
        if (loop_server_active_part(server, biggest_fd, readfds) == 84)
            return (84);
    }
}

int start_server(int port, char *home_dir)
{
    int biggest_fd = 0;
    fd_set readfds;
    server_t *server = init_server(port, home_dir);
    server->fd = create_socket();
    if (server->fd == 84)
        return (84);
    if (bind_socket(server) == 84)
        return (84);
    if (loop_server(server, biggest_fd, readfds) == 84)
        return (84);
    return (0);
}
