/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** ProtectedComponent.hpp
*/
#ifndef PROTECTEDCOMPONENT_HPP_
	#define PROTECTEDCOMPONENT_HPP_

#include "IComponent.hpp"
#include "AComponent.hpp"
#include "PinComponent.hpp"

namespace nts {
	class ProtectedComponent : public nts::AComponent {
//make full empty class for protected overriding all the function to 0
		public:
		ProtectedComponent();
		~ProtectedComponent();
		nts::Tristate compute(std::size_t pin);
		std::vector<Pin> * getLinks();
		const std::vector<Pin> * getLinks() const;
		void display(std::ostream &os);
		void setStates(nts::Tristate state);
		void simulate(std::size_t tick);
		private:
		std::vector<Pin> links = std::vector<Pin> (1);
	};
}

#endif /*PROTECTEDCOMPONENT_HPP_*/