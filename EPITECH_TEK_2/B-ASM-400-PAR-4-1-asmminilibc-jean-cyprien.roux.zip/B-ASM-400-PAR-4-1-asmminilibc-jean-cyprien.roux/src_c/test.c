#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <ctype.h>
#include <stdlib.h>
#include "test.h"




char *to_lower(char *str)
{
    for (int i = 0; str[i]; i++)
        str[i] = tolower(str[i]);
    return str;
}

char *open_file(const char *filename)
{
    // Open file using mmap
    int fd = open(filename, O_RDONLY);
    assert(fd!= -1);

    // Map the file into memory
    struct stat st;
    assert(fstat(fd, &st)!= -1);
    void *mmap_ptr = mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
    assert(mmap_ptr!= MAP_FAILED);

    // Close the file
    assert(close(fd) == 0);

    return mmap_ptr;

}


int test_strlen() {

    char *array[3] = { "Hello, World!", "Hel",  open_file("tiny_file.txt")};
    int length = strlen(array[0]);
    int my_length = _my_strlen(array[0]);
    assert(length == my_length);
    length = strlen(array[1]);
    my_length = _my_strlen(array[1]);
    assert(length == my_length);
    length = strlen(array[2]);
    my_length = _my_strlen(array[2]);
    assert(length == my_length);
    char *array_b[5] = { "", "a", "ab", "abcdefghijklmnopqrstuvwxyz", open_file("long_file.txt")};
    length = strlen(array_b[0]);
    my_length = _my_strlen(array_b[0]);
    assert(length == my_length);
    length = strlen(array_b[1]);
    my_length = _my_strlen(array_b[1]);
    assert(length == my_length);
    length = strlen(array_b[2]);
    my_length = _my_strlen(array_b[2]);
    assert(length == my_length);
    length = strlen(array_b[3]);
    my_length = _my_strlen(array_b[3]);
    assert(length == my_length);
    length = strlen(array_b[4]);
    my_length = _my_strlen(array_b[4]);
    assert(length == my_length);
    printf("test_strlen: OK\n");
    return 0;
}


int test_strcmp()
{
    char *array[3] = { "Hello, World!", "Hel",  open_file("tiny_file.txt")}; //(3] = hello
    int strcmp_r = strcmp(array[0], array[0]);
    int my_strcmp_r = _my_strcmp(array[0], array[0]);
    assert(strcmp_r == my_strcmp_r);
    strcmp_r = strcmp(array[1], array[2]);
    my_strcmp_r = _my_strcmp(array[1], array[2]);
    assert(strcmp_r == my_strcmp_r);
    strcmp_r = strcmp(array[0], array[1]);
    my_strcmp_r = _my_strcmp(array[0], array[1]);
    assert(strcmp_r == my_strcmp_r);
    strcmp_r = strcmp(array[1], array[0]);
    my_strcmp_r = _my_strcmp(array[1], array[0]);
    assert(strcmp_r == my_strcmp_r);
    char *array_b[6] = { "", "a", "ab", "abcdefghijklmnopqrstuvwxyz", "zyxwvutsrqponmlkjihgfedcba", open_file("long_file.txt")};
    strcmp_r = strcmp(array_b[0], array_b[0]);
    my_strcmp_r = _my_strcmp(array_b[0], array_b[0]);
    assert(strcmp_r == my_strcmp_r);
    strcmp_r = strcmp(array_b[1], array_b[2]);
    my_strcmp_r = _my_strcmp(array_b[1], array_b[2]);
    assert(strcmp_r == my_strcmp_r);
    strcmp_r = strcmp(array_b[2], array_b[1]);
    my_strcmp_r = _my_strcmp(array_b[2], array_b[1]);
    assert(strcmp_r == my_strcmp_r);
    strcmp_r = strcmp(array_b[3], array_b[4]);
    my_strcmp_r = _my_strcmp(array_b[3], array_b[4]);
    assert(strcmp_r == my_strcmp_r);
    strcmp_r = strcmp(array_b[4], array_b[3]);
    my_strcmp_r = _my_strcmp(array_b[4], array_b[3]);
    assert(strcmp_r == my_strcmp_r);
    strcmp_r = strcmp(array_b[3], array_b[5]);
    my_strcmp_r = _my_strcmp(array_b[3], array_b[5]);
    assert(strcmp_r == my_strcmp_r);
    printf("test_strcmp: OK\n");
    return 0;
}


int test_strncmp(void)
{
    char *array[3] = { "Hello, World!", "Hel",  open_file("tiny_file.txt")}; //(3] = hello
    int strncmp_r = strncmp(array[0], array[0], 5);
    int my_strncmp_r = _my_strncmp(array[0], array[0], 5);
    assert(strncmp_r == my_strncmp_r);
    strncmp_r = strncmp(array[1], array[2], 5);
    my_strncmp_r = _my_strncmp(array[1], array[2], 5);
    assert(strncmp_r == my_strncmp_r);
    strncmp_r = strncmp(array[0], array[1], 5);
    my_strncmp_r = _my_strncmp(array[0], array[1], 5);
    assert(strncmp_r == my_strncmp_r);
    strncmp_r = strncmp(array[1], array[0], 2);
    my_strncmp_r = _my_strncmp(array[1], array[0], 2); //good comparaison
    assert(strncmp_r == my_strncmp_r);
    printf("test_strncmp: OK\n");
    return 0;
}

int test_strcasecmp(void)
{
    char *array[6] = { "Hello, World!",
                       "hello, world!",
                       "Hel",
                       "hel",
                       "ItS RANiNing BaNANAs",
                          "its raining bananas"};
    int strcasecmp_r = strcasecmp(array[0], array[1]);
    int my_strcasecmp_r = _my_strcasecmp(array[0], array[1]);
    assert(strcasecmp_r == my_strcasecmp_r);
    strcasecmp_r = strcasecmp(array[2], array[3]);
    my_strcasecmp_r = _my_strcasecmp(array[2], array[3]);
    assert(strcasecmp_r == my_strcasecmp_r);
    strcasecmp_r = strcasecmp(array[4], array[5]);
    my_strcasecmp_r = _my_strcasecmp(array[4], array[5]);
    assert(strcasecmp_r == my_strcasecmp_r);
    printf("test_strcasecmp: OK\n");
    return 0;
}

int test_strchr(void)
{
    char *array[3] = { "Hello, World!", "Hel",  open_file("tiny_file.txt")}; //(3] = hello
    char *strchr_v = strchr(array[0], 'l');
    char *my_strchr_v = _my_strchr(array[0], 'l');
    assert(strchr_v == my_strchr_v);
    strchr_v = strchr(array[1], 'l');
    my_strchr_v = _my_strchr(array[1], 'l');
    assert(strchr_v == my_strchr_v);
    strchr_v = strchr(array[2], 'l');
    my_strchr_v = _my_strchr(array[2], 'l');
    assert(strchr_v == my_strchr_v);
    strchr_v = strchr(array[0], 'z');
    my_strchr_v = _my_strchr(array[0], 'z');
    assert(strchr_v == my_strchr_v);
    printf("test_strchr: OK\n");
    return 0;
}

int test_strrchr(void)
{
    char *array[3] = { "Hello, World!", "Hel",  open_file("tiny_file.txt")}; //(3] = hello
    char *strrchr_r = strrchr(array[0], 'l');
    char *my_strrchr_r = _my_strrchr(array[0], 'l');
    assert(strrchr_r == my_strrchr_r);
    strrchr_r = strrchr(array[1], 'l');
    my_strrchr_r = _my_strrchr(array[1], 'l');
    assert(strrchr_r == my_strrchr_r);
    strrchr_r = strrchr(array[2], 'l');
    my_strrchr_r = _my_strrchr(array[2], 'l');
    assert(strrchr_r == my_strrchr_r);
    strrchr_r = strrchr(array[0], 'z');
    my_strrchr_r = _my_strrchr(array[0], 'z');
    assert(strrchr_r == my_strrchr_r);
    strrchr_r = strrchr("", 'l');
    my_strrchr_r = _my_strrchr("", 'l');
    assert(strrchr_r == my_strrchr_r);
    printf("test_strrchr: OK \n");
    return 0;
}


int test_strstr(void)
{
    char *array[3] = { "Hello, World!", "Hel",  open_file("tiny_file.txt")}; //(3] = hello
    char *strstr_r = strstr(array[0], "llo");
    char *my_strstr_r = _my_strstr(array[0], "llo");
    assert(strcmp(strstr_r, my_strstr_r) == 0); //good comparaison llo, World!
    strstr_r = strstr(array[1], "llo");
    my_strstr_r = _my_strstr(array[1], "llo");
    assert( my_strstr_r == NULL && strstr_r == NULL);
    strstr_r = strstr(array[2], "llo");
    my_strstr_r = _my_strstr(array[2], "llo");
    assert(strcmp(strstr_r, my_strstr_r) == 0);
    strstr_r = strstr(array[0], "z");
    my_strstr_r = _my_strstr(array[0], "z");
    assert( my_strstr_r == NULL && strstr_r == NULL);
    printf("test_strstr: OK \n");
    return 0;
}



int test_strpbrk(void)
{
    int result = 0;
    char *string_1 = strdup("Hello, World!");
    char *string_2 = strdup("Hello!");
    char *string_3 = strdup("World!");
    char *strpbrk_r;
    char *my_strpbrk_r;
    strpbrk_r = strpbrk(string_1, "llo");
    my_strpbrk_r = _my_strpbrk(string_1, "llo");
    result = strcmp(strpbrk_r, my_strpbrk_r);
    assert(result == 0); //test 1
    strpbrk_r = strpbrk(string_2, "5");
    my_strpbrk_r = _my_strpbrk(string_2, "5");
    assert(my_strpbrk_r == NULL); //test 2
    strpbrk_r = strpbrk(string_3, "z");
    my_strpbrk_r = _my_strpbrk(string_3, "z");
    assert(my_strpbrk_r == NULL); //test 3
    printf("test_strpbrk: OK\n");
    free (string_1);
    free (string_2);
    free (string_3);
    return 0;
}


int test_strcspn(void)
{
    char *string_1 = strdup("Hello, World!");
    char *string_2 = strdup("Hello!");
    char *string_3 = strdup("World!");
    size_t strcspn_r;
    size_t my_strcspn_r;
    strcspn_r = strcspn(string_1, "llo");
    my_strcspn_r = _my_strcspn(string_1, "llo");
    assert(strcspn_r == my_strcspn_r); //test 1
    strcspn_r = strcspn(string_2, "5");
    my_strcspn_r = _my_strcspn(string_2, "5");
    assert(my_strcspn_r == strcspn_r); //test 2
    strcspn_r = strcspn(string_3, "z");
    my_strcspn_r = _my_strcspn(string_3, "z");
    assert(my_strcspn_r == strcspn_r); //test 3
    printf("test_strcspn: OK\n");
    free (string_1);
    free (string_2);
    free (string_3);
    return 0;
}


int test_memset(void)
{
    int result = 0;
    char *string_1 = strdup("Hello, World!");
    char *string_2 = strdup("Hello!");
    char *string_3 = strdup("World!");
    char *memset_r;
    char *my_memset_r;
    memset_r = memset(string_1, 'l', 5);
    string_1 = strdup("Hello, World!");
    my_memset_r = _my_memset(string_1, 'l', 5);
    result = strcmp(memset_r, my_memset_r);
    assert(result == 0); //test 1
    memset_r = memset(string_2, '5', 5);
    string_2 = strdup("Hello!");
    my_memset_r = _my_memset(string_2, '5', 5);
    result = strcmp(memset_r, my_memset_r);
    assert(result == 0); //test 2
    memset_r = memset(string_3, 0, 5);
    string_3 = strdup("World!");
    my_memset_r = _my_memset(string_3, 0, 5);
    result = strcmp(memset_r, my_memset_r);
    assert(result == 0); //test 3
    printf("test_memset: OK\n");
    free (string_1);
    free (string_2);
    free (string_3);
    return 0;
}

int test_memcpy()
{
    int result = 0;
    char *string_1 = strdup("Hello, World!");
    char *string_2 = strdup("Hello!");
    char *string_3 = strdup("World!");
    char *memcpy_r;
    char *my_memcpy_r;
    memcpy_r = memcpy(string_1, "llo", 3);
    string_1 = strdup("Hello, World!");
    my_memcpy_r = _my_memcpy(string_1, "llo", 3);
    result = strcmp(memcpy_r, my_memcpy_r);
    assert(result == 0); //test 1
    memcpy_r = memcpy(string_2, "5", 1);
    string_2 = strdup("Hello!");
    my_memcpy_r = _my_memcpy(string_2, "5", 1);
    result = strcmp(memcpy_r, my_memcpy_r);
    assert(result == 0); //test 2
    memcpy_r = memcpy(string_3, "llo", 0);
    string_3 = strdup("World!");
    my_memcpy_r = _my_memcpy(string_3, "llo", 0);
    result = strcmp(memcpy_r, my_memcpy_r);
    assert(result == 0); //test 3
    printf("test_memcpy: OK\n");
    free (string_1);
    free (string_2);
    free (string_3);
    return 0;
}

int test_memmove(void)
{
    int result = 0;
    char *string_1 = strdup("xyz");
    char *string_2 = strdup("Hello!");
    char *string_3 = strdup("World!");
    char *memmove_r;
    char *my_memmove_r;
    memmove_r = memmove(string_1 + 1, string_1 , 4);
    string_1 = strdup("xyz");
    my_memmove_r = _my_memmove(string_1  + 1, string_1, 4);
    result = strcmp(memmove_r, my_memmove_r);
    assert(result == 0); //test 1
    memmove_r = memmove(string_2, "5", 1);
    string_2 = strdup("Hello!");
    my_memmove_r = _my_memmove(string_2, "5", 1);
    result = strcmp(memmove_r, my_memmove_r);
    assert(result == 0); //test 2
    memmove_r = memmove(string_3, "llo", 0);
    string_3 = strdup("World!");
    my_memmove_r = _my_memmove(string_3, "llo", 0);
    result = strcmp(memmove_r, my_memmove_r);
    assert(result == 0); //test 3
    string_3 = strdup("Big sentence fill with random words such as: Hello, World!, and other stuff");
    memmove_r = memmove(string_3 + 10, string_3, 10);
    string_3 = strdup("Big sentence fill with random words such as: Hello, World!, and other stuff");
    my_memmove_r = _my_memmove(string_3 + 10, string_3, 10);
    result = strcmp(memmove_r, my_memmove_r);
    assert(result == 0); //test 4
    printf("test_memmove: OK\n");
    free (string_1);
    free (string_2);
    free (string_3);
    return 0;
}



int main() {

    test_strlen();
    test_strcmp();
    test_strncmp();
    test_strcasecmp();
    test_strchr();
    test_strrchr();
    test_strstr();
    test_strpbrk();
    test_strcspn();
    test_memset();
    test_memcpy();
    test_memmove();
    return 0;
}
