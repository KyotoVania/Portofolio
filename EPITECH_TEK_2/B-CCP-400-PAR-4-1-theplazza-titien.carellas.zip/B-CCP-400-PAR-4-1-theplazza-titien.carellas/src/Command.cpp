/*
** EPITECH PROJECT, 2023
** B-CCP-400-PAR-4-1-theplazza-titien.carellas
** File description:
** Command.cpp
*/

#include "Command.hpp"

Command::Command()
{
}

Command::~Command()
{
}
Command Command::splitCommand(int availableSpace) {
    //available space will always be 1 as we only want to get the first pizza of the command and remove it from the command, the one returned will always be 1 size long
    std::vector<std::pair<Pizza *, int>> newCommandPizzas;
    Command newCommand(_id);  // Create a new Command instance instead of pointer
    //we only it to take the first pizza of the command so it need to check if the vector contains multiple pizzas like 2 margarita and 1 fantasia if its the case then it will only take the first margarita and put it in the new command and return it
    //but beore it needs to check if the command is not empty and remove the pizza from the command
    auto& pizzaInfo = _pizzaCommand.front();
    pizzaInfo.second -= availableSpace;
    if (pizzaInfo.second == 0) {
        _pizzaCommand.erase(_pizzaCommand.begin());
    }
    newCommandPizzas.push_back(std::make_pair(pizzaInfo.first, availableSpace));
    newCommand.setCommand(newCommandPizzas);
    return newCommand;  // Return the new Command instance 
}


std::size_t Command::getNumberOfPizza() const {
    std::size_t numberOfPizza = 0;

    for (auto& pair : _pizzaCommand) {
        numberOfPizza += pair.second;
    }
    return numberOfPizza;
}

void Command::updateCommu(commu_t* command)
{
    if (_pizzaCommand.empty()) {
        // If there are no pizzas in the command, update the command accordingly
        command->type = PizzaType::None;
        command->size = PizzaSize::Null;
        command->number = 0;
    } else {
        // Take the first element in the _pizzaCommand vector
        auto& pizzaInfo = _pizzaCommand.front();

        // Update the command with the pizza information
        command->type = pizzaInfo.first->getType();
        command->size = pizzaInfo.first->getSize();
        command->number = pizzaInfo.second;

        // Remove the pizza from _pizzaCommand
        _pizzaCommand.erase(_pizzaCommand.begin());
    }
}
