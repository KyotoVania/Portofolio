/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** TrueComponent.cpp
*/

#include "TrueComponent.hpp"
#include "IComponent.hpp"

nts::TrueComponent::TrueComponent()
{
}

nts::TrueComponent::~TrueComponent()
{
}

nts::Tristate nts::TrueComponent::compute(std::size_t pin)
{
    return nts::TRUE;
}

const std::vector<Pin> * nts::TrueComponent::getLinks () const
{
    return &links;
}


std::vector<Pin> * nts::TrueComponent::getLinks()
{
    return &links;
}

void nts::TrueComponent::display(std::ostream &os)
{
    os << "TrueComponent" << std::endl;
}