/*
** EPITECH PROJECT, 2023
** B-ASM-400-PAR-4-1-bsasmminilibc-jean-cyprien.roux
** File description:
** test_noflage.h
*/
#ifndef TEST_NOFLAGE_H_
	#define TEST_NOFLAGE_H_
    #include <stdio.h>
    #include <string.h>
#endif /*TEST_NOFLAGE_H_*/