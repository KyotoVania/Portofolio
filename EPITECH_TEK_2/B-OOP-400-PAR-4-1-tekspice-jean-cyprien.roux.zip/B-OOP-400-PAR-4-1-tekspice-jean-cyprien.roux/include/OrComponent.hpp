/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** OrComponent.hpp
*/
#ifndef ORCOMPONENT_HPP_
	#define ORCOMPONENT_HPP_

#include "AComponent.hpp"

namespace nts {
    class OrComponent : public nts::AComponent {
        public:
            OrComponent();
            ~OrComponent();
            nts::Tristate compute(std::size_t pin);
            std::vector<Pin> * getLinks();
            const std::vector<Pin> * getLinks() const;
            void display(std::ostream &os);
            void setStates(nts::Tristate state) {};

    private:
            std::vector<Pin> links = std::vector<Pin> (3);
    };
};

#endif /*ORCOMPONENT_HPP_*/