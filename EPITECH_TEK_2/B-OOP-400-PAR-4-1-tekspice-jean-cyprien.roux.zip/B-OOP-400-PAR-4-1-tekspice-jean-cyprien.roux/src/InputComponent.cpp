/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** InputComponent.cpp
*/

#include "InputComponent.hpp"

nts::InputComponent::InputComponent()
{
    state = nts::UNDEFINED;
}

nts::InputComponent::~InputComponent()
{
}

nts::Tristate nts::InputComponent::compute(std::size_t pin)
{
    if (pin == 1) {
        if (links[0].other)
            return getLink(1);
        return state;
    }
    return nts::UNDEFINED;
}

void nts::InputComponent::setStates(nts::Tristate state)
{
    this->nextState = state;
}

void nts::InputComponent::simulate(std::size_t tick)
{
    this->state = this->nextState;
}


const std::vector<Pin> * nts::InputComponent::getLinks () const
{
    return &links;
}

std::vector<Pin> * nts::InputComponent::getLinks()
{
    return &links;
}

void nts::InputComponent::display(std::ostream &os)
{
    os << "InputComponent" << std::endl;
}