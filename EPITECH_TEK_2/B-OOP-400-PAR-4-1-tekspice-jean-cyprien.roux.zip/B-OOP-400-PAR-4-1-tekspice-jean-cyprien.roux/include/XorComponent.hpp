/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** XorComponent.hpp
*/
#ifndef XORCOMPONENT_HPP_
	#define XORCOMPONENT_HPP_

#include "AComponent.hpp"

namespace nts {
    class XorComponent : public nts::AComponent {
        public:
            XorComponent();
            ~XorComponent();
            nts::Tristate compute(std::size_t pin);
            std::vector<Pin> * getLinks();
            const std::vector<Pin> * getLinks() const;
            void display(std::ostream &os);
        void setStates(nts::Tristate state) {};

    private:
        std::vector<Pin> links = std::vector<Pin> (3);
    };
};
#endif /*XORCOMPONENT_HPP_*/