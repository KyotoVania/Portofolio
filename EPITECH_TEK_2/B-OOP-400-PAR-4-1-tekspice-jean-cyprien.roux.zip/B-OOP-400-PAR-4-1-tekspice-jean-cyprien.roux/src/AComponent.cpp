/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-tekspice-jean-cyprien.roux
** File description:
** AComponent.cpp
*/

#include "AComponent.hpp"


nts::AComponent::AComponent()
{
}

nts::AComponent::~AComponent()
{
}

//I want to make a few function
void nts::AComponent::setLink(std::size_t pin, IComponent &other, std::size_t otherPin)
{
    pin--;
    std::vector<Pin> *links = getLinks();
    if (links == NULL)
        throw std::runtime_error("Pin not found");
    if (pin >= links->size())
        throw std::runtime_error("Pin not found");
    if ((*links)[pin].other != NULL && (*links)[pin].otherPin == otherPin) {
        // The link has already been established
        return;
    }

    (*links)[pin].other = &other;
    (*links)[pin].otherPin = otherPin;
   // other.setLink(otherPin, *this, pin + 1);
}

nts::Tristate nts::AComponent::getLink(std::size_t pin) const
{
    pin--;
    const std::vector<Pin> *links = getLinks();
    if (links == NULL || pin >= links->size())
        throw std::runtime_error("Pin not found");
    //create variable to store the value of the pin
    const Pin &pinLink = (*links)[pin];
    if (pinLink.other == NULL) {
		std::cout << "component : " << this << std::endl;
		std::cout << "Pin : " << pin << std::endl;
        throw std::runtime_error("Pin not linked");
    }
    // the type of this
    /*
    std::cout << "component : " << this << std::endl;
    std::cout << "Pin : " << pin << std::endl;
    std::cout << "Link : " << pinLink.other << std::endl;
    std::cout << "Other : " << pinLink.otherPin << std::endl;
     */
    nts::Tristate result = (pinLink.other)->compute(pinLink.otherPin);
    return result;
}

void nts::AComponent::simulate(std::size_t tick)
{
    (void) tick;
}


