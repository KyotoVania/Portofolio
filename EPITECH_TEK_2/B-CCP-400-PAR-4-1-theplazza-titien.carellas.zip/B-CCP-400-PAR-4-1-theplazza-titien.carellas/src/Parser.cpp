#include "Parser.hpp"
#include <iostream>
#include <map>
#include <vector>
#include <sstream>
#include <iterator>
#include <algorithm>
#include "Pizza.hpp"
Parser::Parser() {
}

Parser::~Parser() {
}
/*
* Pizza ordering MUST respect the following grammar:
S := TYPE SIZE NUMBER [; TYPE SIZE NUMBER ]*
TYPE := [ a .. zA .. Z ]+
SIZE := S | M | L | XL | XXL
NUMBER := x [1..9][0..9]*
Ordering example which is grammatically valid:
regina XXL x2; fantasia M x3; margarita S x1
*/
Command * Parser::parseCommand(std::string cmd, int id) {
	Command * command = new Command(id);

    std::istringstream ss(cmd);
    std::string pizzaOrder;

    // Iterate over each pizza order in the command (split by ';')
    while (std::getline(ss, pizzaOrder, ';')) {
        std::istringstream pizzaStream(pizzaOrder);
        std::vector<std::string> pizzaDetails((std::istream_iterator<std::string>(pizzaStream)), std::istream_iterator<std::string>());

        // If pizzaDetails doesn't have exactly 3 elements (type, size, quantity), it's not a valid pizza order
        if (pizzaDetails.size() != 3) {
            // Handle error: invalid pizza order
            std::cout << "Invalid pizza order: " << pizzaOrder << std::endl;
            continue;
        }

        std::string typeString = pizzaDetails[0];
        std::string sizeString = pizzaDetails[1];
        int quantity = std::stoi(pizzaDetails[2].substr(1));  // remove 'x' and convert to int

        // Convert type and size strings to enum values
        PizzaType type = getPizzaTypeFromString(typeString);
        PizzaSize size = getPizzaSizeFromString(sizeString);

        if (type == PizzaType::None || size == PizzaSize::Null) {
            // Handle error: invalid pizza type or size
            std::cout << "Invalid pizza type or size: " << typeString << ", " << sizeString << std::endl;
            continue;
        }

        // Create pizza object and add it to the command
        Pizza * pizza = new Pizza(type, size);
        command->addPizza(pizza, quantity);
    }

    return command;
}
