/*
** EPITECH PROJECT, 2023
** B-ASM-400-PAR-4-1-bsasmminilibc-jean-cyprien.roux
** File description:
** test_noflage.c
*/

#include "test_noflage.h"

int main (void)
{
    char *str = strdup("Hello World");
    int result = strlen(str);
    printf("strlen(\"Hello World\") = %d (expected 11) \n", result);
    return 0;
}