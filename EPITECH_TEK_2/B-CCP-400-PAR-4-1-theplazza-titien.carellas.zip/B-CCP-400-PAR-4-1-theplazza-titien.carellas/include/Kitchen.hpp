/*
** EPITECH PROJECT, 2023
** B-CCP-400-PAR-4-1-theplazza-titien.carellas
** File description:
** Kitchen.hpp
*/
#ifndef KITCHEN_HPP_
    #define KITCHEN_HPP_

#include "Command.hpp"
#include "Pizza.hpp"
#include "shared.hpp"
#include "Chef.hpp"
#include <memory>
#include <mutex>
#include <queue>
#include <sys/ipc.h>
#include <sys/shm.h>

class Kitchen {
public:
    Kitchen(int id, int nbChef, int timeMultiplier, commu_t * sharedMemory);
	~Kitchen();
    void receiveOrder(Command command);
	void handleDetectedCommand();
	void addCommand(Command command);
    int getId() const {return _id;}
    int getMaxPizza() const {return _maxPizza;}
    std::queue<Pizza *> getPizzas() const {return _pizzas;}
    std::vector<std::shared_ptr<Chef>> getChefs() const {return _chefs;}
    void setMaxPizza(int maxPizza) {this->_maxPizza = maxPizza;}
    int getNumberOfPizza() const {return _pizzas.size();}
	int getAvailableSpace();
	void run();
	bool isBusy() const {return _isBusy;}
	void setBusy(bool busy) {_isBusy = busy;}
	bool isClosed() const {return _isClosed;}
	void setClosed(bool closed) {_isClosed = closed;}
	bool isFull();
	bool allChefsFree();
	bool willBeFull(std::size_t nbPizza) const;
	void setFull();
private:
    int _id;
    int _nbChef;
    int _timeMultiplier;
    bool _isFull;
    bool _isClosed;
	bool _isBusy;
	int state;
    std::vector<std::thread> _chefThreads;
	std::queue<Pizza *> _pizzas;
	std::queue<Pizza *>::size_type _maxPizza;
    std::vector<std::shared_ptr<Chef>> _chefs;
    std::shared_ptr<std::mutex> _mutex;
	std::shared_ptr<std::condition_variable> _cv;
	std::shared_ptr<std::condition_variable>  _cvAddCommand;
	int _sharedMemoryId;
	commu_t * _sharedMemory;
    int _numReadyChefs = 0;
    std::condition_variable _allChefsReady;
    std::mutex _readyMutex;
};

#endif /*KITCHEN_HPP_*/
