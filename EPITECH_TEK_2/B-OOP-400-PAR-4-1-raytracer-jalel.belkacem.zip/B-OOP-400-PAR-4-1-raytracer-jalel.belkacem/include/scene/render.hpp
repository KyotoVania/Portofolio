/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** render.hpp
*/
#ifndef RENDER_HPP_
	#define RENDER_HPP_
	#include "utils/shared.hpp"
	#include "scene/scene_config.hpp"
	#include "materials/flat_color.hpp"
	#include <thread>
	#include <fstream>
	#include <iostream>
	#include <vector>
	#include <mutex>
	#include <condition_variable>

class Observer {
public:
    virtual void update(int percentage) = 0;
};

class ProgressBar : public Observer {
public:
    void update(int percentage) override {
        const int size = 50;  // Size of the progress bar (50 characters)

        std::cout << "[";
        for (int i = 0; i < size; ++i) {
            if (i < (percentage/2)) {
                std::cout << "=";  // Completed part of the progress bar
            }
            else if (i == (percentage/2)) {
                std::cout << ">";  // Current position in the progress bar
            }
            else {
                std::cout << " ";  // Remaining part of the progress bar
            }
        }
        std::cout << "] " << percentage << "%\r";  // Use '\r' to return the cursor to the beginning of the line
        std::cout << std::flush;  // Manually flush the output
    }
};


class Render
{

private:
	ColorCalculation _ColorCalculation;
	std::vector<Observer*> _observers;
    std::mutex _mutex;
    std::condition_variable _cv;
    int _finishedThreads = 0;

	void notify() {
    	std::unique_lock<std::mutex> lock(_mutex);
    	for (auto observer : _observers) {
       		int percentage = (_finishedThreads * 100) / _numThreads;
        	observer->update(percentage);
    	}
	}


	void render_thread(SceneConfig &scene_config, std::vector<std::vector<Vec3>>& pixels, int samples, int maxDepth, int start, int end) {
		for (int i = start; i < end; ++i) {
			for (int j = 0; j < scene_config._width; ++j) {
				Vec3 color = _ColorCalculation.averageColorForPixel(scene_config, samples, j, i, maxDepth);
				pixels[i][j] = color;
			}
		}

		{
			std::unique_lock<std::mutex> lock(_mutex);
			_finishedThreads++;
		}
		_cv.notify_all();
		notify();
	}

	void joinThreads(std::vector<std::thread>& threads) {
		for (auto& thread : threads) {
			if (thread.joinable()) {
				thread.join();
				_cv.notify_all();
			}
		}
		std::cout << "All threads joined." << std::endl;
	}

	void writePixelsToFile(const std::string& filename, const std::vector<std::vector<Vec3>>& pixels, const SceneConfig& scene_config) {
		std::ofstream file(filename);
		file << "P3\n" << scene_config._width << " " << scene_config._height << "\n255\n";
		for (const auto& row : pixels) {
			for (const auto& pixel : row) {
				file << static_cast<int>(pixel.x) << " " << static_cast<int>(pixel.y) << " " << static_cast<int>(pixel.z) << "\n";
			}
		}
		file.close();
	}

public:
	int _numThreads = 0;
	void addObserver(Observer* observer) {
        _observers.push_back(observer);
    }
	void render_scene(SceneConfig &scene_config, const std::string &filename, int maxDepth, int samples) {
		{
			_numThreads = std::thread::hardware_concurrency(); 
			std::vector<std::thread> threads(_numThreads);
			std::vector<std::vector<Vec3>> pixels(scene_config._height, std::vector<Vec3>(scene_config._width));

			for (int t = 0; t < _numThreads; ++t) {
				int start = (scene_config._height / _numThreads) * t;
				int end = (t == _numThreads - 1) ? scene_config._height : start + (scene_config._height / _numThreads);

				threads[t] = std::thread(&Render::render_thread, this, std::ref(scene_config), std::ref(pixels), samples, maxDepth, start, end);
			}   

			joinThreads(threads);
			writePixelsToFile(filename, pixels, scene_config);
		}
	}
};

#endif /*RENDER_HPP_*/
