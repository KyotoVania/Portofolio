#!/bin/bash

echo "USER Anonymous"
sleep 1s
echo "PASS"
sleep 1s
echo "PASV"
sleep 1s
echo "DOOP"
sleep 1s
echo "STOR r&s_file/cool.txt"
sleep 1s
echo "NOOP"
sleep 1s
echo "prout"
sleep 1s
echo "QUIT"





