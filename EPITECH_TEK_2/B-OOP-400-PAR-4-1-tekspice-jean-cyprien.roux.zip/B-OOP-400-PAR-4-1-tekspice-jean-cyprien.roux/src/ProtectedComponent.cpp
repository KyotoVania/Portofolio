/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** ProtectedComponent.cpp
*/

#include "ProtectedComponent.hpp"

nts::ProtectedComponent::ProtectedComponent()
{
}

nts::ProtectedComponent::~ProtectedComponent()
{
}

nts::Tristate nts::ProtectedComponent::compute(std::size_t pin)
{
    return nts::UNDEFINED;
}

const std::vector<Pin> * nts::ProtectedComponent::getLinks() const
{
    return &links;
}

std::vector<Pin> * nts::ProtectedComponent::getLinks()
{
    return &links;
}

void nts::ProtectedComponent::display(std::ostream &os)
{
    os << "ProtectedComponent" << std::endl;
}

void nts::ProtectedComponent::setStates(nts::Tristate state)
{
}

void nts::ProtectedComponent::simulate(std::size_t tick)
{
}

// Path: src/OutputComponent.cpp

