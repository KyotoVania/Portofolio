{-
-- EPITECH PROJECT, 2023
-- Wolfran
-- File description:
-- Main.hs
-}

import Data.Bits
import System.Environment (getArgs)
import Control.Monad (when)
import System.Exit ( exitWith, ExitCode(ExitFailure) )

type Rule = Int
type Row = [Bool]

exitWithError :: String -> IO ()
exitWithError msg = putStrLn msg >> exitWith (ExitFailure 84)

ruleFromNum :: Rule -> (Bool -> Bool -> Bool -> Bool)
ruleFromNum r =
    \a b c -> testBit r (4 * fromEnum a + 2 * fromEnum b + fromEnum c)

rowToString :: Row -> String
rowToString row = map (\x -> if x then '*' else ' ') row

setElem :: Int -> bool -> [bool] -> [bool]
setElem index value list = take index list ++ [value] ++ drop (index + 1) list


addPadding :: String -> Int -> String
addPadding row windowSize =
  let rowSize = length row
      paddingSize = (windowSize - rowSize) `div` 2
  in if rowSize >= windowSize then row
     else replicate (paddingSize + 1)  ' ' ++ row
      ++ replicate (paddingSize) ' '


displayStringRow :: String -> Int -> Int -> IO ()
displayStringRow row windowSize move =
  if length row > windowSize then
    let paddingSize = (windowSize) `div` 2 - length row `div` 2
        startIdx = max 0 (move - paddingSize)
        endIdx = min (length row) (startIdx + windowSize)
        row' = drop startIdx row
        row'' = take (endIdx - startIdx) row'
    in putStrLn $ addPadding row'' windowSize
  else
    putStrLn $ addPadding row windowSize

initFirstRow :: Row
initFirstRow = foldr (\i acc -> setElem i True acc) (replicate 5 False) [2]

applyRule :: (Bool -> Bool -> Bool -> Bool) -> Row -> Row
applyRule rule row =
  let newRow = map (\(a, b, c) -> rule a b c)
               $ zip3 row (tail row) (tail $ tail row)
  in [False, False] ++ newRow ++ [False, False]

loopRows :: (Bool -> Bool -> Bool -> Bool) -> Row -> Int -> Int -> Int -> Int -> IO ()
loopRows rule row 0 _ _ _ = return ()
loopRows rule row numLines winSize move 0 =
  let newRow = applyRule rule row
      newRowString = rowToString newRow
  in printInitialRow newRow winSize move
   >> loopRows rule newRow (numLines - 1) winSize move 0
loopRows rule row numLines winSize move startNum | startNum > 0 =
  loopRows rule (applyRule rule row) numLines winSize move (startNum - 1)
loopRows _ _ _ _ _ _ = return ()

parseArgs :: [String] -> (Int, Int, Int, Int, Int)
parseArgs args =
  let lookupArg key = case lookup key (zip args (tail args)) of
                        Nothing -> Nothing
                        Just x  -> Just (read x :: Int)
      startNum = maybe 0 id (lookupArg "--start")
      numLines = maybe 0 id (lookupArg "--lines")
      winSize  = maybe 80 id (lookupArg "--window")
      move     = maybe 0 id (lookupArg "--move")
      numLinesTrue = if startNum <= 0 then numLines - 1 else numLines
  in (startNum, numLines, winSize, move, numLinesTrue)

printInitialRow :: Row -> Int -> Int -> IO ()
printInitialRow row winSize move =
  let row_string = rowToString row
  in displayStringRow row_string winSize move

checkArgs :: [String] -> IO ()
checkArgs [] = exitWithError "program must take at least 2 arguments"
checkArgs [_] = exitWithError "program must take at least 2 arguments"
checkArgs args
  | length args `mod` 2 == 1 = exitWithError "arguments must be in pairs"
  | ruleNum < 0 || ruleNum > 255 =
    exitWithError "Rule number must be between 0 and 255"
  | otherwise = return ()
  where
    ruleNum = maybe (error "Rule number is mandatory") read
              $ lookup "--rule" (zip args (tail args))

main :: IO ()
main = do
  args <- getArgs
  checkArgs args
  let ruleNum = read $ head $ tail $ dropWhile (/= "--rule") args :: Int
      rule = ruleFromNum ruleNum
      (startNum, numLines, winSize, move, numLinesTrue) = parseArgs args
      row = initFirstRow
      start = if startNum <= 0 then 0 else startNum - 1
  when (startNum <= 0) $ printInitialRow row winSize move
  loopRows rule row numLinesTrue winSize move start
