/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** XorComponent.cpp
*/

#include "XorComponent.hpp"

nts::XorComponent::XorComponent()
{
}

nts::XorComponent::~XorComponent()
{
}

nts::Tristate nts::XorComponent::compute(std::size_t pin)
{
    nts::Tristate state = getLink(1);
    nts::Tristate state2 = getLink(2);
    if (pin == 3) {
        if (getLink(1) == nts::FALSE && getLink(2) == nts::FALSE)
            return nts::FALSE;
        else if (getLink(1) == nts::FALSE && getLink(2) == nts::TRUE)
            return nts::TRUE;
        else if (getLink(1) == nts::TRUE && getLink(2) == nts::FALSE)
            return nts::TRUE;
        else if (getLink(1) == nts::TRUE && getLink(2) == nts::TRUE)
            return nts::FALSE;
        else if (getLink(1) == nts::UNDEFINED || getLink(2) == nts::UNDEFINED)
            return nts::UNDEFINED;
        else
            return nts::UNDEFINED;
    }
    return nts::UNDEFINED;
}

const std::vector<Pin> * nts::XorComponent::getLinks() const
{
    return &links;
}

std::vector<Pin> * nts::XorComponent::getLinks()
{
    return &links;
}

void nts::XorComponent::display(std::ostream &os)
{
    os << "XorComponent" << std::endl;
}