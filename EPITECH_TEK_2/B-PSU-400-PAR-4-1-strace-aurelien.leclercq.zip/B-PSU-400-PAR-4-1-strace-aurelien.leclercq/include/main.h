/*
** EPITECH PROJECT, 2023
** Strace
** File description:
** main.h
*/

#ifndef MAIN_H_
    #define MAIN_H_
    #include "options.h"
    #include "syscall.h"
    #include "trace.h"

void detach_and_exit(pid_t pid);
void print_detailed_params(pid_t child, syscall_t *syscalls,
    long long index, options_t *opts);
#endif /*MAIN_H_*/
