/*
** EPITECH PROJECT, 2023
** Strace
** File description:
** main.c
*/

#include "trace.h"
#include "main.h"
#include "syscall_table.h"

int main(int argc, char **argv)
{
    options_t opts = parse_options(argc, argv);
    syscall_t tabled[330];
    memcpy(tabled, table, sizeof(table));

    if (argc < 2) {
        fprintf(stderr, "Usage: %s [-s] [-p] prog args\n", argv[0]);
        exit(1);
    }
    if (opts.p_option) {
        return trace_process(argv, opts, tabled);
    }

    pid_t child = fork();
    if (child == 0) {
        return do_child(argc - optind, argv + optind);
    } else {
        return print_exit(do_trace(child, &opts, tabled));
    }
}
