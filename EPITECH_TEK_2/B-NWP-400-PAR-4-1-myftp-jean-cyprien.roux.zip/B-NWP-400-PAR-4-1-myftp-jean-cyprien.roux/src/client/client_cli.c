/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** client.c
*/

#include "client.h"

int client_loop_check(client_t *client, char *line, char *response)
{
    size_t size = 0;
    if (getline(&line, &size, stdin) == -1) {
        printf("Error reading stdin (client_loop)\n");
        return (84);
    }
    send_server_response(client, line);
    response = read_server_response(client);
    handle_passive_mode(client, response, line);
    handle_active_mode(client, line);
    handle_retrieve_mode(client, response, line);
    handle_store_mode(client, line);
    free(response);
    response = NULL;
    return 0;
}

int client_loop(client_t *client)
{
    char *line = NULL;
    char *response = NULL;

    if ((response = read_server(client->fd)) == NULL) {
        printf("Error reading server response"
            " from fd %d (client_loop) \n", client->fd);
        return (84);
    }
    while (1) {
        printf(">");
        if (client_loop_check(client, line, response) == 84) {
            free(line);
            return 84;
        }
        free(response);
        response = NULL;
    }
    free(line);
    return 0;
}
