/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** basic_operation.cpp
*/

#include "myftp.h"

int close_client(int client_fd, server_t *server)
{
    if (close(client_fd) == -1)
        return (84);
    server->client_count--;
    return (0);
}

int create_socket(void)
{
    int fd = socket(AF_INET, SOCK_STREAM, 0);

    if (fd == -1) {
        perror("socket failed");
        return (84);
    }
    if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR,
        &(int){1}, sizeof(int)) == -1) {
        perror("setsockopt failed");
        return (84);
    }
    return (fd);
}
