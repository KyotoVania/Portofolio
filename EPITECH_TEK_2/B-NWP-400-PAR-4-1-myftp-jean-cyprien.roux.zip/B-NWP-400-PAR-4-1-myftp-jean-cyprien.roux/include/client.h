/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** client.h
*/

#ifndef CLIENT_H_
    #define CLIENT_H_
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <unistd.h>
    #include <sys/types.h>
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <arpa/inet.h>
    #include <stdbool.h>
    #include <sys/types.h>
    #include <sys/wait.h>
    #include <signal.h>
    #include <time.h>
    #include <sys/types.h>
    #include <sys/stat.h>
    #include <fcntl.h>

enum{
    is_passive,
    is_active,
    undefined
};

typedef struct client_s {
    int fd;
    int data_fd;
    char *ip;
    int port;
    int data_port;
    char *buffer;
    int buffer_pos;
    int buffer_size;
    int status;
    char *working_dir;
    int states;
    struct sockaddr_in client_addr;
    struct sockaddr_in data_addr;
    bool passive;
    socklen_t client_addr_len;
    socklen_t data_addr_len;
} client_t;


int create_client(client_t *client, char *ip, int port);
int connect_to_server(client_t *client);
char * read_server(int fd);
int send_server(int fd, char *msg);
int client_loop(client_t *client);
int login_to_server(client_t *client);
int create_socket(void);
int activate_passive_mode(char *msg, client_t *client);
int retrieve_passive_mode(client_t *client, char *pathname);
int activate_active_mode(char *port, client_t *client);
int read_and_write_client(int read_fd, int write_fd);
int retrieve_file(client_t *client, char *command_check, char *file_name);
int send_server_response(client_t *client, char* line);
char *read_server_response(client_t *client);
int store_client(client_t *client, char *line);
int parse_ip_port_from_pasv_response_sub(char **end, char **tok,
    char **ip, char *msg);
int parse_ip_port_from_pasv_response_sub_sub(char **ip, char **tok);
int parse_ip_port_from_pasv_response(char *msg, char **ip, int *port);
int connect_toserver_passive(char *ip, int port, client_t *client);
int parse_ip_port_from_pasv_response_port(char *tok, int port);
void handle_store_mode(client_t *client, char* line);
void handle_retrieve_mode(client_t *client, char* response, char* line);
void handle_active_mode(client_t *client, char* line);
void handle_passive_mode(client_t *client, char* response, char* line);
#endif /*CLIENT_H_*/
