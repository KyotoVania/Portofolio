/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** active_operation.c
*/

#include "myftp.h"

int set_actv_valuesettings(fd_node_t *node, char *ip, char *port)
{
    if (node->data_fd == 84)
        return (84);
    node->data_addr.sin_family = AF_INET;
    node->data_addr.sin_addr.s_addr = inet_addr(ip);
    node->data_addr_len = sizeof(node->data_addr);
    node->data_addr.sin_port = htons(atoi(port));
    node->data_port = atoi(port);
    node->states = is_active;
    node->ip = strdup(ip);
    if (node->ip == NULL)
        return (84);
    return (0);
}

int set_actv_connection(fd_node_t *node)
{
    if (connect(node->data_fd,
    (const struct sockaddr *)&node->data_addr,
            node->data_addr_len) == -1) {
        perror("connect");
        return (84);
    }
    if (node->data_fd == -1) {
        if (send_client_line(node->fd,
        "425 Can't open data connection.\n") == 84)
            return (84);
        return (425);
    }
    return (0);
}

int set_actv(fd_node_t *node, char *ip, char *port)
{
    int res = 0;

    if (check_iflogged(node) == 532)
        return (84);
    if (node->data_fd != 0) {
        close(node->data_fd);
        node->data_fd = 0;
    }
    if (send_client_line(node->fd,
    "trying to connect to data server\n") == 84)
        return (84);
    node->data_fd = create_socket();
    if (set_actv_valuesettings(node, ip, port) == 84)
        return (84);
    res = set_actv_connection(node);
    if (res != 0)
        return (res);
    return (200);
}
