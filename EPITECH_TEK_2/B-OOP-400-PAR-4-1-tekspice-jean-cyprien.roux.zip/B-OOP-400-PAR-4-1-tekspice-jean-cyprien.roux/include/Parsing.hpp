/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** Parsing.hpp
*/
#ifndef PARSING_HPP_
	#define PARSING_HPP_

#include "IComponent.hpp"
#include "AComponent.hpp"
#include "PinComponent.hpp"
#include "InputComponent.hpp"
#include "OutputComponent.hpp"
#include "AndComponent.hpp"
#include "NandComponent.hpp"
#include "TrueComponent.hpp"
#include "FalseComponent.hpp"
#include "OrComponent.hpp"
#include "XorComponent.hpp"
#include "NotComponent.hpp"
#include "NorComponent.hpp"
#include "ClockComponent.hpp"
#include "SubCircuit.hpp"
#include <string>
#include <vector>
#include <fstream>

class Parsing {
    public:
        Parsing();
        Parsing(const std::string file_name, std::map<std::string, nts::AComponent *> &componentsMap);
        ~Parsing();
        void parseFile(std::map<std::string, nts::AComponent *> &componentsMap);
        bool isComponentValid(const std::string &component, std::map<std::string, nts::AComponent *> &componentsMap);
        bool checkLink(const std::string &link, std::map<std::string, nts::AComponent *> &componentsMap);
        bool isArealComponent(const std::string &component);

protected:
    std::string file_name;
    std::vector<std::string> valid_components = {"input", "output", "true", "false", "clock", "or", "and", "nand", "nor", "not", "xor", "4001", "4011", "4030", "4069", "4071", "4081"};
    private:
};

#endif /*PARSING_HPP_*/