/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** SubCircuit.cpp
*/

#include "SubCircuit.hpp"

void nts::SubCircuit::parsing(std::string filename)
{
    std::ifstream file(filename);
    std::string line;
    std::size_t size_tmp = 1;
    std::pair<std::string, std::size_t> tmp;
    std::pair<std::string, std::size_t> tmp2;

    if (file.is_open()) {
        while (getline(file, line)) {
            if (line == ".chipsets:") {
                while (getline(file, line)) {
                    if (line == ".links:") {
                        ("Now we go to the links parts !\n");
                        break;
                    }
                    if (line.find("input") != std::string::npos) {
						nts::InputComponent *input = new nts::InputComponent();
                        _componentsMap[line.substr(6, line.size())] =  input;
						Pin *pin = new Pin();
						links.push_back(*pin);
                        input->setLink(1, *this, size_tmp);
                        size_tmp++;
                    }
                    if (line.find("output") != std::string::npos) {
                        nts::OutputComponent *output = new nts::OutputComponent();
                        _componentsMap[line.substr(7, line.size())] =  output;
						Pin *pin = new Pin();
						links.push_back(*pin);
                        this->setLink(size_tmp, *output, 1);
                        size_tmp++;
					}
                    if (line.find("or") != std::string::npos) {
                        nts::OrComponent *orComponent = new nts::OrComponent();
                        _componentsMap[line.substr(3, line.size())] = orComponent;
                    }
                    //check if the line start with and
                    if (line.find("and") != std::string::npos) {
                        _componentsMap[line.substr(4, line.size())] = new nts::AndComponent();
                    }
                    if (line.find("nand") != std::string::npos) {
                        _componentsMap[line.substr(5, line.size())] = new nts::NandComponent();
                    }
                    //check if the line start with xor
                    if (line.find("xor") != std::string::npos) {
                        _componentsMap[line.substr(4, line.size())] = new nts::XorComponent();
                    }
                    //check if the line start with not
                    if (line.find("not") != std::string::npos) {
                        _componentsMap[line.substr(4, line.size())] = new nts::NotComponent();
                    }
                    if (line.find("nor") != std::string::npos) {
                        _componentsMap[line.substr(4, line.size())] = new nts::NorComponent();
                    }
                    //check if the line start with clock
                    if (line.find("clock") != std::string::npos) {
                        _componentsMap[line.substr(6, line.size())] = new nts::ClockComponent();
                    }
                    //check if the line start with true
                    if (line.find("true") != std::string::npos) {
                        nts::TrueComponent *trueComponent = new nts::TrueComponent();
                        _componentsMap[line.substr(5, line.size())] = trueComponent;
                        Pin *pin = new Pin();
                        links.push_back(*pin);
                        this->setLink(size_tmp, *trueComponent, 1);
                        size_tmp++;
                    }
                    //check if the line start with false
                    if (line.find("false") != std::string::npos) {
                        nts::FalseComponent *falseComponent = new nts::FalseComponent();
                        _componentsMap[line.substr(6, line.size())] = falseComponent;
                        Pin *pin = new Pin();
                        links.push_back(*pin);
                        this->setLink(size_tmp, *falseComponent, 1);
                        size_tmp++;
                    }
                    if (line.find("protected") != std::string::npos) {
                        nts::ProtectedComponent *protectedComponent = new nts::ProtectedComponent();
                        _componentsMap[line.substr(9, line.size())] = protectedComponent;
                        Pin *pin = new Pin();
                        links.push_back(*pin);
                        this->setLink(size_tmp, *protectedComponent, 1);
                        size_tmp++;
                    }
                }
            }
            if (line == ".links:") {
                while (getline(file, line)) {
                    tmp.first = line.substr(0, line.find(":"));
                    tmp.second = std::stoi(line.substr(line.find(":") + 1, line.find(" ")));
                    tmp2.first = line.substr(line.find(" ") + 1, line.find(":", line.find(":") + 1) - line.find(" ") - 1);
                    tmp2.second = std::stoi(line.substr(line.find(":", line.find(":") + 1) + 1, line.size()));
                    //we need to link the pin of the component to the pin of the this component
					this->_componentsMap[tmp.first]->setLink(tmp.second, *this->_componentsMap[tmp2.first], tmp2.second);
                }
            }
        }
    }
    file.close();
}

nts::SubCircuit::SubCircuit(const std::string &file)
{
    std::map<std::string, std::string> component_path { {"4071", "4071_or.nts"}};
    component_path.insert(std::pair<std::string, std::string>("4001", "4001_nor.nts"));
    component_path.insert(std::pair<std::string, std::string>("4011", "4011_nand.nts"));
    component_path.insert(std::pair<std::string, std::string>("4030", "4030_xor.nts"));
    component_path.insert(std::pair<std::string, std::string>("4069", "4069_not.nts"));
    component_path.insert(std::pair<std::string, std::string>("4081", "4081_and.nts"));
    parsing("parsing_file/" + component_path[file]);
}

nts::SubCircuit::~SubCircuit()
{
}

nts::Tristate nts::SubCircuit::compute(std::size_t pin)
{
    pin--;
    return links[pin].compute();
}

const std::vector<Pin> *nts::SubCircuit::getLinks() const
{
    return &links;
}

std::vector<Pin> *nts::SubCircuit::getLinks()
{
    return &links;
}

void nts::SubCircuit::display(std::ostream &os)
{
    os << "SubCircuit" << std::endl;
}