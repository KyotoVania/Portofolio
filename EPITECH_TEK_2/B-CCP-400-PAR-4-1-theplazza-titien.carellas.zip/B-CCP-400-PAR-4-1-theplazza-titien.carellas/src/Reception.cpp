/*
** EPITECH PROJECT, 2023
** B-CCP-400-PAR-4-1-theplazza-titien.carellas
** File description:
** Reception.cpp
*/

#include "Reception.hpp"

Reception::Reception(int argc, char **argv)
    : _options(argc, argv)  // Initialize _options using the constructor
{
    std::cout << "Reception trying to initialize shmget" << std::endl;
	_memid = shmget(0x00042473, sizeof(commu_t), 0700 | IPC_CREAT);
	if (_memid == -1) {
    	std::cerr << "shmget failed while trying to create new memory. Attempting to attach to existing memory..." << std::endl;
    	_memid = shmget(0x00042473, sizeof(commu_t), 0700);
    	if (_memid == -1) {
        	std::cerr << "shmget failed while trying to attach to existing memory." << std::endl;
        	exit(1);
    	}
	}

    _shared_mem = (commu_t*) shmat(_memid, nullptr, 0);
    if ((void*)_shared_mem == (void*)-1) {
        std::cerr << "shmat failed\n";
        exit(1);
    }
    _shared_mem->_commandAdded = false; // Initialize to false
	_shared_mem->_commandProcessed = false; // Initialize to false
	sem_init(&_shared_mem->sem, 1, 0);

    //create the kitchen
    std::shared_ptr<Kitchen> kitchen = std::make_shared<Kitchen>(1, _options.getChefNumber(), _options.getCookingTimeMultiplier(), _shared_mem);

    pid_t pid = fork();
    if (pid == -1) {
        // Error
        std::cerr << "Error: fork() failed" << std::endl;
        exit(84);
    } else if (pid == 0) {
        // This is the child process (kitchen)
        kitchen->run(); // Pass shared memory to kitchen
        exit(0); // exit when done
    }

    // Parent process continues here
    _kitchens.push_back(kitchen);
}



Reception::~Reception()
{
    shmdt(_shared_mem);
	sem_destroy(&_shared_mem->sem);
}

void Reception::receiveOrder(Command * command)
{
    std::cout << "Reception: received order" << std::endl;

    int remainingPizzas = command->getNumberOfPizza();
    std::cout << "Reception: number of pizzas in command: " << remainingPizzas << std::endl;

    while (remainingPizzas > 0) {
        bool pizzaAdded = false;

        for (auto& kitchen : _kitchens) {
            if (!kitchen->isBusy()) {
                int availableSpace = kitchen->getAvailableSpace();
                if (availableSpace > 0) {
                    std::cout << "Reception: kitchen id:" << kitchen->getId() << " still have some place" << std::endl;

                    while (availableSpace > 0 && remainingPizzas > 0) {
                        Command partialCommand = command->splitCommand(1);  // Split only one pizza
                        std::cout << "_shared_mem->_order number of pizza = " << _shared_mem->number << "\t size : " << pizzaSizeMap[_shared_mem->size] << "\t type : " << pizzaTypeMap[_shared_mem->type] << std::endl;
                        _shared_mem->_commandAdded = true;
                        sem_post(&_shared_mem->sem);
						while (!_shared_mem->_commandProcessed) {
    						// Wait for the command to be processed
						    std::this_thread::sleep_for(std::chrono::milliseconds(100)); // sleep to prevent busy waiting
						}
						_shared_mem->_commandProcessed = false;  // Reset the flag before adding a new command

					    std::this_thread::sleep_for(std::chrono::milliseconds(100)); // sleep to prevent busy waiting
						std::cout << "Reception: sending command to kitchen" << std::endl;
                        partialCommand.updateCommu(_shared_mem); 
                        --availableSpace;
                        --remainingPizzas;
                    }
                    std::cout << "Reception: remaining pizzas: " << remainingPizzas << std::endl;
                    pizzaAdded = true;
                }
            }

            if (remainingPizzas <= 0) {
                break;
            }
        }

		if (remainingPizzas > 0 && !pizzaAdded) {

        	std::shared_ptr<Kitchen> newKitchen = std::make_shared<Kitchen>(_kitchens.size() + 1, _options.getChefNumber(), _options.getCookingTimeMultiplier(), _shared_mem);    
   			pid_t pid = fork();
       		if (pid == -1) {
            // Handle error here
        	} else if (pid == 0) {
            	// This is the child process (kitchen)
            	// TODO: Add the code for the kitchen process here
            	newKitchen->run();
            	exit(0); // exit when done
        	}
            Command remainingCommand = command->splitCommand(newKitchen->getAvailableSpace());
            remainingPizzas -= newKitchen->getAvailableSpace();
            _kitchens.push_back(newKitchen);
			//TODO update like above
            std::cout << "Reception: created new kitchen" << std::endl;
            std::cout << "Reception: kitchen id: " << newKitchen->getId() << std::endl;
            std::cout << "Reception: Pizzas in kitchen: " << newKitchen->getNumberOfPizza() << std::endl;
			std::cout << "Reception: remaining pizzas: " << remainingPizzas << std::endl;
        }
    }
}


void Reception::createKitchen() {
}


bool Kitchen::isFull() {
    return _pizzas.size() >= _maxPizza;
}

bool Kitchen::allChefsFree() {
    for (auto &chef : _chefs) {
        if (chef->isBusy())
	        return false;
    }
    return true;
}
void Kitchen::setFull() {
    if (_pizzas.size() >= static_cast<std::queue<std::shared_ptr<Pizza>>::size_type>(_maxPizza))
        _isFull = true;
    else
        _isFull = false;
}

int Kitchen::getAvailableSpace() {
    return _maxPizza - _pizzas.size();
}
bool Kitchen::willBeFull(std::size_t nbPizza) const {
    return _pizzas.size() + nbPizza >= static_cast<std::queue<std::shared_ptr<Pizza>>::size_type>(_maxPizza);
}