/*
** EPITECH PROJECT, 2023
** B-CCP-400-PAR-4-1-theplazza-titien.carellas
** File description:
** Pizza.hpp
*/
#ifndef PIZZA_HPP_
	#define PIZZA_HPP_
    #include <string>
    #include <vector>
    #include <memory>
    #include <map>
    #include <iostream>
    enum class PizzaType { Margarita, Regina, Americana, Fantasia, None };
    enum class PizzaSize { S, M, L, XL, XXL, Null };
    enum class Ingredient {
        Dough,
        Tomato,
        Gruyere,
        Steak,
        Ham,
        Mushrooms,
        Eggplant,
        GoatCheese,
        ChiefLove
    };

extern std::map<PizzaType, std::string> pizzaTypeMap;
extern std::map<PizzaSize, std::string> pizzaSizeMap;
extern std::map<Ingredient, std::string> ingredientMap;

PizzaType getPizzaTypeFromString(const std::string& pizzaTypeString);
PizzaSize getPizzaSizeFromString(const std::string& pizzaSizeString);

class Pizza {
    public:
    Pizza(PizzaType type, PizzaSize size);
    ~Pizza();
    PizzaType getType() const { return type; }
    PizzaSize getSize() const { return size; }
    std::string getNameString() const { return pizzaTypeMap[type]; }
    std::string getSizeString() const { return pizzaSizeMap[size]; }
    std::vector<Ingredient> getIngredients() const { return ingredients; }
    void addIngredient(Ingredient ingredient) { ingredients.push_back(ingredient); }
    void removeIngredient(Ingredient ingredient);
    void clearIngredients() { ingredients.clear(); }
    void setType(PizzaType type) { this->type = type; }
    void setSize(PizzaSize size) { this->size = size; }
    void setIngredients(std::vector<Ingredient> ingredients) { this->ingredients = ingredients; }
private:
    PizzaType type;
    PizzaSize size;
    std::vector<Ingredient> ingredients;
};
#endif /*PIZZA_HPP_*/
