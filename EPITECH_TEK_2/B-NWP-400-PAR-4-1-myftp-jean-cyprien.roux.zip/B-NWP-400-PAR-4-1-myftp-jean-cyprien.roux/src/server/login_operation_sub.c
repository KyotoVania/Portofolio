/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** login_operation.c
*/

#include "myftp.h"
#include <ctype.h>

int set_user(fd_node_t *node, char *username)
{
    if (node->status != is_connected)
        return (84);
    printf("Username: %s \n", username);
    if (strncmp(username, "Anonymous", 9) == 0){
        node->status = is_anonymous;
        if (send_client_line(node->fd,
            "331 User name okay, need password.\n") == 84)
            return (84);
    } else {
        if (send_client_line(node->fd, "530 Not logged in.\n") == 84)
            return (84);
    }
    return (0);
}

int is_empty_or_whitespace(const char *str)
{
    while (*str) {
        if (!isspace((unsigned char)*str))
            return 0;
        str++;
    }
    return 1;
}

int compare_password(char *password)
{
    if (password == NULL)
        return (0);
    if (is_empty_or_whitespace(password))
        return (0);
    return (1);
}

int set_pass(fd_node_t *node, char *password)
{
    if (node->status != is_anonymous) {
        printf("User not logged in causes status %d \n", node->status);
        return (84);
    }
    if (compare_password(password) == 0) {
        if (send_client_line(node->fd,
        "230 User logged in, proceed.\n") == 84)
            return (84);
        node->status = is_logged_in;
    } else {
        if (send_client_line(node->fd, "530 Not logged in.\n") == 84)
            return (84);
        return (530);
    }
    return (0);
}
