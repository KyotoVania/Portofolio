/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** client.c
*/

#include "client.h"

void handle_passive_mode(client_t *client, char* response, char* line)
{
    char code_tmp[4];
    int res = 0;

    for (int i = 0; i < 3; i++) {
        code_tmp[i] = response[i];
    }
    code_tmp[3] = '\0';
    res = atoi(code_tmp);
    if (res == 227 && strstr(line, "PASV") != NULL)
        activate_passive_mode(response, client);
}

void handle_active_mode(client_t *client, char* line)
{
    if (strstr(line, "PORT") != NULL) {
        activate_active_mode(line + 5, client);
    }
}

void handle_retrieve_mode(client_t *client, char* response, char* line)
{
    if ((strstr(line, "RETR") != NULL)) {
        retrieve_file(client, response, line + 5);
    }
}

void handle_store_mode(client_t *client, char* line)
{
    if (strstr(line, "STOR") != NULL) {
        line[strlen(line) - 1] = '\0';
        store_client(client, line + 5);
    }
}
