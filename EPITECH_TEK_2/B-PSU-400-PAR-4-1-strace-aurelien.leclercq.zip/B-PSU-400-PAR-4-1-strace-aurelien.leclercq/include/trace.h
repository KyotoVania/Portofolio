/*
** EPITECH PROJECT, 2023
** Strace
** File description:
** trace.h
*/

#ifndef TRACE_H_
    #define TRACE_H_
    #include "trace.h"
    #include "options.h"
    #include "trace.h"
    #include "main.h"
    #include "syscall.h"
    #include "low_func.h"
    #include "syscall_helpers.h"
    #include <sys/ptrace.h>
    #include <sys/reg.h>
    #include <sys/types.h>
    #include <sys/user.h>
    #include <unistd.h>
    #include <stdlib.h>
    #include <stdio.h>
    #include <signal.h>
    #include <string.h>
    #include <stdbool.h>
    #include <sys/ptrace.h>
    #include <sys/reg.h>
    #include <sys/wait.h>
    #include <sys/types.h>
    #include <unistd.h>
    #include <errno.h>
    #include <unistd.h>
    #include <sys/syscall.h>
    #include <ctype.h>

typedef struct {
    pid_t pid;
    int status;
    struct user_regs_struct regs;
    options_t opts;
    syscall_t *tabled;
} trace_context_t;

int trace_process(char **av, options_t opts, syscall_t *tabled);
int do_child(int argc, char **argv);
int do_trace(pid_t child, options_t *opts, syscall_t *tabled);
int print_exit(int exit_status);
void perform_trace_p(trace_context_t *context);
#endif /*TRACE_H_*/
