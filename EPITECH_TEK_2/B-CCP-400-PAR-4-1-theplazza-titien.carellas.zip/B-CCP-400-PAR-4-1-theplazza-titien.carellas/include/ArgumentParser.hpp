/*
** EPITECH PROJECT, 2023
** B-CCP-400-PAR-4-1-theplazza-titien.carellas
** File description:
** ArgumentParser.hpp
*/
#ifndef ARGUMENTPARSER_HPP_
	#define ARGUMENTPARSER_HPP_


    #include <cstdlib>  // for std::exit
    #include <iostream> // for std::cerr
    #include <string>   // for std::string
    #include <climits>  // for INT_MAX

class ArgumentParser {
public:
    ArgumentParser(){}; //default constructor
    ArgumentParser(int argc, char *argv[]) {
        if (argc != 4) {
            std::cerr << "Usage: " << argv[0] << " <cooking time multiplier> <number of cooks> <inactivity time>\n";
            std::exit(84);
        }

        // Parse and validate each argument
        cookingTimeMultiplier = parseDouble(argv[1]);
        numberOfCooks = parseInt(argv[2]);
        inactivityTime = parseInt(argv[3]);

        // You can also add additional validation here if needed, such as checking that all values are positive
        if (numberOfCooks < 0 || inactivityTime < 0 || cookingTimeMultiplier < 0) {
            std::cerr << "Invalid argument: All arguments must be positive\n";
            std::exit(84);
        }
        //debug print usage
        std::cout << "cookingTimeMultiplier: " << cookingTimeMultiplier << std::endl;
        std::cout << "numberOfCooks: " << numberOfCooks << std::endl;
        std::cout << "inactivityTime: " << inactivityTime << std::endl;
    }

    double getCookingTimeMultiplier() const { return cookingTimeMultiplier; }
    int getChefNumber() const { return numberOfCooks; }
    int getInactivityTime() const { return inactivityTime; }

private:
    double cookingTimeMultiplier;
    int numberOfCooks;
    int inactivityTime;

    double parseDouble(const char *arg) {
        char *end;
        double value = std::strtod(arg, &end);

        if (*end != '\0' || value < 0) {
            std::cerr << "Invalid cooking time multiplier: " << arg << "\n";
            std::exit(84);
        }

        return value;
    }

    int parseInt(const char *arg) {
        char *end;
        long value = std::strtol(arg, &end, 10);

        if (*end != '\0' || value <= 0 || value > INT_MAX) {
            std::cerr << "Invalid integer value: " << arg << "\n";
            std::exit(84);
        }

        return static_cast<int>(value);
    }
};

#endif /*ARGUMENTPARSER_HPP_*/