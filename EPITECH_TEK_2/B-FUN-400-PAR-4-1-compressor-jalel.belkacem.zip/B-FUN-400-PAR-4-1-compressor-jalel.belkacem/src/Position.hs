{-
-- EPITECH PROJECT, 2023
-- norme_moi_ca
-- File description:
-- Position
-}

module Position where
import Text.ParserCombinators.ReadP
import Data.Char (isDigit)
import Control.Applicative ((<|>), empty) -- For the ReadP parsers

type Position = (Int, Int)

readInt :: ReadP Int
readInt = read <$> many1 (char ' ' <|> char '\t' <|> char ',' <|> (satisfy isDigit))

formatPosition :: Position -> String
formatPosition (x, y) = "(" ++ show x ++ "," ++ show y ++ ")"

parsePosition :: String -> Maybe Position
parsePosition ln = case readP_to_S positionParser ln of
    [(pos, "")] -> Just pos
    _ -> Nothing

processPosition :: String -> Position
processPosition ln = case parsePosition ln of
    Just pos -> pos
    Nothing -> error $ "Invalid position data: " ++ ln

positionParser :: ReadP Position
positionParser = do
    _ <- char '('
    x <- readInt
    _ <- char ','
    y <- readInt
    _ <- char ')'
    return (x, y)
