/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** cone.hpp
*/
#ifndef CONE_HPP_
	#define CONE_HPP_
	#include "utils/shared.hpp"
//handle later

class Cone
{
	public:
	Cone();
	~Cone();
	//void setPos(Position pos);
	//void setRadius(float radius);
	//void setColor(Color color);
	private:
	Position _pos;
	float _radius;
	FlatColor _color;
};

#endif /*CONE_HPP_*/