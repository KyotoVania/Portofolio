/*
** EPITECH PROJECT, 2023
** Strace
** File description:
** syscall_helpers.c
*/

#include "syscall_helpers.h"

char *read_string(pid_t child, size_t address)
{
    char *buffer = malloc(4096);
    int bytesRead = 0;
    size_t chunk = 0;

    while (1) {
        if (bytesRead + sizeof(size_t) > 4096) {
            buffer = realloc(buffer, sizeof(buffer) * 2);
        }
        chunk = ptrace(PTRACE_PEEKDATA, child, address + bytesRead);
        if ((int)chunk == -1)
            return NULL;
        memcpy(buffer + bytesRead, &chunk, sizeof(size_t));
        if (memchr(&chunk, 0, sizeof(size_t)) != NULL) {
            break;
        }
        bytesRead += sizeof(size_t);
    }
    return buffer;
}

int get_syscall_index(long long syscall, syscall_t *syscalls)
{
    for (int i = 0; syscalls[i].name != NULL; i++) {
        if (syscalls[i].num == syscall) {
            return i;
        }
    }
    return -1;
}

long long get_register(pid_t child, int reg)
{
    return ptrace(PTRACE_PEEKUSER, child, 8 * reg);
}

int print_name(long long syscall, syscall_t *syscalls)
{
    int index = get_syscall_index(syscall, syscalls);
    const char *name = NULL;

    if (index != -1) {
        name = strndup(syscalls[index].name,
            strlen(syscalls[index].name));
        fprintf(stderr, "%s(", name);
        free((void *)name);
    } else {
        fprintf(stderr, "(null)(");
    }
    return index;
}

void print_params(pid_t child, syscall_t *syscalls, long long index)
{
    int nargs = syscalls[index].nargs;
    int args[6] = {RDI, RSI, RDX, R10, R8, R9};
    unsigned long long arg_long = -1;

    if (index == -1) {
        return;
    }
    for (int i = 0; i < nargs; i++) {
        arg_long = get_register(child, args[i]);
        if (arg_long) {
            fprintf(stderr, "0x%llx", arg_long);
        } else {
            fprintf(stderr, "0x0");
        }
        if (i < nargs - 1) {
            fprintf(stderr, ", ");
        }
    }
}
