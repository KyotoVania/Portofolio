/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** passive_operation.c
*/

#include "myftp.h"

int set_pasv_start(fd_node_t *node, char *ip, int *port)
{
    node->data_addr.sin_family = AF_INET;
    node->data_addr.sin_addr.s_addr = inet_addr(ip);
    node->data_addr_len = sizeof(node->data_addr);
    *port = rand() % 64511 + 1024;
    node->data_addr.sin_port = htons(*port);
    node->data_port = *port;
    node->states = is_passive;
    return (0);
}

int set_pasv_check(fd_node_t *node)
{
    if (check_iflogged(node) == 532)
        return (84);
    if (node->data_fd != 0) {
        close(node->data_fd);
        node->data_fd = 0;
    }
    node->data_fd = create_socket();
    return (0);
}

int set_pasv_port(fd_node_t *node, int *port)
{
    while (bind(node->data_fd, (struct sockaddr *)&node->data_addr,
        sizeof(node->data_addr)) == -1) {
        *port = rand() % 64511 + 1024;
        node->data_addr.sin_port = htons(*port);
    }
    if (listen(node->data_fd, 1) == -1) {
        if (send_client_line(node->fd,
            "425 Passive 2 Can't open data connection.\n") == 84)
            return (84);
        return (425);
    }
    return (0);
}

int set_pav_accept_client(fd_node_t *node, unsigned char *ip1,
    int port, char *message)
{
    asprintf(&message, "227 Entering Passive Mode (%d,%d,%d,%d,%d,%d)."
    " good port ;%d\n",ip1[0], ip1[1], ip1[2], ip1[3],
    port / 256, port % 256, port);
    if (send_client_line(node->fd, message) == 84) {
        free(message);
        return (84);
    }
    free(message);
    node->data_fd = accept(node->data_fd,
        (struct sockaddr *)&node->data_addr, &node->data_addr_len);
    if (node->data_fd == -1) {
        if (send_client_line(node->fd,
            "425 Passive 3 Can't open data connection.\n") == 84)
            return (84);
        return (425);
    }
    return (0);
}

int set_pasv(fd_node_t *node, server_t *server)
{
    int port = 0;
    char *message = NULL;
    unsigned char *ip1 = NULL;
    if (set_pasv_check(node) == 84)
        return (84);
    if (set_pasv_start(node, server->ip, &port) == 84)
        return (84);
    ip1 = (unsigned char *)&node->data_addr.sin_addr.s_addr;
    if (set_pasv_port(node, &port) == 84) {
        printf("Error: cannot set port \n");
        return (84);
    }
    if (set_pav_accept_client(node, ip1, port, message) == 84) {
        printf("Error: cannot accept client \n");
        return (84);
    }
    return (227);
}
