/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** Raytracer.cpp
*/

#include "scene/Raytracer.hpp"
#include "primitives/sphere.hpp"
#include "primitives/plane.hpp"

void Raytracer::render() {
    // Get the camera from the scene config
    Camera camera = _sceneConfig.getCamera();
    
    // Get the resolution of the camera
    Resolution resolution = camera.getResolution();
    int width = resolution.width;
    int height = resolution.height;

    // Create an empty image with the same resolution as the camera
    std::vector<std::vector<Color>> image(height, std::vector<Color>(width));

    // Iterate through each pixel in the output image
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            // Generate a ray for each pixel based on the camera settings
            Ray ray = camera.generateRay(x, y);

            // Check for intersections with the primitives in the scene
            // (in this case, the sphere)
            Intersection intersection = getClosestIntersection(ray);

            // Calculate lighting and shading based on the material and light settings
            Color pixelColor = calculateShading(intersection);

            // Set the color of the pixel based on the calculated shading
            image[y][x] = pixelColor;
        }
    }

    // Save the image to a PPM file or another image format
    saveImageToFile(image);
}
