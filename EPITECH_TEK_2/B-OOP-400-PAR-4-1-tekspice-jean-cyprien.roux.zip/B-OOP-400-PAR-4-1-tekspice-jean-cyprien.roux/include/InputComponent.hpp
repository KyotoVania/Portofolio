/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** InputComponent.hpp
*/
#ifndef INPUTCOMPONENT_HPP_
	#define INPUTCOMPONENT_HPP_

#include "AComponent.hpp"
namespace nts {
    class InputComponent : public nts::AComponent {
    public:
        InputComponent();
        ~InputComponent();
        nts::Tristate compute(std::size_t pin);
        std::vector<Pin> * getLinks();
        const std::vector<Pin> * getLinks() const;
        void setStates(nts::Tristate state);
        void display(std::ostream &os);
        void simulate(std::size_t tick);
    private:
        std::vector<Pin> links = std::vector<Pin> (1);
        nts::Tristate state = nts::UNDEFINED;
        nts::Tristate nextState = nts::UNDEFINED;
    };
};
#endif /*INPUTCOMPONENT_HPP_*/