/*
** EPITECH PROJECT, 2023
** Strace
** File description:
** low_func.c
*/

#include "low_func.h"

char * tolower_str(char *str)
{
    for (int i = 0; str[i] != '\0'; i++) {
        str[i] = tolower(str[i]);
    }
    return str;
}

void detach_and_exit(pid_t pid)
{
    ptrace(PTRACE_DETACH, pid, NULL, NULL);
    exit(0);
}

int get_arg_type(syscall_t syscall, int i)
{
    if (i >= syscall.nargs)
        return -1;
    if (i == 0 )
        return syscall.arg1_type;
    if (i == 1 )
        return syscall.arg2_type;
    if (i == 2 )
        return syscall.arg3_type;
    if (i == 3 )
        return syscall.arg4_type;
    if (i == 4 )
        return syscall.arg5_type;
    if (i == 5 )
        return syscall.arg6_type;
    return -1;
}
