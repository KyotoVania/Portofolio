/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** OutputComponent.hpp
*/
#ifndef OUTPUTCOMPONENT_HPP_
	#define OUTPUTCOMPONENT_HPP_

#include "IComponent.hpp"
#include "AComponent.hpp"
#include "PinComponent.hpp"

namespace nts {
    class OutputComponent : public nts::AComponent {
        public:
        OutputComponent();
        ~OutputComponent();
        nts::Tristate compute(std::size_t pin);
        std::vector<Pin> * getLinks();
        const std::vector<Pin> * getLinks() const;
        void display(std::ostream &os);
        void setStates(nts::Tristate state);
        void simulate(std::size_t tick);

    private:
        std::vector<Pin> links = std::vector<Pin> (1);
        nts::Tristate state = nts::UNDEFINED;
    };
}

#endif /*OUTPUTCOMPONENT_HPP_*/