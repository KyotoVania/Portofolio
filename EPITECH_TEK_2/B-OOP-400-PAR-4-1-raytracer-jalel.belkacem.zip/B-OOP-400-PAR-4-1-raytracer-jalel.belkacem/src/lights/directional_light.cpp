/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** directional_light.cpp
*/

#include "lights/directional_light.hpp"


