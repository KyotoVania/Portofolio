/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** NotComponent.hpp
*/
#ifndef NOTCOMPONENT_HPP_
	#define NOTCOMPONENT_HPP_

#include "AComponent.hpp"

namespace nts {
    class NotComponent : public nts::AComponent {
        public:
            NotComponent();
            ~NotComponent();
            nts::Tristate compute(std::size_t pin);
            const std::vector<Pin> * getLinks() const;
            std::vector<Pin> * getLinks();
            void display(std::ostream &os);
             void setStates(nts::Tristate state) {};

    private:
            std::vector<Pin> links = std::vector<Pin> (2);

    };
};

#endif /*NOTCOMPONENT_HPP_*/