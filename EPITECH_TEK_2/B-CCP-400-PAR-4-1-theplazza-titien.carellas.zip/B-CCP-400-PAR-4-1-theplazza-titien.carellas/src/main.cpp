
#include <iostream>
#include "Parser.hpp"
#include "Reception.hpp"
#include "ArgumentParser.hpp"
#include "shared.hpp"
#include "Command.hpp"
#include <memory>
#include <unistd.h>

int main(int argc, char *argv[]) {
	int id_command = 0;
    try {
        Parser parser;
        Reception reception(argc, argv);

        std::string line;
        while (std::getline(std::cin, line)) {
            if (line == "quit" || line == "exit") {
                break;
            }
            // Parse the command line argum	ents
            Command * command = parser.parseCommand(line, id_command);
			if (command != nullptr) {
				id_command++;
				reception.receiveOrder(command);
			}
        }
    } catch (const std::exception &e) {
        std::cerr << e.what() << std::endl;
        return 84; 
    }

    return 0; 
}


