/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** ambient_light.hpp
*/
#ifndef AMBIENT_LIGHT_HPP_
	#define AMBIENT_LIGHT_HPP_
	#include "utils/shared.hpp"


class AmbientLight {
public:
	Vec3 color;
	float intensity;

	AmbientLight(const Vec3& color = Vec3(1, 1, 1), float intensity = 0.2f) : color(color), intensity(intensity) {}
};

#endif /*AMBIENT_LIGHT_HPP_*/