/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** flat_color.hpp
*/
#ifndef FLAT_COLOR_HPP_
	#define FLAT_COLOR_HPP_
	#include "utils/shared.hpp"
	#include "scene/scene_config.hpp"
	#include "utils/mathHelper.hpp"
	#include "utils/intersection.hpp"
	
class ColorCalculation
{
	public:
	Vec3 clampColor(const Vec3& color) {
		float clampedX = std::max(0.0f, std::min(color.x, 255.0f));
		float clampedY = std::max(0.0f, std::min(color.y, 255.0f));
		float clampedZ = std::max(0.0f, std::min(color.z, 255.0f));
		return Vec3(clampedX, clampedY, clampedZ);
	}
	Vec3 calculateColor(const SceneConfig& sceneConfig, const Vec3& hitPoint, const Vec3& rayDirection, int maxDepth, int depth) {
		Vec3 surfaceNormal;
		float closestHit = std::numeric_limits<float>::max();
		float t0, t1;
		iPrimitive* hitPrimitive = nullptr;
		bool hitObject = _intersection.findClosestIntersection(sceneConfig._spheres, sceneConfig._planes, hitPoint, rayDirection, surfaceNormal, closestHit, hitPrimitive, t0, t1);

		if (hitObject) {
			// Compute the distance the ray has traveled through the object
			float distance = std::abs(t1 - t0);

			// Compute the absorption factor using Beer's law
			float absorption = std::exp(-hitPrimitive->gettransparency() * distance);

			// Apply the absorption factor to the color
			return processHitObject(sceneConfig, hitPoint, rayDirection, maxDepth, depth, hitPrimitive, surfaceNormal) * absorption;
		} else {
			return processNoHit();
		}
	}
	Vec3 averageColorForPixel(const SceneConfig& sceneConfig, int samplesPerPixel, int i, int j, int maxDepth) {
		Vec3 color;
		for (int s = 0; s < samplesPerPixel; ++s) {
			float u = float(i + _mathHelper.random_float()) / float(sceneConfig._width);
			float v = float(sceneConfig._height - j - 1 + _mathHelper.random_float()) / float(sceneConfig._height);
			Vec3 rayDirection = sceneConfig._camera.getLowerLeftCorner() + u * sceneConfig._camera.getHorizontal() + v * sceneConfig._camera.getVertical() - sceneConfig._camera.getOrigin();
			color += calculateColor(sceneConfig, sceneConfig._camera.getOrigin(), rayDirection, maxDepth, 0);
		}
		color = color / samplesPerPixel;
    
		return color;
	}
	Vec3 processHitObject(const SceneConfig& sceneConfig, const Vec3& hitPoint, const Vec3& rayDirection, int maxDepth, int depth, iPrimitive* hitPrimitive, Vec3& surfaceNormal) {
		float closestHit = std::numeric_limits<float>::max();
		float bias = 1e-6;
		float t0, t1;

		_intersection.findClosestIntersection(sceneConfig._spheres, sceneConfig._planes, hitPoint + surfaceNormal * bias, rayDirection, surfaceNormal, closestHit, hitPrimitive, t0, t1);

		Vec3 color = calculateShading(sceneConfig, hitPrimitive->color, surfaceNormal, rayDirection, 32.0f, hitPoint);// shinesses + hitPrimitive->color * 0.2f; // ambient component
    
		if (depth < maxDepth) {
			color += calculateReflectionRefraction(sceneConfig, hitPoint, rayDirection, maxDepth, depth, surfaceNormal, hitPrimitive, 1e-6f);
		}
		return clampColor(color);
	}


	Vec3 processNoHit() {
		return Vec3(0, 0, 0);
	}
	Vec3 calculateShading(const SceneConfig& sceneConfig, Vec3& objectColor, Vec3& surfaceNormal, const Vec3& rayDirection, float shininess, const Vec3& hitPoint) {
	    Vec3 color = objectColor * sceneConfig._ambientLight.color * sceneConfig._ambientLight.intensity * 255.99; // ambient component
	    
	    for (const auto& pointLight : sceneConfig._pointLights) {
	        Vec3 lightDirection = (pointLight.position - hitPoint).normalized();
	        float distance = (pointLight.position - hitPoint).length();
	        
	        float shading = std::max(0.0f, surfaceNormal.dot(lightDirection));
	        
	        float attenuation = 1.0f / (pointLight.constantAttenuation + pointLight.linearAttenuation * distance + pointLight.quadraticAttenuation * distance * distance);
	        
	        color += objectColor * pointLight.color * pointLight.intensity * shading * attenuation * 255.99; // diffuse component
	        float specular = _mathHelper.phongSpecular(lightDirection, surfaceNormal, rayDirection, shininess);
	        color += pointLight.color * pointLight.intensity * specular * attenuation * 255.99; // specular component
	    }
	    for (const auto& directionalLight : sceneConfig._directionalLights) {
	        Vec3 lightDirection = directionalLight.direction;
	        float shading = std::max(0.0f, surfaceNormal.dot(lightDirection));
	        color += objectColor * directionalLight.color * directionalLight.intensity * shading * 255.99; // diffuse component
	        float specular = _mathHelper.phongSpecular(lightDirection, surfaceNormal, rayDirection, shininess);
	        color += directionalLight.color * directionalLight.intensity * specular * 255.99; // specular component
	    }
	    return color;
	}

	Vec3 calculateReflectionRefraction(const SceneConfig& sceneConfig, const Vec3& hitPoint, const Vec3& rayDirection, int maxDepth, int depth, Vec3& surfaceNormal, iPrimitive* hitPrimitive, float bias) {
	    Vec3 reflectionDirection = rayDirection - surfaceNormal * 2 * rayDirection.dot(surfaceNormal);
	   

	    reflectionDirection.normalized();
	    Vec3 refractionDirection = _mathHelper.refract(rayDirection, surfaceNormal, 1.0f, hitPrimitive->refractiveIndex);

	    float fresnel = _mathHelper.fresnelSchlick(rayDirection, surfaceNormal, hitPrimitive->refractiveIndex);
	    Vec3 reflectionColor = calculateColor(sceneConfig, hitPoint + surfaceNormal * bias, reflectionDirection, maxDepth, depth + 1);
	    if (fresnel < 1.0f) {
	        if (hitPrimitive->transparency < 1) {
	            Vec3 refractionColor = calculateColor(sceneConfig, hitPoint - surfaceNormal * bias, refractionDirection, maxDepth, depth + 1);
	            return reflectionColor * fresnel + refractionColor * (1 - fresnel) * hitPrimitive->transparency;  // here we multiply by the transparency
	        } else {
	            return reflectionColor * fresnel;
	        }
	    } else {
	        return reflectionColor * fresnel;
	    }
	}
	private:
	MathHelper _mathHelper;
	Intersection _intersection;
};
#endif /*FLAT_COLOR_HPP_*/