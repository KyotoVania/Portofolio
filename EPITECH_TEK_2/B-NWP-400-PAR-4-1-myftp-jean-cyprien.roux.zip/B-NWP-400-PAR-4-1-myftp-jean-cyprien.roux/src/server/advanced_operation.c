/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** advanced_operation.c
*/

#include "myftp.h"

char * check_addedslashes(char *path, fd_node_t *node)
{
    char *new_path = NULL;
    if (path[0] != '/'){
        new_path = malloc(sizeof(char) * (strlen(node->working_dir)
        + strlen(path) + 2));
        if (new_path == NULL)
            return (NULL);
        strcpy(new_path, node->working_dir);
        strcat(new_path, "/");
        strcat(new_path, path);
        return (new_path);
    }
    return (path);
}

int set_cwd(fd_node_t *node, char *path)
{
    if (check_iflogged(node) == 532)
        return (84);
    path = check_addedslashes(path, node);
    if (path == NULL)
        return (84);
    if (chdir(path) == -1) {
        if (send_client_line(node->fd, "550 Failed"
            " to change directory.\n") == 84)
            return (84);
        return (550);
    }
    free(node->working_dir);
    node->working_dir = strdup(path);
    if (send_client_line(node->fd, "250 Directory"
        " successfully changed.\n") == 84)
        return (84);
    return (250);
}

int set_cdup(fd_node_t *node)
{
    if (check_iflogged(node) == 532)
        return (84);
    if (chdir("..") == -1) {
        if (send_client_line(node->fd, "550 Failed to change"
        " directory.\n") == 84)
            return (84);
        return (550);
    }
    free(node->working_dir);
    node->working_dir = strdup("..");
    if (send_client_line(node->fd, "250 Directory"
        " successfully changed.\n") == 84)
        return (84);
    return (250);
}

int set_smnt (fd_node_t *node, char *structure)
{
    if (check_iflogged(node) == 532)
        return (84);
    if (strcmp(structure, "F") == 0) {
        if (send_client_line(node->fd,
        "200 Structure set to F.\n") == 84)
            return (84);
        return (200);
    } else {
        if (send_client_line(node->fd,
        "504 Command not implemented for that parameter.\n") == 84)
            return (84);
        return (504);
    }
}

int reinit_client(fd_node_t *node, server_t *server)
{
    if (check_iflogged(node) == 532)
        return (84);
    if (send_client_line(node->fd,
    "120 Service ready in nnn minutes.\n") == 84)
        return (84);
    node->buffer_size = 1024;
    node->buffer_pos = 0;
    node->working_dir = strdup(server->home_dir);
    return (120);
}
