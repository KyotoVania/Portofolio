/*
** EPITECH PROJECT, 2023
** B-CCP-400-PAR-4-1-panoramix-jean-cyprien.roux
** File description:
** druid.c
*/

#include "panoramix.h"
#include <stdbool.h>

bool refill_potion(program_t *program)
{
    bool last_refill = false;
    sem_wait(&program->semaphorex.refill_sem);
    pthread_mutex_lock(&program->semaphorex.pot_mutex);

    if (program->druid.pot_size > 0 && program->no_more_refills) {
        pthread_mutex_unlock(&program->semaphorex.pot_mutex);
        return false;
    }
    program->druid.pot_size = program->parameters.pot_size;
    program->druid.refills_left--;
    printf("Druid: Ah! Yes, yes, I'm awake! Working on it!"
    " Beware I can only make %d more refills after this one.\n",
    program->druid.refills_left);
    if (program->druid.refills_left == 0) {
        last_refill = true;
        program->no_more_refills = true;
    }
    pthread_mutex_unlock(&program->semaphorex.pot_mutex);
    return last_refill;
}

void *druid(void *arg)
{
    program_t *program = (program_t *)arg;
    bool last_refill = false;
    printf("Druid: I'm ready... but sleepy...\n");
    pthread_barrier_wait(&program->barrier);
    while (!last_refill) {
        last_refill = refill_potion(program);
        pthread_cond_broadcast(&program->semaphorex.refill_cv);
        pthread_mutex_lock(&program->semaphorex.finished_villagers_mutex);
        if (program->semaphorex.finished_villagers ==
        program->parameters.nb_villagers) {
            pthread_mutex_unlock(&program->semaphorex.finished_villagers_mutex);
            break;
        }
        pthread_mutex_unlock(&program->semaphorex.finished_villagers_mutex);
    }
    printf("Druid: I'm out of viscum. "
    "I'm going back to... zZz\n");
    return NULL;
}
