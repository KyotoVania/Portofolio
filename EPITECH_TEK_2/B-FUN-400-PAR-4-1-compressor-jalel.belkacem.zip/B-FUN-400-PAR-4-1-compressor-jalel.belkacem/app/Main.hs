{-
-- EPITECH PROJECT, 2023
-- B-FUN-400-PAR-4-1-compressor-jalel.belkacem
-- File description:
-- Main
-}

module Main where

import Args (Args(..), parseArgs)
import System.Environment (getArgs) -- For getting command line arguments
import Data.Char (isDigit) -- For checking if a character is a digit
import Data.Maybe (fromJust, fromMaybe, catMaybes, isJust) -- Functions for working with Maybe values
import Control.Monad (replicateM) -- For running an IO action multiple times
import Text.ParserCombinators.ReadP (ReadP, char, readP_to_S, sepBy1, string, many1, satisfy, skipSpaces, between, sepBy, manyTill, eof, get, look, pfail, (<++), choice, munch, munch1, skipMany, skipMany1, count, option, optional, readS_to_P, readP_to_S) -- Parser combinators for parsing pixel and position data

import Point (Point, obtainPixelData, getMaxDimensions)
import Args (parseArgs, filePath, nClusters, limit)
import Cluster (generateInitialClusters, refineClusters, groupPixelsByCluster, allocatePixelsToClusters)
import Printer (printFormattedAllocatedPixels)

main :: IO ()
main = do
    args <- getArgs
    handleArgs args

handleArgs :: [String] -> IO ()
handleArgs args = case parseArgs args of
    Left errMsg -> putStrLn errMsg
    Right parsedArgs -> processArgs parsedArgs

processArgs :: Args -> IO ()
processArgs parsedArgs = do
    pixelData <- obtainPixelData (filePath parsedArgs)
    let imageSize = getMaxDimensions pixelData
    let pixelValues = map snd pixelData
    initialClusters <- generateInitialClusters (nClusters parsedArgs) pixelValues
    (finalClusters, refinementStepsCount) <- 
        refineClusters imageSize (limit parsedArgs) initialClusters pixelValues
    let allocatedPixels = allocatePixelsToClusters imageSize initialClusters pixelValues
    let groupedPixels = groupPixelsByCluster finalClusters allocatedPixels
    printFormattedAllocatedPixels groupedPixels
