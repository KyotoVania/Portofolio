/*
** EPITECH PROJECT, 2023
** B-ASM-400-PAR-4-1-bsasmminilibc-jean-cyprien.roux
** File description:
** test.h
*/
#ifndef TEST_H_
	#define TEST_H_
int _my_strlen(const char *str);
int _my_strcmp(const char *s1, const char *s2);
int _my_strncmp(const char *s1, const char *s2, size_t n);
int _my_strcasecmp(const char *s1, const char *s2);
char *_my_strchr(const char *s, int c);
char *_my_strrchr(const char *s, int c);
char *_my_strstr(const char *haystack, const char *needle);
char *_my_strpbrk(const char *s, const char *accept);
size_t _my_strcspn(const char *s, const char *reject);
void *_my_memset(void *s, int c, size_t n);
void *_my_memcpy(void *dest, const void *src, size_t n);
void *_my_memmove(void *dest, const void *src, size_t n);

#endif /*TEST_H_*/