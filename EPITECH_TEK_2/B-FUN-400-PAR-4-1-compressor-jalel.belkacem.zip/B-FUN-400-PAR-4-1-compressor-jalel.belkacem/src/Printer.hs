{- 
-- EPITECH PROJECT, 2023
-- norme_moi_ca
-- File description:
-- Printer
-}

module Printer (printFormattedAllocatedPixels) where

import Cluster (Cluster(..), clusterValue, clusterId)
import Point (Point(..), pointPosition, pointValue)
import Data.List (groupBy)

printFormattedAllocatedPixels :: [Cluster] -> IO ()
printFormattedAllocatedPixels clusters = mapM_ printCluster clusters
  where
    printCluster cluster = 
      putStrLn "--"
      >> putStrLn (show (clusterValue cluster))
      >> putStrLn "-"
      >> mapM_ (putStrLn . showPointWithColor) (points cluster)
    showPointWithColor point = 
      show (pointPosition point) ++ " " ++ show (pointValue point)
