/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** NandComponent.cpp
*/

#include "NandComponent.hpp"

#include "NandComponent.hpp"

nts::NandComponent::NandComponent()
{

}

nts::NandComponent::~NandComponent()
{
}

nts::Tristate nts::NandComponent::compute(std::size_t pin)
{
    nts::Tristate state = getLink(1);
    nts::Tristate state2 = getLink(2);
    if (pin == 3) {
        if (state == nts::UNDEFINED || state2 == nts::UNDEFINED) {
            return nts::UNDEFINED;
        } else if (state == nts::FALSE || state2 == nts::FALSE) {
            return nts::TRUE;
        } else {
            return nts::FALSE;
        }
    }
    
    if (pin == 1) {
        return getLink(1);
    }
    if (pin == 2) {
        return getLink(2);
    }
    return nts::UNDEFINED;
}

const std::vector<Pin> * nts::NandComponent::getLinks() const
{
    return &links;
}

std::vector<Pin> * nts::NandComponent::getLinks()
{
    return &links;
}

void nts::NandComponent::display(std::ostream &os)
{
    os << "NandComponent" << std::endl;
}