/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** send_receive_operation.c
*/

#include "myftp.h"

int get_fd_server(fd_node_t *node,
char *pathname_client, char *home_dir)
{
    int fd_server = 0;
    char *pathname_server = NULL;
    (void) home_dir;

    asprintf(&pathname_server, "%s/%s", node->working_dir,
    get_last_path(pathname_client));
    fd_server = open(pathname_server, O_RDONLY);
    if (fd_server != -1) {
        close (fd_server);
        fd_server = open(pathname_server, O_WRONLY | O_TRUNC, 0644);
    } else {
        fd_server = open(pathname_server, O_WRONLY | O_CREAT, 0644);
    }
    return (fd_server);
}

int store_doing(fd_node_t *node, int fd_server, char *message)
{
    if (send_client_line(node->fd, message) == 84) {
        free(message);
        return (84);
    }
    if (read_and_write(node->data_fd, fd_server) == 84) {
        free(message);
        return (84);
    }
    asprintf(&message, "226 Closing data connection."
    " Requested file action successful\n");
    if (send_client_line(node->fd, message) == 84)
        return (84);
    return (0);
}

int store_file_start(fd_node_t *node, char *pathname_client,
char *home_dir)
{
    if (check_iflogged(node) == 532)
        return (84);
    char *message = NULL;
    int fd_server = get_fd_server(node, pathname_client, home_dir);

    asprintf(&message,
    "150 File status okay; about to open data connection.\n");
    if (store_doing(node, fd_server, message) == 84)
        return (84);
    close(fd_server);
    return (226);
}

int store_file (fd_node_t *node, char *pathname_client, char *home_dir)
{
    if (check_iflogged(node) == 532)
        return (84);
    if (node->states == undefined){
        if (send_client_line(node->fd,
        "503 Bad sequence of commands.\n") == 84)
            return (84);
        return (425);
    } else if (node->states == is_passive
            || node->states == is_active) {
        store_file_start(node, pathname_client, home_dir);
    } else {
        if (send_client_line(node->fd,
        "503 Bad sequence of commands.\n") == 84)
            return (84);
        return (425);
    }
    return (226);
}
