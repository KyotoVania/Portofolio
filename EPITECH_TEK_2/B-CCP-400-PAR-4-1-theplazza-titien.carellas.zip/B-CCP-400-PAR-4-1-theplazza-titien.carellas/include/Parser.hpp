#ifndef PARSER_HPP
#define PARSER_HPP

#include <memory>
#include <string>
#include "Command.hpp"

class Parser {
public:
    Parser();
    ~Parser();
    Parser(int argc, char* argv[]);
    Command * parseCommand(std::string cmd, int id);
    private:
};

#endif // PARSER_HPP
