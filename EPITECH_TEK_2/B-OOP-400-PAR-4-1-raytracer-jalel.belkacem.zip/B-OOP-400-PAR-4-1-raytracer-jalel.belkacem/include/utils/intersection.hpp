/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** intersection.hpp
*/
#ifndef INTERSECTION_HPP_
	#define INTERSECTION_HPP_
#include "utils/shared.hpp"
#include "utils/mathHelper.hpp"
#include "primitives/sphere.hpp"
#include "primitives/plane.hpp"
#include "scene/scene_config.hpp"


class Intersection {
    public:
    bool findClosestIntersection(const std::vector<Sphere>& spheres, const std::vector<Plane>& planes, const Vec3& hitPoint, const Vec3& rayDirection, Vec3& surfaceNormal, float& closestHit, iPrimitive*& hitPrimitive, float& t0, float& t1) {
        bool hitObject = false;
        t0 = std::numeric_limits<float>::max();
        t1 = std::numeric_limits<float>::max();

        for (int i = 0; i < spheres.size() + planes.size(); ++i) {
            if (i < spheres.size()) {
                const auto& s = spheres[i];
                float tSphere0, tSphere1;
                Vec3 translatedRayOrigin = hitPoint - s.translation;  // Adjust the ray origin for the sphere's translation
                if (s.intersect(translatedRayOrigin, rayDirection, tSphere0, tSphere1)) {
                    if (tSphere0 >= 0 && tSphere0 < closestHit) {
                        hitObject = true;
                        closestHit = tSphere0;
                        hitPrimitive = const_cast<Sphere*>(&s);
                        t0 = tSphere0;
                        t1 = tSphere1;
                        surfaceNormal = (translatedRayOrigin + rayDirection * tSphere0 - s.center).normalized();
                    }
                }
            } else {
                const auto& p = planes[i - spheres.size()];
                float tPlane0, tPlane1;
                Vec3 translatedRayOrigin = hitPoint - p.translation;  // Adjust the ray origin for the plane's translation
                if (p.intersect(translatedRayOrigin, rayDirection, tPlane0, tPlane1)) {
                    if (tPlane0 >= 0 && tPlane0 < closestHit) {
                        hitObject = true;
                        closestHit = tPlane0;
                        hitPrimitive = const_cast<Plane*>(&p);
                        surfaceNormal = p.normal;
                        t0 = tPlane0;
                        t1 = tPlane1;
                    }
                }
            }
        }
        return hitObject;
    }
};



#endif /*INTERSECTION_HPP_*/