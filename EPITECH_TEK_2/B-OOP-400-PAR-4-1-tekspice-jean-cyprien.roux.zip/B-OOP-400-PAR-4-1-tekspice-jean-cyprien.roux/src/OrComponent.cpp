/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** OrComponent.cpp
*/


#include "OrComponent.hpp"

nts::OrComponent::OrComponent()
{
}

nts::OrComponent::~OrComponent()
{
}

nts::Tristate nts::OrComponent::compute(std::size_t pin)
{
    nts::Tristate state = getLink(1);
    nts::Tristate state2 = getLink(2);
    if (pin == 3){
        if (state == nts::TRUE || state2 == nts::TRUE)
            return nts::TRUE;
        else if (state == nts::FALSE && state2 == nts::FALSE)
            return nts::FALSE;
        else
            return nts::UNDEFINED;
    }
    return nts::UNDEFINED;
}

const std::vector<Pin> * nts::OrComponent::getLinks() const
{
    return &links;
}

std::vector<Pin> * nts::OrComponent::getLinks()
{
    return &links;
}

void nts::OrComponent::display(std::ostream &os)
{
    os << "OrComponent" << std::endl;
}