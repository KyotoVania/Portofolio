/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** send_receive_operation.c
*/

#include "myftp.h"

int retrieve_file_start(fd_node_t *node, char *pathname, char * server_dir)
{
    char *path = NULL;
    asprintf(&path, "%s/%s", server_dir, pathname);
    int fd = open(path, O_RDONLY);
    if (fd == -1) {
        if (send_client_line(node->fd, "550 File not found.\n") == 84)
            return (84);
        return (550);
    }
    if (send_client_line(node->fd,
    "150 File status okay; about to open data connection.\n") == 84)
        return (84);
    if (read_and_write(fd, node->data_fd) == 84)
        return (84);
    close(fd);
    close(node->data_fd);
    node->states = undefined;
    if (send_client_line(node->fd, "226 Transfer complete.\n") == 84)
        return (84);
    return (226);
}

int retrieve_file(fd_node_t *node, char *pathname, char *server_dir)
{
    if (check_iflogged(node) == 532)
        return (84);

    if (node->states == undefined){
        if (send_client_line(node->fd,
            "503 Bad sequence of commands.\n") == 84)
            return (84);
        return (425);
    } else if (node->states == is_passive || node->states == is_active) {
        retrieve_file_start(node, pathname, server_dir);
    } else {
        if (send_client_line(node->fd,
            "503 Bad sequence of commands.\n") == 84)
            return (84);
        return (425);
    }
    return (226);
}
