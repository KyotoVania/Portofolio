/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** client.c
*/

#include "client.h"

char* read_server_response(client_t *client)
{
    char *response = strdup(" ");
    if ((response = read_server(client->fd)) == NULL) {
        printf("Error reading server response client loop from fd %d"
            "\n", client->fd);
        exit(84);
    }
    return response;
}

int send_server_response(client_t *client, char* line)
{
    int res = 0;
    if ((res = send_server(client->fd, line)) == 84) {
        printf("Error sending server response from fd %d (client_loop)"
            "\n", client->fd);
        exit(84);
    }
    return res;
}

char * read_server(int fd)
{
    char buffer[1024];
    int size = 0;

    if ((size = read(fd, buffer, 1023)) == -1)
        return (NULL);
    buffer[size] = '\0';
    printf("%s", buffer);
    return (strdup(buffer));
}

int send_server(int fd, char *msg)
{
    if (write(fd, msg, strlen(msg)) == -1)
        return (84);
    return (0);
}

int read_and_write_client(int read_fd, int write_fd)
{
    char buffer[1024];
    int size = 0;

    while ((size = read(read_fd, buffer, 1023)) > 0) {
        buffer[size] = '\0';
        if (write(write_fd, buffer, size) == -1) {
            printf("Error: cannot write to server \n");
            return 84;
        }
        if (size < 1023)
            break;
    }
    return 0;
}
