#!/bin/bash

echo "USER Anonymous"
sleep 1s
echo "PASS"
sleep 1s
echo "PASV"
sleep 1s
echo "STOR ./test.txt"
sleep 1s
echo "NOOP"
sleep 1s
echo "RETR test.txt"
sleep 1s
echo "prout"
sleep 1s
echo "QUIT"





