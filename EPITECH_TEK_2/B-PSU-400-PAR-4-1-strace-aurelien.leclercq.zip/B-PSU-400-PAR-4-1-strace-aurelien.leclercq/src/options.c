/*
** EPITECH PROJECT, 2023
** Strace
** File description:
** option.c
*/

#include "options.h"
#include <unistd.h>
#include <stdlib.h>

void switch_options(options_t *opts, int opt)
{
    switch (opt) {
        case 's':
            opts->s_option = 1;
            break;
        case 'p':
            opts->p_option = 1;
            opts->pid = atoi(optarg);
            break;
        default:
            break;
    }
}

options_t parse_options(int argc, char **argv)
{
    options_t opts = {0, 0, 0};
    int opt;

    while ((opt = getopt(argc, argv, "+:sp:")) != -1) {
        if (opt == '?' || opt == ':') {
            break;
        }
        switch_options(&opts, opt);
    }
    return opts;
}
