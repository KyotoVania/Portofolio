{-
-- EPITECH PROJECT, 2023
-- B-FUN-400-PAR-4-1-compressor-jalel.belkacem
-- File description:
-- Args
-}

module Args( Args(..), parseArgs ) where
import Text.Read (readMaybe) -- For parsing Int and Float from strings

data Args = Args { nClusters :: Int, limit :: Float, filePath :: String } deriving (Show)

parseArgs :: [String] -> Either String Args
parseArgs args
    | length args /= 6 = Left "Usage: ./imageCompressor -n N -l L -f FILE"
    | otherwise = do
        n <- getNumber args
        l <- getLimit args
        f <- getPath args
        Right Args { nClusters = n, limit = l, filePath = f }

getNumber :: [String] -> Either String Int
getNumber ("-n":n:rest) =
  maybe (Left errMsg) Right (readMaybe n :: Maybe Int)
  where errMsg = "Error: Invalid number of clusters."
getNumber (_:rest) = getNumber rest
getNumber [] = Left "Error: Number of clusters flag (-n) not provided."

getLimit :: [String] -> Either String Float
getLimit ("-l":l:rest) =
  maybe (Left "Error: Invalid limit value.") Right (readMaybe l :: Maybe Float)
getLimit (_:rest) = getLimit rest
getLimit [] = Left "Error: Limit value flag (-l) not provided."

getPath :: [String] -> Either String String
getPath ("-f":f:rest)
    | null f = Left "Error: Invalid file path."
    | otherwise = Right f
getPath (_:rest) = getPath rest
getPath [] = Left "Error: File path flag (-f) not provided."
