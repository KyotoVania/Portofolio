/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** NorComponent.cpp
*/


#include "NorComponent.hpp"

nts::NorComponent::NorComponent()
{
}

nts::NorComponent::~NorComponent()
{
}

nts::Tristate nts::NorComponent::compute(std::size_t pin)
{
    nts::Tristate state = getLink(1);
    nts::Tristate state2 = getLink(2);
    if (pin == 3) {
        if (state == nts::TRUE || state2 == nts::TRUE) {
            return nts::FALSE;
        } else if (state == nts::UNDEFINED || state2 == nts::UNDEFINED) {
            return nts::UNDEFINED;
        } else {
            return nts::TRUE;
        }
    }

    return nts::UNDEFINED;
}

const std::vector<Pin> * nts::NorComponent::getLinks() const
{
    return &links;
}

std::vector<Pin> * nts::NorComponent::getLinks()
{
    return &links;
}

void nts::NorComponent::display(std::ostream &os)
{
    os << "NorComponent" << std::endl;
}