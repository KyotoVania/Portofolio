/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** client.c
*/

#include "client.h"


int create_client_socket(client_t *client)
{
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd == -1)
        return (84);
    client->fd = fd;
    return (0);
}

int create_client(client_t *client, char *ip, int port)
{
    client->ip = ip;
    client->port = port;
    client->data_port = -1;
    client->data_fd = 0;
    client->states = undefined;
    if (create_client_socket(client) == 84)
        return (84);
    return (0);
}

int connect_to_server (client_t *client)
{
    client->client_addr.sin_family = AF_INET;
    client->client_addr.sin_port = htons(client->port);
    client->client_addr.sin_addr.s_addr = inet_addr(client->ip);
    client->client_addr_len = sizeof(client->client_addr);
    if (connect(client->fd,
                (const struct sockaddr *)
                &client->client_addr, client->client_addr_len) == -1)
        return (84);
    return (0);
}
