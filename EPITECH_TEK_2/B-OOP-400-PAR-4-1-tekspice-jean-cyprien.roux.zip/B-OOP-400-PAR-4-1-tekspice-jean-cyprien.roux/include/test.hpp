/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** test.hpp
*/
#ifndef TEST_HPP_
	#define TEST_HPP_

#include "AComponent.hpp"

class my_Test {
public:
    my_Test();
    ~my_Test();
    void bigTest();
    void testInput();
    void testOutput();
    void testAnd();
    void testOr();
    void testXor();
    void testNor();
    void testNot();
    void testFalse();
    void testTrue();
    void testClock();
    void testLink();
    void testBootsrap();
    void testInputOutput();
};
#endif /*TEST_HPP_*/