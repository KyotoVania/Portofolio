/*
** EPITECH PROJECT, 2023
** B-CCP-400-PAR-4-1-theplazza-titien.carellas
** File description:
** Chef.hpp
*/
#ifndef CHEF_HPP_
	#define CHEF_HPP_
#include <memory>
#include <atomic>
#include <mutex>
#include <thread>
#include <queue>
#include <condition_variable>
#include <iostream>
#include "Pizza.hpp"

#include "Pizza.hpp"

//the chef will be a thread
class Chef {
public:
    Chef();
    Chef(int id, int timeMultiplier);
    ~Chef();
    void cookPizza(Pizza * pizza);
	bool isReady();
    void run();
    bool isBusy();
    void setPizza(Pizza *pizza);
	int getId() const {return _id;}
    std::shared_ptr<std::mutex> _mutex;
    std::shared_ptr<std::condition_variable> _cv;
    std::mutex _myMutex, _readyMutex;
    std::condition_variable _myCv, _readyCv;
    bool _isReady, _hasPizza;
    std::atomic<bool> _isBusy;

    Pizza * _pizza;
private:
    int _id;
    int _timeMultiplier;
};
#endif /*CHEF_HPP_*/