/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** server.c
*/

#include "myftp.h"
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int accept_and_select(fd_set readfds, server_t *server, int biggest_fd)
{
    if (select(biggest_fd + 1, &readfds, NULL, NULL, NULL) == -1) {
        perror("select");
        return (84);
    }
    if (FD_ISSET(server->fd, &readfds)) {
        if (accept_client(server) == 84)
            return (84);
        printf("Client connected\n");
    }
    return (0);
}

int stop_server(int fd)
{
    if (close(fd) == -1)
        return (84);
    return (0);
}
