USAGE : 
``` 

make -> crée ma lib

make test -> crée ma lib mais avec un flag pour faire ma grosse batterie de test

make test_c -> fait un exec a lancé avec export Library. example
export LD_LIBRARY_PATH=. && ./test

make test_c_replace -> fait un exec a tester avec ld_preload. example ;
LD_PRELOAD=./libasm.so ./test

make clean -> clean la lib

make fclean -> clean la lib + la source et les exec du C

make re -> fclean et compile
```
