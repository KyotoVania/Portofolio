{-
-- EPITECH PROJECT, 2023
-- B-FUN-400-PAR-4-1-compressor-jalel.belkacem
-- File description:
-- Point
-}

module Point (Point(..), randomlySelect, obtainPixelData, getMaxDimensions) where
import Pixel (Pixel, processPixelLine)
import Position (Position, processPosition)
import Data.List (groupBy)
import System.Random (randomRIO) -- For generating random numbers
import Text.ParserCombinators.ReadP

data Point = Point { pointPosition :: !(Int, Int), pointValue :: !Pixel }
  deriving (Show, Eq)

splitPixelLine :: String -> (String, String)
splitPixelLine line = case words line of
    (pos:rgb:_) -> (pos, rgb)
    _ -> error $ "Invalid pixel data: " ++ line

randomlySelect :: [a] -> IO a
randomlySelect xs = do
    idx <- randomRIO (0, length xs - 1)
    return $ xs !! idx

assignPixelsToClusters :: [Pixel] -> [Point] -> [Point]
assignPixelsToClusters pxs allocatedPts =
  zipWith (\pt px -> pt { pointValue = px }) allocatedPts pxs

getMaxDimensions :: [(Position, Pixel)] -> (Int, Int)
getMaxDimensions pxData =
  (maximum (map (fst . fst) pxData) + 1, maximum (map (snd . fst) pxData) + 1)

obtainPixelData :: FilePath -> IO [(Position, Pixel)]
obtainPixelData path = do
    content <- readFile path
    let pxLines = lines content
    let (posLines, rgbLines) = unzip $ map splitPixelLine pxLines
    return $ zip (map processPosition posLines) (map processPixelLine rgbLines)
