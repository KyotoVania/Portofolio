/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** client.c
*/

#include "client.h"

int retrieve_file(client_t *client,
char *command_check, char *file_name)
{
    char *command = strdup(command_check);
    char *filename = strdup(file_name);
    filename[strlen(filename) - 1] = '\0';
    if (strstr(command_check, "150") != NULL) {
        printf("File %s is being sent to client \n", command);
        if (retrieve_passive_mode(client, filename) == 84)
            return (84);
    } else if (strstr(command_check, "503") != NULL) {
        printf("Error: cannot retrieve file %s \n", command);
        return (84);
    }
    return (0);
}

int store_client_checkfile(int fd_file, client_t *client, char *file)
{
    char *response = NULL;
    if (fd_file == -1) {
        printf("Error: cannot open file %s \n", file);
        return 84;
    }
    if (read_and_write_client(fd_file, client->data_fd) == 84)
        return 84;
    response = read_server(client->fd);
    if (strstr(response, "226") == NULL) {
        printf("Error: cannot store file %s \n", file);
        return 84;
    }
    return 0;
}

int store_client(client_t *client, char *line)
{
    char *response = NULL;
    char *file = strdup(line);
    int fd_file = 0;
    fd_file = open(file, O_RDONLY);
    if (store_client_checkfile(fd_file, client, file) == 84)
        return 84;
    close(fd_file);
    close(client->data_fd);
    if (response == NULL) {
        printf("Error reading server response from fd %d\n",
        client->fd);
        return 84;
    }
    return 0;
}
