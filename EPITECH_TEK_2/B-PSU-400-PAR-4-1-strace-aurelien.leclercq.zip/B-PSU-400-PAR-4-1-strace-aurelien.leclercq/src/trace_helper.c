/*
** EPITECH PROJECT, 2023
** Strace
** File description:
** trace.c
*/

#include <sys/ptrace.h>
#include <sys/reg.h>
#include <sys/types.h>
#include <sys/user.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include "trace.h"
#include "syscall_helpers.h"

void perform_trace_p(trace_context_t *context)
{
    long long int syscall_num;
    long index;

    while (waitpid(context->pid, &context->status, 0)
        && !WIFEXITED(context->status)) {
        ptrace(PTRACE_GETREGS, context->pid, NULL, &context->regs);
        syscall_num = context->regs.orig_rax;
        index = get_syscall_index(syscall_num, context->tabled);
        if (syscall_num >= 0) {
            print_name(syscall_num, context->tabled);
            print_params(context->pid, context->tabled, index);
            print_retval(context->regs.rax, &context->opts,
            context->tabled[index].ret_type, context->pid);
        }
        ptrace(PTRACE_SINGLESTEP, context->pid, NULL, NULL);
    }
    detach_and_exit(context->pid);
}
