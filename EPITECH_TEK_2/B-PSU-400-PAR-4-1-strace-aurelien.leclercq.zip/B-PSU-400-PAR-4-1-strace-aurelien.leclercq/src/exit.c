/*
** EPITECH PROJECT, 2023
** Strace
** File description:
** exit.c
*/

#include <stdbool.h>
#include <stdio.h>
#include <sys/wait.h>
#include "exit.h"

bool is_exited(int exit_status)
{
    return WIFEXITED(exit_status);
}

bool is_signaled(int exit_status)
{
    return WIFSIGNALED(exit_status);
}

bool is_stopped(int exit_status)
{
    return WIFSTOPPED(exit_status);
}

int print_exit(int exit_status)
{
    int code = 0;
    struct condition_message_pair conditions_messages[] = {
            {is_exited, "+++ exited with %d +++\n"},
            {is_signaled, "+++ killed by %d +++\n"},
            {is_stopped, "+++ stopped by %d +++\n"},
            {NULL, "+++ unknown exit status %d +++\n"}
    };
    for (int i = 0; conditions_messages[i].condition != NULL; ++i) {
        if (conditions_messages[i].condition(exit_status)) {
            code = i;
            break;
        }
    }
    fprintf(stderr, conditions_messages[code].message,
            code == 0 ? WEXITSTATUS(exit_status) :
            code == 1 ? WTERMSIG(exit_status) :
            code == 2 ? WSTOPSIG(exit_status) : exit_status);
    return 0;
}
