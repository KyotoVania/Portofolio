/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** login_operation.c
*/

#include "myftp.h"

int check_iflogged(fd_node_t *node)
{
    if (node->status == is_logged_in)
        return (0);
    if (send_client_line(node->fd, "530 Not logged in.\n") == 84)
        return (84);
    node = node->next;
    return (530);
}

int check_ifanonymous(fd_node_t *node)
{
    if (node->status == is_anonymous)
        return (0);
    if (send_client_line(node->fd,
    "332 Need account for login.\n") == 84)
        return (84);
    node = node->next;
    return (332);
}

int set_account(fd_node_t *node, char *account)
{
    (void)account;
    if (check_iflogged(node) == 530)
        return (84);
    if (send_client_line(node->fd,
    "202 Command not implemented, superfluous at this site.\n") == 84)
        return (84);
    return (202);
}
