/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** NandComponent.hpp
*/
#ifndef NandCOMPONENT_HPP_
	#define NandCOMPONENT_HPP_

#include "AComponent.hpp"
#include "PinComponent.hpp"

namespace nts {

class NandComponent : public nts::AComponent {
    public:
        NandComponent();
        ~NandComponent();
        nts::Tristate compute(std::size_t pin);
        const std::vector<Pin> * getLinks() const;
        std::vector<Pin> * getLinks();
        void display(std::ostream &os);
        void setStates(nts::Tristate state) {};

private:
        std::vector<Pin> links = std::vector<Pin> (3);
    };
};

#endif /*NandCOMPONENT_HPP_*/