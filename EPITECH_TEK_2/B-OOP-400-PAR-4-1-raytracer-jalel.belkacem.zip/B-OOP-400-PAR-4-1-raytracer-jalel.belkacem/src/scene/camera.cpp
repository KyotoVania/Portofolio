/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** camera.cpp
*/

#include "scene/camera.hpp"

Camera::Camera(float fieldOfView, float aspectRatio)
{
    float theta = fieldOfView * M_PI / 180.0f;
    float halfHeight = tan(theta / 2.0f);
    float halfWidth = aspectRatio * halfHeight;

    origin = Vec3(0, 0, 0);
    lowerLeftCorner = Vec3(-halfWidth, -halfHeight, -1.0);
    horizontal = Vec3(2 * halfWidth, 0, 0);
    vertical = Vec3(0, 2 * halfHeight, 0);
}

Vec3 Camera::getOrigin() const
{
    return origin;
}

Vec3 Camera::getLowerLeftCorner() const
{
    return lowerLeftCorner;
}

Vec3 Camera::getHorizontal() const
{
    return horizontal;
}

Vec3 Camera::getVertical() const
{
    return vertical;
}