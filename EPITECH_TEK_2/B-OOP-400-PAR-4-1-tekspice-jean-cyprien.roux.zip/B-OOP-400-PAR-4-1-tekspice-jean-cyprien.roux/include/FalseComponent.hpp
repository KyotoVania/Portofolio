/*
** EPITECH PROJECT, 2023
** Bootsrap
** File description:
** FalseComponent.hpp
*/
#ifndef FALSECOMPONENT_HPP_
	#define FALSECOMPONENT_HPP_

#include "AComponent.hpp"

namespace nts {
    class FalseComponent : public nts::AComponent {
        public:
            FalseComponent();
            ~FalseComponent();
            nts::Tristate compute(std::size_t pin);
            std::vector<Pin> * getLinks();
            const std::vector<Pin> * getLinks() const;
            void display(std::ostream &os);
            void setStates(nts::Tristate state) {};
    private:
            std::vector<Pin> links = std::vector<Pin> (1);
    };
};

#endif /*FALSECOMPONENT_HPP_*/