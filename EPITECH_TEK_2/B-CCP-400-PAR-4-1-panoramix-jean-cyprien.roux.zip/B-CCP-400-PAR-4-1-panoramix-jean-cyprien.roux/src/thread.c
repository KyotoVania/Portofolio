/*
** EPITECH PROJECT, 2023
** B-CCP-400-PAR-4-1-panoramix-jean-cyprien.roux
** File description:
** thread.c
*/

#include "panoramix.h"

int init_parameters (parameters_t *parameters, char **av)
{
    parameters->nb_villagers = atoi(av[1]);
    parameters->pot_size = atoi(av[2]);
    parameters->nb_fights = atoi(av[3]);
    parameters->nb_refills = atoi(av[4]);
    return (0);
}

void init_semaphores_and_mutex(program_t *program)
{
    sem_init(&program->semaphorex.refill_sem, 0, 0);
    pthread_mutex_init(&program->semaphorex.pot_mutex, NULL);
    pthread_mutex_init(&program->semaphorex.wake_mutex, NULL);
    pthread_cond_init(&program->semaphorex.refill_cv, NULL);
    pthread_mutex_init(&program->semaphorex.finished_villagers_mutex, NULL);
}

void create_and_join_threads(program_t *program)
{
    pthread_t *threads = malloc(sizeof(pthread_t) *
    (program->parameters.nb_villagers + 1));
    pthread_create(&threads[0], NULL, druid, (void *)program);
    usleep(100);
    for (int i = 0; i < program->parameters.nb_villagers; i++) {
        pthread_create(&threads[i + 1], NULL, villager, (void *)program);
    }
    for (int i = 0; i <= program->parameters.nb_villagers; i++) {
        pthread_join(threads[i], NULL);
    }
    free(threads);
}

void init_villagers(program_t *program)
{
    program->villagers = malloc(sizeof(villager_t) *
        program->parameters.nb_villagers);
    program->villager_id = 0;
    for (int i = 0; i < program->parameters.nb_villagers; i++) {
        program->villagers[i].id = i;
        program->villagers[i].fight_left =
        program->parameters.nb_fights;
    }
}

void init_program(char **argv, program_t *program)
{
    init_parameters(&program->parameters, argv);
    program->druid.pot_size = program->parameters.pot_size;
    program->druid.refills_left = program->parameters.nb_refills;
    program->no_more_refills = false;
    init_villagers(program);
    pthread_barrier_init(&program->barrier,
        NULL, program->parameters.nb_villagers + 1);
    init_semaphores_and_mutex(program);
    create_and_join_threads(program);
    free(program->villagers);
}
