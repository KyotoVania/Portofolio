/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** active_mode.c
*/

#include "client.h"


void set_value_for_active_mode(client_t *client, char *port)
{
    client->data_port = atoi(port);
    client->states = is_active;
    client->data_fd = socket(AF_INET, SOCK_STREAM, 0);
    client->data_addr.sin_family = AF_INET;
    client->data_addr.sin_port = htons(client->data_port);
    client->data_addr.sin_addr.s_addr = inet_addr(client->ip);
    client->data_addr_len = sizeof(client->data_addr);
    return;
}

int activate_active_mode(char *port, client_t *client)
{
    printf("Active mode activation in progress...\n");
    if (client->data_fd != 0)
        close(client->data_fd);
    set_value_for_active_mode(client, port);
    if (bind(client->data_fd,
                (const struct sockaddr *)&client->data_addr,
                client->data_addr_len) == -1) {
        perror("bind");
        return (84);
    }
    if (listen(client->data_fd, 1) == -1) {
        perror("listen");
        return (84);
    }
    client->data_fd = accept(client->data_fd,
    (struct sockaddr *)&client->data_addr, &client->data_addr_len);
    printf("Connected to server %s:%d in active mode !\n",
    client->ip, client->data_port);
    return (0);
}
