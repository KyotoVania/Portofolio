/*
** EPITECH PROJECT, 2023
** B-CCP-400-PAR-4-1-panoramix-jean-cyprien.roux
** File description:
** panoramix.h
*/
#ifndef PANORAMIX_H_
    #define PANORAMIX_H_
    #include <stdio.h>
    #include <stdlib.h>
    #include <unistd.h>
    #include <pthread.h>
    #include <semaphore.h>
    #include <stdbool.h>

typedef struct villager_s {
    int id;
    int fight_left;
    bool drunk;
} villager_t;

typedef struct druid_s {
    int pot_size;
    int refills_left;
} druid_t;

typedef struct semaphorex_s {
    pthread_mutex_t pot_mutex;
    pthread_mutex_t wake_mutex;
    sem_t refill_sem;
    pthread_cond_t refill_cv;
    pthread_mutex_t finished_villagers_mutex;
    int finished_villagers;
} semaphorex_t;

typedef struct parameters_s {
    int nb_villagers;
    int pot_size;
    int nb_fights;
    int nb_refills;
} parameters_t;

typedef struct program_s {
    parameters_t parameters;
    druid_t druid;
    villager_t *villagers;
    int villager_id;
    semaphorex_t semaphorex;
    pthread_barrier_t barrier;
    bool no_more_refills;
} program_t;

void *villager(void *arg);
void *druid(void *arg);
void init_program(char **argv, program_t *program);
void init_semaphores_and_mutex(program_t *program);

#endif /*PANORAMIX_H_*/
