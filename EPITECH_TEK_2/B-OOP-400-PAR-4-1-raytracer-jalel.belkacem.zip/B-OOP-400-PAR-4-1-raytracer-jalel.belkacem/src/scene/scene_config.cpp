/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** scene_config.cpp
*/

#include "scene/scene_config.hpp"
#include "factory.hpp"
#include <libconfig.h++>
#include <iostream>
#include <string>

SceneConfig::~SceneConfig()
{
}

void SceneConfig::adjustRgbValues(Vec3& color)
{
	if (color.x > 1 || color.y > 1 || color.z > 1)
	{
		color.x /= 255;
		color.y /= 255;
		color.z /= 255;
	}
}

void SceneConfig::parseCamera(const libconfig::Setting& cameraConfig)
{
	CameraFactory cameraFactory;
	Camera camera = cameraFactory.create(cameraConfig);
	_camera = camera;
	ResolutionFactory resolutionFactory;
	std::pair<int, int> resolution = resolutionFactory.create(cameraConfig);
	_width = resolution.first;
	_height = resolution.second;	 
	std::cout << "Camera created" << std::endl;
}

void SceneConfig::parsePrimitives(const libconfig::Setting &primitivesConfig)
{
	SphereFactory sphereFactory;
	if (primitivesConfig.exists("spheres")) {
		const libconfig::Setting& spheresConfig = primitivesConfig["spheres"];
		for (int i = 0; i < spheresConfig.getLength(); ++i) {
			const libconfig::Setting& sphereConfig = spheresConfig[i];
			Sphere sphere = sphereFactory.create(sphereConfig);
			_spheres.push_back(sphere);
			std::cout << "sphere created" << std::endl;
		}
	}
	
	PlaneFactory planeFactory;
	if (primitivesConfig.exists("planes")) {
		const libconfig::Setting& planesConfig = primitivesConfig["planes"];
		for (int i = 0; i < planesConfig.getLength(); ++i) {
			const libconfig::Setting& planeConfig = planesConfig[i];
			Plane plane = planeFactory.create(planeConfig);
			_planes.push_back(plane);
			std::cout << "plane created" << std::endl;

		}
	}
}

void SceneConfig::parseLights(const libconfig::Setting &lightsConfig)
{
	AmbientLightFactory ambientLightFactory;
	if (lightsConfig.exists("ambient")) {
		const libconfig::Setting& ambientLightConfig = lightsConfig["ambient"];
		AmbientLight ambientLight = ambientLightFactory.create(ambientLightConfig);
		adjustRgbValues(ambientLight.color);
		_ambientLight = ambientLight;
		std::cout << "ambient light created" << std::endl;
	}
	
	directionalLightFactory directionalLightFactory;
	if (lightsConfig.exists("directional"))
	{
		
		const libconfig::Setting& directionalLightsConfig = lightsConfig["directional"];
		for (int i = 0; i < directionalLightsConfig.getLength(); ++i)
		{
			const libconfig::Setting& directionalLightConfig = directionalLightsConfig[i];
			DirectionalLight directionalLight = directionalLightFactory.create(directionalLightConfig);
			adjustRgbValues(directionalLight.color);
			_directionalLights.push_back(directionalLight);
			std::cout << "directional created" << std::endl;		
		}
	}

	pointLightFactory pointLightFactory;
	if (lightsConfig.exists("pointLights"))
	{
		const libconfig::Setting& pointLightsConfig = lightsConfig["pointLights"];
		for (int i = 0; i < pointLightsConfig.getLength(); ++i)
		{
			const libconfig::Setting& pointLightConfig = pointLightsConfig[i];
			pointLight pointLight = pointLightFactory.create(pointLightConfig);
			_pointLights.push_back(pointLight);
			std::cout << "point of light created" << std::endl;
		}
	}
}

bool SceneConfig::parseSceneConfig(const std::string &filename)
{
    libconfig::Config config;

    try
    {
        config.readFile(filename.c_str());
    }
    catch (const libconfig::FileIOException &fioex)
    {
        std::cerr << "Error: Cannot read configuration file '" << filename << "'." << std::endl;
        return false;
    }
    catch (const libconfig::ParseException &pex)
    {
        std::cerr << "Error: Parse error at " << pex.getFile() << ":" << pex.getLine()
                  << " - " << pex.getError() << std::endl;
        return false;
    }

    const libconfig::Setting &root = config.getRoot();

    parseCamera(root["camera"]);
    parsePrimitives(root["primitives"]);
    parseLights(root["lights"]);
    return true;
}

SceneConfig SceneConfig::set_up_scene(const std::string& scene_file) {
    SceneConfig scene_config;
    if (!scene_config.parseSceneConfig(scene_file)) {
        std::cerr << "Error loading scene configuration file." << std::endl;
        exit(1);
    }
    printf("Scene configuration loaded successfully.\n");
    return scene_config;
}