/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** pointLight.hpp
*/
#ifndef POINTLIGHT_HPP_
	#define POINTLIGHT_HPP_

class pointLight
{
	public:
		pointLight(const Vec3& position = Vec3(0, 0, 0), const Vec3& color = Vec3(1, 1, 1), float intensity = 1.0f, float constantAttenuation = 1.0f, float linearAttenuation = 0.0f, float quadraticAttenuation = 0.0f)
			: position(position), color(color), intensity(intensity), constantAttenuation(constantAttenuation), linearAttenuation(linearAttenuation), quadraticAttenuation(quadraticAttenuation) {}
		Vec3 position;
		Vec3 color;
		float intensity;
		float constantAttenuation;
		float linearAttenuation;
		float quadraticAttenuation;
	
};
#endif /*POINTLIGHT_HPP_*/