/*
** EPITECH PROJECT, 2023
** B-CCP-400-PAR-4-1-theplazza-titien.carellas
** File description:
** Command.hpp
*/
#ifndef COMMAND_HPP_
	#define COMMAND_HPP_
#include "Pizza.hpp"
#include <string>
#include <vector>
#include <utility>
#include <iostream>
#include <queue>
#include <memory>
#include "shared.hpp"

class Command {
	public:
		Command();
		Command(int id) : _id(id), _pizzaCommand() {		};
		~Command();
		void addPizza(Pizza * pizza, int quantity)
		{
			std::cout << "Adding pizza to command" << std::endl;
			std::cout << "Pizza name: " << pizza->getNameString() << std::endl;
			std::cout << "Pizza size: " << pizza->getSizeString() << std::endl;
			_pizzaCommand.push_back(std::make_pair(pizza, quantity));
		}
		std::size_t getNumberOfPizza() const;
		Command splitCommand(int availableSpace);
		//Add a function to set the command
		void setCommand(std::vector<std::pair<Pizza *, int>> command) {_pizzaCommand = command;}
		void addPizza(std::pair<Pizza *, int> pizza) {_pizzaCommand.push_back(pizza);}
		int getId() const {return _id;}
		//need to at least add a function ‘getPizzas’ to get the pizzas for the kitchen 
		std::queue<Pizza *> getPizzas() {
			std::queue<Pizza *> pizzaQueue;
			for (auto& pair : _pizzaCommand) {
				for (int i = 0; i < pair.second; i++) {
					pizzaQueue.push(pair.first);
				}
			}
			return pizzaQueue;
		}
		int getPizzaNumber() const {
			int result = 0;
		
			if (_pizzaCommand.size() > 0) {
				for (auto& pair : _pizzaCommand)
					result += pair.second;
			}
	
			return result;
		}
		void setId(int id) {_id = id;}
		void updateCommu(commu_t* command);
		std::shared_ptr<Command> parseCommand(std::string cmd, int id);
		std::vector<std::pair<Pizza *, int>> getCommand() const {return _pizzaCommand;}
	private:
	int _id;
	std::vector<std::pair<Pizza *, int>> _pizzaCommand; //pair of pizza and quantity of pizza
};

#endif /*COMMAND_HPP_*/