/*
** EPITECH PROJECT, 2023
** B-NWP-400-PAR-4-1-myftp-jean-cyprien.roux
** File description:
** server.c
*/

#include "myftp.h"
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int server_functionhandler_easy_split(fd_node_t *tmp_node, char *line,
command_map_easy commands)
{
    if (strncmp(line, commands.code,
    strlen(commands.code)) == 0) {
        if (commands.handler(tmp_node) == 84)
            return (84);
        return 1;
    }
    return 0;
}

int server_functionhandler_easy(fd_node_t *tmp_node, char *line)
{
    int res = 0;
    command_map_easy commands[] = {
            {"NOOP", noop_function},
            {"HELP", help_function},
            {"CDUP", set_cdup}
    };
    for (long unsigned int i = 0;
    i < sizeof(commands) / sizeof(command_map); i++) {
        res = server_functionhandler_easy_split(tmp_node,
        line, commands[i]);
        if (res == 84 || res == 1)
            return (res);
    }
    return 0;
}

int server_functionhandler_first_split(fd_node_t *tmp_node, char *line,
command_map commands)
{
    if (strncmp(line, commands.code,
        strlen(commands.code)) == 0) {
        if (commands.handler(tmp_node,
            line + strlen(commands.code) + 1) == 84)
            return (84);
        return 1;
    }
    return 0;
}

int server_functionhandler_first(fd_node_t *tmp_node, char *line)
{
    int res = 0;
    command_map commands[] = {
            {"USER", set_user},
            {"PASS", set_pass},
            {"ACCT", set_account},
            {"CWD", set_cwd},
            {"SMNT", set_smnt},
    };

    for (long unsigned int i = 0;
    i < sizeof(commands) / sizeof(command_map); i++) {
        res = server_functionhandler_first_split(tmp_node,
        line, commands[i]);
        if (res == 84 || res == 1)
            return (res);
    }
    return 0;
}
