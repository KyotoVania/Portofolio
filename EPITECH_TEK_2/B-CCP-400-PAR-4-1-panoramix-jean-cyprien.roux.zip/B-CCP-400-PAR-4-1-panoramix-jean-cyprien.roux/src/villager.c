/*
** EPITECH PROJECT, 2023
** B-CCP-400-PAR-4-1-panoramix-jean-cyprien.roux
** File description:
** villager.c
*/
#include "panoramix.h"
#include <stdbool.h>

void drink_potion(program_t *program, villager_t *villager)
{
    pthread_mutex_lock(&program->semaphorex.pot_mutex);
    if (!program->no_more_refills) {
        printf("Villager %d: I need a drink... I see %d servings left.\n",
        villager->id, program->druid.pot_size);

        if (program->druid.pot_size == 0 && !program->no_more_refills) {
            printf("Villager %d: Hey Pano wake up! We need more potion.\n",
            villager->id);
            sem_post(&program->semaphorex.refill_sem);
            pthread_cond_wait(&program->semaphorex.refill_cv,
            &program->semaphorex.pot_mutex);
        }
        program->druid.pot_size--;
        villager->drunk = true;
    }
    pthread_mutex_unlock(&program->semaphorex.pot_mutex);
}

void drink_remaining_potion(program_t *program, villager_t *villager)
{
    if (program->druid.pot_size > 0) {
        printf("Villager %d: I need a drink... I see %d servings left.\n",
        villager->id, program->druid.pot_size);
        program->druid.pot_size--;
        villager->drunk = true;
    }
}

bool loop_villager(program_t *program, villager_t *villager)
{
    if (program->druid.pot_size <= 0 && program->no_more_refills) {
        return (false);
    }
    pthread_mutex_lock(&program->semaphorex.wake_mutex);
    if (!program->no_more_refills) {
        drink_potion(program, villager);
    } else if (program->no_more_refills) {
        drink_remaining_potion(program, villager);
    }
    pthread_mutex_unlock(&program->semaphorex.wake_mutex);
    if (villager->drunk) {
        villager->drunk = false;
        villager->fight_left--;
        printf("Villager %d: Take that roman scum! Only %d left.\n",
        villager->id, villager->fight_left);
    }
    if (program->druid.pot_size <= 0 && program->no_more_refills) {
        return (false);
    }
    return (true);
}

void villager_wait_and_end(program_t *program, villager_t *villager)
{
    pthread_mutex_lock(&program->semaphorex.finished_villagers_mutex);
    program->semaphorex.finished_villagers++;
    pthread_mutex_unlock(&program->semaphorex.finished_villagers_mutex);
    pthread_mutex_lock(&program->semaphorex.wake_mutex);
    if (program->semaphorex.finished_villagers ==
        program->parameters.nb_villagers) {
        program->no_more_refills = true;
        sem_post(&program->semaphorex.refill_sem);
    }
    printf("Villager %d: I'm going to sleep now.\n", villager->id);
    pthread_mutex_unlock(&program->semaphorex.wake_mutex);
}

void *villager(void *arg)
{
    program_t *program = (program_t *)arg;
    villager_t *villager = &program->villagers[program->villager_id++];
    villager->drunk = false;
    printf("Villager %d: Going into battle!\n", villager->id);
    pthread_barrier_wait(&program->barrier);
    while (villager->fight_left > 0) {
        if (!loop_villager(program, villager))
            break;
    }
    villager_wait_and_end(program, villager);
    return NULL;
}
