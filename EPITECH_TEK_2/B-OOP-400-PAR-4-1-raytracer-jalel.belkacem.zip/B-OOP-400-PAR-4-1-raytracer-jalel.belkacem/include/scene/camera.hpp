/*
** EPITECH PROJECT, 2023
** B-OOP-400-PAR-4-1-raytracer-jalel.belkacem
** File description:
** camera.hpp
*/
#ifndef CAMERA_HPP_
	#define CAMERA_HPP_
	#include "utils/shared.hpp"

class Camera{
    public:
    Camera(float fieldOfView, float aspectRatio);
    Vec3 getOrigin() const;
    Vec3 getLowerLeftCorner() const;
    Vec3 getHorizontal() const;
    Vec3 getVertical() const;
    private:
    Vec3 origin;
    Vec3 lowerLeftCorner;
    Vec3 horizontal;
    Vec3 vertical;
};

#endif /*CAMERA_HPP_*/
